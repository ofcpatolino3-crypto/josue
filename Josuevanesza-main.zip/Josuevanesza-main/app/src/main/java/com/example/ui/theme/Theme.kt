package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = TranspetroCyan,
    onPrimary = TranspetroNavyDark,
    primaryContainer = TranspetroTeal,
    onPrimaryContainer = TranspetroIce,
    secondary = TranspetroGold,
    onSecondary = TranspetroNavyDark,
    tertiary = TranspetroGreenSuccess,
    background = SurfaceDark,
    surface = CardBackgroundDark,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    error = TranspetroRedAlert
)

private val LightColorScheme = lightColorScheme(
    primary = TranspetroNavyPrimary,
    onPrimary = TranspetroIce,
    primaryContainer = TranspetroTeal,
    onPrimaryContainer = TranspetroIce,
    secondary = TranspetroGoldDark,
    onSecondary = TranspetroIce,
    tertiary = TranspetroGreenSuccess,
    background = SurfaceLight,
    surface = CardBackgroundLight,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight,
    error = TranspetroRedAlert
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent Transpetro branding
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
