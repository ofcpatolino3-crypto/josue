package com.example.data.parser

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipInputStream

object XlsxParser {

    data class RawTable(
        val headers: List<String>,
        val rows: List<Map<String, String>>,
        val sheetNames: List<String>
    )

    /**
     * Parses standard .xlsx files (Zip archive containing XML worksheets and sharedStrings).
     */
    fun parseXlsx(bytes: ByteArray): RawTable {
        val sharedStrings = extractSharedStrings(bytes)
        val sheetData = extractFirstSheetData(bytes, sharedStrings)

        if (sheetData.isEmpty()) {
            return RawTable(emptyList(), emptyList(), emptyList())
        }

        val rawHeaders = sheetData.first()
        val headers = rawHeaders.mapIndexed { index, h ->
            if (h.isNotBlank()) h.trim() else "Coluna_${index + 1}"
        }

        val rows = mutableListOf<Map<String, String>>()
        for (i in 1 until sheetData.size) {
            val rowValues = sheetData[i]
            val rowMap = mutableMapOf<String, String>()
            for (colIdx in headers.indices) {
                val header = headers[colIdx]
                val value = if (colIdx < rowValues.size) rowValues[colIdx].trim() else ""
                rowMap[header] = value
            }
            rows.add(rowMap)
        }

        return RawTable(headers, rows, listOf("Sheet1"))
    }

    private fun extractSharedStrings(bytes: ByteArray): List<String> {
        val strings = mutableListOf<String>()
        val zip = ZipInputStream(ByteArrayInputStream(bytes))
        var entry = zip.nextEntry

        while (entry != null) {
            if (entry.name == "xl/sharedStrings.xml") {
                val parser = Xml.newPullParser()
                parser.setInput(zip, "UTF-8")
                var eventType = parser.eventType
                var inT = false
                val currentString = StringBuilder()

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    when (eventType) {
                        XmlPullParser.START_TAG -> {
                            if (parser.name == "t") {
                                inT = true
                            }
                        }
                        XmlPullParser.TEXT -> {
                            if (inT) {
                                currentString.append(parser.text)
                            }
                        }
                        XmlPullParser.END_TAG -> {
                            if (parser.name == "t") {
                                inT = false
                            } else if (parser.name == "si") {
                                strings.add(currentString.toString())
                                currentString.setLength(0)
                            }
                        }
                    }
                    eventType = parser.next()
                }
                break
            }
            entry = zip.nextEntry
        }
        zip.close()
        return strings
    }

    private fun extractFirstSheetData(bytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val zip = ZipInputStream(ByteArrayInputStream(bytes))
        var entry = zip.nextEntry

        while (entry != null) {
            if (entry.name.startsWith("xl/worksheets/sheet") && entry.name.endsWith(".xml")) {
                val parser = Xml.newPullParser()
                parser.setInput(zip, "UTF-8")
                var eventType = parser.eventType

                val currentRow = mutableMapOf<Int, String>()
                var currentCellColIndex = 0
                var cellType: String? = null
                var inValue = false
                val cellValue = StringBuilder()

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    when (eventType) {
                        XmlPullParser.START_TAG -> {
                            when (parser.name) {
                                "row" -> {
                                    currentRow.clear()
                                }
                                "c" -> {
                                    val cellRef = parser.getAttributeValue(null, "r") ?: ""
                                    currentCellColIndex = cellRefToColIndex(cellRef)
                                    cellType = parser.getAttributeValue(null, "t")
                                    cellValue.setLength(0)
                                }
                                "v" -> {
                                    inValue = true
                                }
                                "t" -> {
                                    inValue = true
                                }
                            }
                        }
                        XmlPullParser.TEXT -> {
                            if (inValue) {
                                cellValue.append(parser.text)
                            }
                        }
                        XmlPullParser.END_TAG -> {
                            when (parser.name) {
                                "v", "t" -> {
                                    inValue = false
                                }
                                "c" -> {
                                    val rawVal = cellValue.toString().trim()
                                    val finalVal = if (cellType == "s") {
                                        val strIndex = rawVal.toIntOrNull() ?: -1
                                        if (strIndex in sharedStrings.indices) sharedStrings[strIndex] else rawVal
                                    } else {
                                        rawVal
                                    }
                                    currentRow[currentCellColIndex] = finalVal
                                }
                                "row" -> {
                                    if (currentRow.isNotEmpty()) {
                                        val maxCol = (currentRow.keys.maxOrNull() ?: 0)
                                        val rowList = mutableListOf<String>()
                                        for (c in 0..maxCol) {
                                            rowList.add(currentRow[c] ?: "")
                                        }
                                        if (rowList.any { it.isNotBlank() }) {
                                            rows.add(rowList)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    eventType = parser.next()
                }
                break
            }
            entry = zip.nextEntry
        }
        zip.close()
        return rows
    }

    private fun cellRefToColIndex(cellRef: String): Int {
        var col = 0
        for (ch in cellRef) {
            if (ch in 'A'..'Z') {
                col = col * 26 + (ch - 'A' + 1)
            } else {
                break
            }
        }
        return (col - 1).coerceAtLeast(0)
    }

    /**
     * Also parses XML Spreadsheet 2003 format (saved as .xml or .xls by Excel).
     */
    fun parseXmlSpreadsheet(text: String): RawTable {
        val parser = Xml.newPullParser()
        parser.setInput(text.reader())
        var eventType = parser.eventType

        val rows = mutableListOf<List<String>>()
        var currentRow = mutableListOf<String>()
        var inData = false
        val cellValue = StringBuilder()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "Row" -> currentRow = mutableListOf()
                        "Data" -> {
                            inData = true
                            cellValue.setLength(0)
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inData) cellValue.append(parser.text)
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "Data" -> {
                            inData = false
                            currentRow.add(cellValue.toString().trim())
                        }
                        "Row" -> {
                            if (currentRow.any { it.isNotBlank() }) {
                                rows.add(currentRow)
                            }
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        if (rows.isEmpty()) return RawTable(emptyList(), emptyList(), emptyList())

        val headers = rows.first().mapIndexed { i, h -> if (h.isNotBlank()) h else "Coluna_${i + 1}" }
        val dataRows = mutableListOf<Map<String, String>>()
        for (i in 1 until rows.size) {
            val r = rows[i]
            val map = mutableMapOf<String, String>()
            for (col in headers.indices) {
                map[headers[col]] = if (col < r.size) r[col] else ""
            }
            dataRows.add(map)
        }

        return RawTable(headers, dataRows, listOf("Planilha1"))
    }
}
