package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudyDaySchedule
import com.example.data.repository.EBookMasterRepository
import com.example.ui.theme.TranspetroGold
import com.example.ui.theme.TranspetroGreenSuccess
import com.example.ui.theme.TranspetroNavyPrimary
import com.example.ui.viewmodel.EBookUiState
import com.example.ui.viewmodel.EBookViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyPlansScreen(
    viewModel: EBookViewModel,
    uiState: EBookUiState,
    modifier: Modifier = Modifier
) {
    val plans = remember { EBookMasterRepository.getStudyPlans() }
    val currentPlan = plans.find { it.id == uiState.selectedPlanId } ?: plans.first()

    val completedDaysCount = currentPlan.dailySchedules.count { uiState.completedDays.contains(it.dayNumber) }
    val totalDays = currentPlan.targetHorizonDays
    val progress = if (totalDays > 0) completedDaysCount.toFloat() / totalDays else 0f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        // Top Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TranspetroNavyPrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CRONOGRAMAS ESTRATÉGICOS DE ESTUDO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TranspetroGold
                    )
                    Text(
                        text = currentPlan.title,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = currentPlan.description,
                        fontSize = 12.5.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        lineHeight = 17.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Meta: ${currentPlan.recommendedDailyHours}h/dia • $completedDaysCount de $totalDays dias concluídos",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TranspetroGreenSuccess
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = TranspetroGreenSuccess,
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )
                }
            }
        }

        // Plan Selector Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                plans.forEach { plan ->
                    FilterChip(
                        selected = plan.id == currentPlan.id,
                        onClick = { viewModel.selectStudyPlan(plan.id) },
                        label = { Text("${plan.targetHorizonDays} Dias", fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }
            }
        }

        // Weekly Goals
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "METAS SEMANAIS DO PLANO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    for (goal in currentPlan.weeklyGoals) {
                        Row(modifier = Modifier.padding(vertical = 3.dp)) {
                            Text(text = "✓ ", color = TranspetroGreenSuccess, fontWeight = FontWeight.Bold)
                            Text(text = goal, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }

        // Day by Day Schedule
        item {
            Text(
                text = "Cronograma Diário Passo a Passo",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(currentPlan.dailySchedules) { schedule ->
            val isDone = uiState.completedDays.contains(schedule.dayNumber)

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .testTag("study_day_${schedule.dayNumber}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.toggleDayCompleted(schedule.dayNumber) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Concluir Dia",
                            tint = if (isDone) TranspetroGreenSuccess else MaterialTheme.colorScheme.outline
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Dia ${schedule.dayNumber} — ${schedule.focusSubject}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${schedule.estimatedHours}h",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        for (top in schedule.topicsToStudy) {
                            Text(
                                text = "• $top",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Meta do dia: ~${schedule.targetTheoryPages} págs • ${schedule.targetQuestions} questões",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TranspetroGold
                        )
                    }
                }
            }
        }
    }
}
