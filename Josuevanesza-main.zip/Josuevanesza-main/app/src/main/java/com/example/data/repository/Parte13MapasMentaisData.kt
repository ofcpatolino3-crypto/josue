package com.example.data.repository

import com.example.data.model.*

object Parte13MapasMentaisData {
    fun getChapter(): EBookChapter {
        return EBookChapter(
            id = "part13_mapas_mentais",
            partId = "part_13",
            partNumber = 13,
            partTitle = "PARTE 13 — MAPAS MENTAIS EM FORMATO TEXTUAL",
            chapterNumber = 1,
            title = "Mapas Mentais Textuais Esquematizados",
            subtitle = "Estruturas Visuais Lógicas para Fixação Rápida da Memória de Curto e Longo Prazo",
            readTimeMinutes = 20,
            strategicSummary = "Diagramas conceituais em formato de árvore textual cobrindo os 6 pilares temáticos do Processo Seletivo Público Transpetro 2026.",
            highYieldAlerts = listOf(
                "Mapas mentais textuais ativam a memória visual associativa através de ramificações hierárquicas.",
                "Utilize os diagramas para revisões relâmpago de 5 minutos antes de iniciar baterias de questões."
            ),
            examTraps = listOf(
                "Tentar memorizar conceitos isolados sem entender a hierarquia lógica de onde eles se encaixam no processo operacional."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Mapa Mental: Língua Portuguesa (Sintaxe e Pontuação)",
                    body = """```text
[LÍNGUA PORTUGUESA]
  ├── CRASE
  │     ├── Proibida ───► Antes de masculino / Verbo / Pronome pessoal / 'A' + plural
  │     ├── Facultativa ─► Nome de mulher / Possessivo feminino ('à minha') / Até a(à)
  │     └── Obrigatória ─► Locuções femininas ('à medida que', 'às vezes') / Termo regente pede 'A' + termo regido tem 'A'
  │
  ├── CONCORDÂNCIA
  │     ├── Haver / Fazer ──► Impessoais (sentido de existir ou tempo) ──► 3ª pessoa SINGULAR
  │     ├── VTD + SE ────────► Voz Passiva Sintética ──────────────────► Concorda com o Sujeito
  │     └── VTI + SE ────────► Índice de Indeterminação do Sujeito ────► 3ª pessoa SINGULAR
  │
  └── ORAÇÕES & CONECTIVOS
        ├── Adversativas ──► Mas, porém, contudo, todavia, no entanto ─► Oposição direta
        ├── Concessivas ───► Embora, conquanto, ainda que, posto que ──► Oposição com subjuntivo
        └── Proporcionais ─► À medida que, à proporção que ────────────► Simultaneidade progressiva
```"""
                ),
                ContentSection(
                    title = "2. Mapa Mental: Matemática e Grandezas de Processo",
                    body = """```text
[MATEMÁTICA OPERACIONAL]
  ├── VARIAÇÕES PERCENTUAIS
  │     ├── Aumento (+i%) ────► Multiplica por (1 + i/100)  [ex: +20% ⇒ × 1,20]
  │     ├── Desconto (-i%) ───► Multiplica por (1 - i/100)  [ex: -15% ⇒ × 0,85]
  │     └── Sucessivas ───────► F_total = F1 × F2 × ... × Fn (NUNCA somar!)
  │
  ├── GEOMETRIA INDUSTRIAL
  │     ├── Tanque Cilíndrico ──► Volume V = π · r² · h  (1 m³ = 1.000 L)
  │     ├── Tanque Esférico ────► Volume V = (4/3) · π · r³
  │     └── Área do Círculo ────► A = π · r²  |  Perímetro C = 2 · π · r
  │
  └── REGRAS DE PROPORÇÃO
        ├── Diretas ──────────► Multiplicação em CRUZ (a / b = c / d)
        └── Inversas ─────────► Multiplicação em LINHA (a · b = c · d) [ex: Vazão × Tempo]
```"""
                ),
                ContentSection(
                    title = "3. Mapa Mental: Dutos, Válvulas e Bombas",
                    body = """```text
[DUTOS & EQUIPAMENTOS]
  ├── TUBULAÇÕES & VÁLVULAS
  │     ├── API 5L ──────────► Aços Grau X (X52, X65, X70 = SMYS em ksi)
  │     ├── Válvula Esfera ──► Passagem Plena (Full Bore) ──► Permite PIG
  │     ├── Válvula Gaveta ──► Bloqueio On/Off (Não serve para regular vazão!)
  │     ├── Válvula Globo ───► Regulagem fina de vazão (Alta perda de carga)
  │     └── Válvula Retenção ► Fluxo unidirecional automático (Anti-retorno)
  │
  ├── MÁQUINAS DE FLUXO (BOMBAS)
  │     ├── Centrífugas ─────► Vazão contínua, alta rotação, turbomáquinas
  │     │     ├── Em Série ──► Soma Alturas Manométricas (H_total = H1 + H2)
  │     │     └── Em Paralelo► Soma Vazões (Q_total = Q1 + Q2)
  │     ├── Volumétricas ────► Deslocamento positivo (Parafusos, Pistão) ──► Exige PSV
  │     └── Anti-Cavitação ──► NPSH_disponível > NPSH_requerido (Obrigatório!)
  │
  └── ARMAZENAGEM & TANQUES
        ├── Teto Fixo ───────► Diesel, Bunker, Óleos Pesados (baixa volatilidade)
        ├── Teto Flutuante ──► Petróleo Leve, Gasolina, Nafta (elimina espaço vapor)
        └── Esferas GLP ─────► Pressurizadas a 8-18 kgf/cm² (Propano/Butano líquido)
```"""
                ),
                ContentSection(
                    title = "4. Mapa Mental: Manutenção Mecânica e SMS",
                    body = """```text
[MANUTENÇÃO & SEGURANÇA]
  ├── TRIBOLOGIA & MANCAIS
  │     ├── Mancal Deslizamento ─► Cunha de óleo hidrodinâmica (Grandes eixos/turbinas)
  │     ├── Mancal Rolamento ────► Rígido esferas (radial/alta vel), Rolos cônicos (axial+radial)
  │     └── Lubrificação ────────► ISO VG (Viscosidade cSt a 40 °C), NLGI (Graxas 000 a 6)
  │
  ├── MANUTENÇÃO PREDITIVA
  │     ├── Vibrações (FFT) ─────► 1X (Desbalanceamento), 2X (Desalinhamento), Harmônicos (Folga)
  │     ├── Confiabilidade ──────► MTBF (Tempo entre falhas) ↑  |  MTTR (Tempo de reparo) ↓
  │     └── Alinhamento Laser ───► Correção radial/angular + Verificação de 'Pé Manco'
  │
  └── SMS & COMBATE A INCÊNDIO
        ├── Classe B (Inflamáveis) ─► Espuma Mecânica (LGE) / PQS (Água em jato PROIBIDA!)
        ├── Proteção Catódica ─────► Duto = CÁTODO (-850 mV vs Cu/CuSO₄) ligado ao polo (-)
        └── Espaço Confinado (NR-33)► PET + Vigia Permanente + Medição Contínua (O₂ > 19,5%)
```"""
                ),
                ContentSection(
                    title = "5. Mapa Mental: Administração, Materiais e Governança",
                    body = """```text
[ADMINISTRAÇÃO & SUPRIMENTOS]
  ├── GESTÃO DE ESTOQUES
  │     ├── Curva ABC ────────► A (~20% itens / ~80% valor), B (~30%/15%), C (~50%/5%)
  │     ├── Criticidade XYZ ──► Z (Vital/Crítico: falta paralisa a planta), Y (Médio), X (Baixo)
  │     └── Avaliação PEPS ───► Saídas a custos antigos; Estoque final avaliado a preços novos
  │
  ├── COMPRAS & LEI 13.303/16 (ESTATAIS)
  │     ├── Inexigibilidade ──► Inviabilidade jurídica de competição (Fornecedor exclusivo)
  │     └── Dispensa ─────────► Competição possível, mas dispensada por lei (Pequeno valor)
  │
  └── GOVERNANÇA & COMPLIANCE
        ├── 4 Princípios IBGC ─► Transparência, Equidade, Prestação de Contas (Accountability), Responsabilidade
        └── Lei Anticorrupção ─► Lei 12.846/2013 ──► Responsabilidade civil e administrativa OBJETIVA
```"""
                )
            )
        )
    }
}
