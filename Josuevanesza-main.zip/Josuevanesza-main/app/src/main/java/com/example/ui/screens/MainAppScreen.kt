package com.example.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.viewmodel.EBookUiState
import com.example.ui.viewmodel.EBookViewModel
import com.example.ui.viewmodel.MainTab

@Composable
fun MainAppScreen(
    viewModel: EBookViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    // Determine current screen content
    when {
        uiState.selectedChapter != null -> {
            ChapterReaderScreen(
                chapter = uiState.selectedChapter!!,
                viewModel = viewModel,
                uiState = uiState,
                onBack = { viewModel.selectChapter(null) }
            )
        }
        uiState.selectedModule != null -> {
            ModuleDetailScreen(
                module = uiState.selectedModule!!,
                viewModel = viewModel,
                uiState = uiState,
                onBack = { viewModel.selectModule(null) }
            )
        }
        else -> {
            Scaffold(
                bottomBar = {
                    NavigationBar(
                        modifier = Modifier.testTag("main_bottom_nav"),
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 6.dp
                    ) {
                        NavigationBarItem(
                            selected = uiState.currentTab == MainTab.SUMARIO,
                            onClick = { viewModel.setTab(MainTab.SUMARIO) },
                            icon = { Icon(Icons.Default.MenuBook, contentDescription = "Apostila") },
                            label = { Text("Apostila") },
                            modifier = Modifier.testTag("nav_tab_sumario")
                        )
                        NavigationBarItem(
                            selected = uiState.currentTab == MainTab.QUESTOES,
                            onClick = { viewModel.setTab(MainTab.QUESTOES) },
                            icon = { Icon(Icons.Default.Quiz, contentDescription = "Questões") },
                            label = { Text("Questões") },
                            modifier = Modifier.testTag("nav_tab_questoes")
                        )
                        NavigationBarItem(
                            selected = uiState.currentTab == MainTab.SIMULADOS,
                            onClick = { viewModel.setTab(MainTab.SIMULADOS) },
                            icon = { Icon(Icons.Default.Timer, contentDescription = "Simulados") },
                            label = { Text("Simulados") },
                            modifier = Modifier.testTag("nav_tab_simulados")
                        )
                        NavigationBarItem(
                            selected = uiState.currentTab == MainTab.PLANO_ESTUDO,
                            onClick = { viewModel.setTab(MainTab.PLANO_ESTUDO) },
                            icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "Planos") },
                            label = { Text("Planos") },
                            modifier = Modifier.testTag("nav_tab_planos")
                        )
                        NavigationBarItem(
                            selected = uiState.currentTab == MainTab.REVISAO_TURBO,
                            onClick = { viewModel.setTab(MainTab.REVISAO_TURBO) },
                            icon = { Icon(Icons.Default.FlashOn, contentDescription = "Revisão") },
                            label = { Text("Revisão") },
                            modifier = Modifier.testTag("nav_tab_revisao")
                        )
                    }
                }
            ) { innerPadding ->
                when (uiState.currentTab) {
                    MainTab.SUMARIO -> HomeScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        modifier = Modifier.padding(innerPadding)
                    )
                    MainTab.QUESTOES -> QuestionBankScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        modifier = Modifier.padding(innerPadding)
                    )
                    MainTab.SIMULADOS -> SimuladosScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        modifier = Modifier.padding(innerPadding)
                    )
                    MainTab.PLANO_ESTUDO -> StudyPlansScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        modifier = Modifier.padding(innerPadding)
                    )
                    MainTab.REVISAO_TURBO -> RevisaoTurboScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}
