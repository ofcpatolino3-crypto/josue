package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.viewmodel.LeadUiState
import com.example.ui.viewmodel.LeadViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeadDashboardScreen(
    viewModel: LeadViewModel,
    uiState: LeadUiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var filterInput by remember { mutableStateOf(uiState.responsibleFilterInput) }

    // File Picker for CSV, XLSX, XLS
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "planilha_leads.csv"
            viewModel.loadUserFile(fileName, uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Gestor de Leads",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Validação Pré-Importação • Mapeamento Real de Cursos",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.openIntegrityReport() },
                        modifier = Modifier.testTag("btn_integrity_report")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Relatório de Integridade",
                            tint = SuccessGreen
                        )
                    }

                    Button(
                        onClick = { viewModel.openExportDialog() },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("btn_export")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Exportar", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryNavy)
            )
        },
        snackbarHost = {
            if (uiState.feedbackMessage != null) {
                Snackbar(
                    modifier = Modifier.padding(16.dp),
                    action = {
                        TextButton(onClick = { viewModel.dismissFeedbackMessage() }) {
                            Text("OK", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    },
                    containerColor = PrimaryNavy
                ) {
                    Text(text = uiState.feedbackMessage)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(SurfaceLight)
                .padding(innerPadding)
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
        ) {
            // Import Actions & File Info
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    filePickerLauncher.launch(
                                        arrayOf(
                                            "text/csv",
                                            "text/comma-separated-values",
                                            "application/vnd.ms-excel",
                                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                            "*/*"
                                        )
                                    )
                                },
                                modifier = Modifier
                                    .weight(1.1f)
                                    .testTag("btn_pick_file"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentTeal)
                            ) {
                                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Importar Planilha", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { viewModel.loadSample908Data() },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_load_sample_908"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CourseBlue)
                            ) {
                                Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Testar 908 Leads", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (uiState.parseResult != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Base ativa: ${uiState.parseResult.fileName}",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryNavy
                                )
                                Text(
                                    text = "${uiState.parseResult.fileType} • ${uiState.allLeads.size} leads",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }

            // Quick Stats Banner
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatBadge(
                        label = "Total Leads",
                        value = "${uiState.allLeads.size}",
                        icon = Icons.Default.People,
                        tint = PrimaryNavy,
                        modifier = Modifier.weight(1f)
                    )
                    StatBadge(
                        label = "Com Telefone",
                        value = "${uiState.allLeads.count { it.hasPhone }}",
                        icon = Icons.Default.Phone,
                        tint = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                    StatBadge(
                        label = "Com Curso",
                        value = "${uiState.allLeads.count { it.hasCourse }}",
                        icon = Icons.Default.School,
                        tint = CourseBlue,
                        modifier = Modifier.weight(1f)
                    )
                    StatBadge(
                        label = "Duplicados",
                        value = "${uiState.allLeads.count { it.isDuplicate }}",
                        icon = Icons.Default.ContentCopy,
                        tint = WarningAmber,
                        modifier = Modifier.weight(1f)
                    )
                    StatBadge(
                        label = "Perdidos",
                        value = "0",
                        icon = Icons.Default.Security,
                        tint = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Filter by Responsible Input (Rule 8)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "DIVISÃO AUTOMÁTICA POR RESPONSÁVEL:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryNavy
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = filterInput,
                                onValueChange = { filterInput = it },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_responsible_filter"),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                                placeholder = { Text("Ex: Josué e Wanessa", fontSize = 13.sp) }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { viewModel.applyResponsibleFilter(filterInput) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryNavy),
                                modifier = Modifier.testTag("btn_apply_responsible_filter")
                            ) {
                                Text("Filtrar", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Responsible Tabs (Scrollable)
            item {
                val scrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState)
                        .padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    uiState.availableTabs.forEach { tabName ->
                        val isSelected = uiState.selectedTab == tabName
                        val count = if (tabName == "Todos") {
                            uiState.allLeads.size
                        } else {
                            uiState.responsibleSheets.find { it.sheetName == tabName }?.leadCount ?: 0
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectTab(tabName) },
                            label = {
                                Text(
                                    text = "$tabName ($count)",
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                                    fontSize = 12.5.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryNavy,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("tab_$tabName")
                        )
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Buscar por nome, telefone, curso, temperatura...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Limpar")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .testTag("search_leads_input")
                )
            }

            // Quick Banner: If any lead has blank course but filled observation
            val leadsWithObsNoCourse = uiState.allLeads.count { it.course.isBlank() && it.observation.isNotBlank() }
            if (leadsWithObsNoCourse > 0) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .testTag("card_fix_obs_to_course_banner"),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF9C3)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCA8A04).copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = Color(0xFF854D0E),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "$leadsWithObsNoCourse lead(s) com observação mas sem curso.",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF854D0E)
                                    )
                                    Text(
                                        text = "Se os cursos comprados estão em observação, mova-os agora:",
                                        fontSize = 11.sp,
                                        color = Color(0xFFA16207)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { viewModel.moveAllObservationsToCourses() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF854D0E)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("btn_move_all_obs_to_course")
                            ) {
                                Text(
                                    text = "Mover p/ Curso",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Header for leads count
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Leads Exibidos: ${uiState.displayedLeads.size}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "Toque em um lead para ver todas as colunas",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // Leads List
            items(uiState.displayedLeads, key = { it.id }) { lead ->
                LeadCard(
                    lead = lead,
                    onMoveObservationToCourse = { leadId -> viewModel.moveObservationToCourse(leadId) }
                )
            }

            if (uiState.displayedLeads.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Nenhum lead encontrado para este filtro.",
                            color = Color(0xFF64748B),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }

    // Pre-Import Confirmation Screen / Dialog
    if (uiState.isPreImportPreviewOpen && uiState.pendingImportResult != null) {
        PreImportConfirmationDialog(
            parseResult = uiState.pendingImportResult,
            onUpdateMapping = { courseCol, obsCol ->
                viewModel.updateImportColumnMapping(courseCol, obsCol)
            },
            onConfirmImport = { viewModel.confirmPendingImport() },
            onCancel = { viewModel.cancelPendingImport() }
        )
    }

    // Integrity Report Dialog
    if (uiState.isIntegrityReportOpen && uiState.integrityReport != null) {
        IntegrityReportDialog(
            report = uiState.integrityReport,
            onDismiss = { viewModel.dismissIntegrityReport() }
        )
    }

    // Pre-Export Validation Dialog
    if (uiState.isExportDialogOpen && uiState.exportValidation != null) {
        PreExportValidationDialog(
            validation = uiState.exportValidation,
            onConfirmExport = { format -> viewModel.executeExport(format, context) },
            onDismiss = { viewModel.dismissExportDialog() }
        )
    }

    // Validation Blocker Dialog
    if (uiState.isValidationBlockerOpen && uiState.exportValidation != null) {
        ValidationBlockerDialog(
            validation = uiState.exportValidation,
            onDismiss = { viewModel.dismissExportDialog() }
        )
    }
}

@Composable
private fun StatBadge(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                color = tint
            )
            Text(
                text = label,
                fontSize = 8.5.sp,
                color = Color(0xFF64748B),
                maxLines = 1
            )
        }
    }
}
