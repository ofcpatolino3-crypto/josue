package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.EBookMasterRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class MainTab {
    SUMARIO,
    QUESTOES,
    SIMULADOS,
    PLANO_ESTUDO,
    REVISAO_TURBO
}

data class EBookUiState(
    val currentTab: MainTab = MainTab.SUMARIO,
    val selectedModule: EBookModule? = null,
    val selectedChapter: EBookChapter? = null,
    val searchQuery: String = "",
    val searchResults: List<EBookChapter> = emptyList(),
    val completedChapterIds: Set<String> = emptySet(),
    val favoriteChapterIds: Set<String> = emptySet(),
    val userQuizAnswers: Map<String, Int> = emptyMap(),
    // Reader Settings
    val readerFontSizeSp: Float = 16f,
    val isNightReadingMode: Boolean = false,
    val isSepiaMode: Boolean = false,
    // Active Simulation
    val activeSimulation: ExamSimulation? = null,
    val simRemainingSeconds: Int = 0,
    val simAnswers: Map<String, Int> = emptyMap(),
    val simIsFinished: Boolean = false,
    val simScorePercentage: Float = 0f,
    // Question Bank Filters
    val filterSubject: String? = null,
    val filterDifficulty: String? = null,
    // Study Plan Selected
    val selectedPlanId: String = "plano_30_dias",
    val completedDays: Set<Int> = emptySet()
)

class EBookViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(EBookUiState())
    val uiState: StateFlow<EBookUiState> = _uiState.asStateFlow()

    val modules: StateFlow<List<EBookModule>> = EBookMasterRepository.modules

    private var simTimerJob: Job? = null

    init {
        viewModelScope.launch {
            EBookMasterRepository.completedChapters.collect { completed ->
                _uiState.update { it.copy(completedChapterIds = completed) }
            }
        }
        viewModelScope.launch {
            EBookMasterRepository.favoriteChapterIds.collect { favs ->
                _uiState.update { it.copy(favoriteChapterIds = favs) }
            }
        }
        viewModelScope.launch {
            EBookMasterRepository.userQuizAnswers.collect { answers ->
                _uiState.update { it.copy(userQuizAnswers = answers) }
            }
        }
    }

    fun setTab(tab: MainTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun selectModule(module: EBookModule?) {
        _uiState.update { it.copy(selectedModule = module, selectedChapter = null) }
    }

    fun selectChapter(chapter: EBookChapter?) {
        _uiState.update { it.copy(selectedChapter = chapter) }
    }

    fun updateSearchQuery(query: String) {
        val results = EBookMasterRepository.searchContent(query)
        _uiState.update { it.copy(searchQuery = query, searchResults = results) }
    }

    fun toggleChapterCompletion(chapterId: String) {
        EBookMasterRepository.toggleChapterCompletion(chapterId)
    }

    fun toggleFavorite(chapterId: String) {
        EBookMasterRepository.toggleFavoriteChapter(chapterId)
    }

    fun answerQuizQuestion(questionId: String, optionIndex: Int) {
        EBookMasterRepository.recordQuizAnswer(questionId, optionIndex)
    }

    fun increaseFontSize() {
        _uiState.update { it.copy(readerFontSizeSp = (it.readerFontSizeSp + 2f).coerceAtMost(26f)) }
    }

    fun decreaseFontSize() {
        _uiState.update { it.copy(readerFontSizeSp = (it.readerFontSizeSp - 2f).coerceAtLeast(12f)) }
    }

    fun toggleSepiaMode() {
        _uiState.update { it.copy(isSepiaMode = !it.isSepiaMode, isNightReadingMode = false) }
    }

    fun toggleNightMode() {
        _uiState.update { it.copy(isNightReadingMode = !it.isNightReadingMode, isSepiaMode = false) }
    }

    // Simulados Logic
    fun startSimulation(simulation: ExamSimulation) {
        simTimerJob?.cancel()
        _uiState.update {
            it.copy(
                activeSimulation = simulation,
                simRemainingSeconds = simulation.durationMinutes * 60,
                simAnswers = emptyMap(),
                simIsFinished = false,
                simScorePercentage = 0f
            )
        }
        startSimulationTimer()
    }

    private fun startSimulationTimer() {
        simTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val current = _uiState.value.simRemainingSeconds
                if (current > 0 && !_uiState.value.simIsFinished) {
                    _uiState.update { it.copy(simRemainingSeconds = current - 1) }
                } else if (current <= 0) {
                    finishSimulation()
                    break
                }
            }
        }
    }

    fun recordSimAnswer(questionId: String, optionIndex: Int) {
        val answers = _uiState.value.simAnswers.toMutableMap()
        answers[questionId] = optionIndex
        _uiState.update { it.copy(simAnswers = answers) }
    }

    fun finishSimulation() {
        simTimerJob?.cancel()
        val sim = _uiState.value.activeSimulation ?: return
        var correctCount = 0
        val questionsList = sim.allQuestions
        questionsList.forEach { q ->
            val userAns = _uiState.value.simAnswers[q.id]
            if (userAns == q.correctIndex) {
                correctCount++
            }
        }
        val score = if (questionsList.isNotEmpty()) {
            (correctCount.toFloat() / questionsList.size) * 100f
        } else 0f

        _uiState.update { it.copy(simIsFinished = true, simScorePercentage = score) }
    }

    fun exitSimulation() {
        simTimerJob?.cancel()
        _uiState.update { it.copy(activeSimulation = null, simIsFinished = false) }
    }

    // Filter Question Bank
    fun setQuestionFilter(subject: String?, difficulty: String?) {
        _uiState.update { it.copy(filterSubject = subject, filterDifficulty = difficulty) }
    }

    fun selectStudyPlan(planId: String) {
        _uiState.update { it.copy(selectedPlanId = planId) }
    }

    fun toggleDayCompleted(dayNumber: Int) {
        val current = _uiState.value.completedDays.toMutableSet()
        if (current.contains(dayNumber)) current.remove(dayNumber) else current.add(dayNumber)
        _uiState.update { it.copy(completedDays = current) }
    }
}
