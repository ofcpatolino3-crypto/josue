package com.example.data.exporter

import com.example.data.model.ExportValidationResult
import com.example.data.model.Lead
import com.example.data.model.ResponsibleSheet
import java.io.StringWriter
import java.nio.charset.StandardCharsets

object LeadExporter {

    /**
     * Validates input vs output before allowing any export.
     * Guaranteed zero data loss.
     */
    fun validateBeforeExport(inputLeads: List<Lead>, outputLeads: List<Lead>): ExportValidationResult {
        val inputCount = inputLeads.size
        val outputCount = outputLeads.size

        val inputPhones = inputLeads.count { it.hasPhone }
        val outputPhones = outputLeads.count { it.hasPhone }
        val lostPhones = (inputPhones - outputPhones).coerceAtLeast(0)

        val inputEmails = inputLeads.count { it.hasEmail }
        val outputEmails = outputLeads.count { it.hasEmail }
        val lostEmails = (inputEmails - outputEmails).coerceAtLeast(0)

        val inputNames = inputLeads.count { it.hasName }
        val outputNames = outputLeads.count { it.hasName }
        val lostNames = (inputNames - outputNames).coerceAtLeast(0)

        val inputCourses = inputLeads.count { it.hasCourse }
        val outputCourses = outputLeads.count { it.hasCourse }
        val lostCourses = (inputCourses - outputCourses).coerceAtLeast(0)

        val blockers = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (outputCount < inputCount) {
            blockers.add("CRÍTICO: A saída possui $outputCount registros, mas a entrada possuía $inputCount. Registros foram perdidos!")
        }

        if (lostPhones > 0) {
            blockers.add("CRÍTICO: $lostPhones número(s) de telefone que existiam na entrada não foram encontrados na saída!")
        }

        if (lostEmails > 0) {
            blockers.add("ALERTA GRAVE: $lostEmails e-mail(s) foram perdidos durante a preparação dos dados!")
        }

        if (lostNames > 0) {
            blockers.add("ALERTA GRAVE: $lostNames nome(s) foram perdidos durante a preparação dos dados!")
        }

        if (lostCourses > 0) {
            blockers.add("CRÍTICO: $lostCourses curso(s)/concurso(s) foram perdidos durante a exportação!")
        }

        val canExport = blockers.isEmpty()

        return ExportValidationResult(
            inputLeadsCount = inputCount,
            outputLeadsCount = outputCount,
            inputPhonesCount = inputPhones,
            outputPhonesCount = outputPhones,
            lostPhones = lostPhones,
            lostEmails = lostEmails,
            lostNames = lostNames,
            lostCourses = lostCourses,
            canExport = canExport,
            blockerReasons = blockers,
            warnings = warnings
        )
    }

    /**
     * Generates a multi-sheet Microsoft Excel Spreadsheet (.xls / XML Spreadsheet 2003).
     * Supported by Microsoft Excel, LibreOffice, Apple Numbers, and Google Sheets.
     * Uses ss:Type="String" for EVERY cell, preventing Excel from stripping leading zeros,
     * converting to scientific notation, or truncating large numbers.
     */
    fun generateExcelXml(
        allLeads: List<Lead>,
        headers: List<String>,
        responsibleSheets: List<ResponsibleSheet>
    ): String {
        val writer = StringWriter()
        writer.append("""<?xml version="1.0" encoding="UTF-8"?>""").append("\n")
        writer.append("""<?mso-application progid="Excel.Sheet"?>""").append("\n")
        writer.append("""<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"""").append("\n")
        writer.append(""" xmlns:o="urn:schemas-microsoft-com:office:office"""").append("\n")
        writer.append(""" xmlns:x="urn:schemas-microsoft-com:office:excel"""").append("\n")
        writer.append(""" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"""").append("\n")
        writer.append(""" xmlns:html="http://www.w3.org/TR/REC-html40">""").append("\n")

        // Styles
        writer.append(""" <Styles>""").append("\n")
        writer.append("""  <Style ss:ID="Header">""").append("\n")
        writer.append("""   <Font ss:Bold="1" ss:Color="#FFFFFF"/>""").append("\n")
        writer.append("""   <Interior ss:Color="#0B2545" ss:Pattern="Solid"/>""").append("\n")
        writer.append("""   <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>""").append("\n")
        writer.append("""  </Style>""").append("\n")
        writer.append("""  <Style ss:ID="TextStyle">""").append("\n")
        writer.append("""   <NumberFormat ss:Format="@"/>""").append("\n")
        writer.append("""  </Style>""").append("\n")
        writer.append("""  <Style ss:ID="DuplicateStyle">""").append("\n")
        writer.append("""   <Interior ss:Color="#FFF3CD" ss:Pattern="Solid"/>""").append("\n")
        writer.append("""   <NumberFormat ss:Format="@"/>""").append("\n")
        writer.append("""  </Style>""").append("\n")
        writer.append(""" </Styles>""").append("\n")

        // Build list of sheets to render:
        // Always include "Todos" as the first sheet
        val sheetsToRender = mutableListOf<ResponsibleSheet>()
        sheetsToRender.add(ResponsibleSheet(sheetName = "Todos", leads = allLeads))
        sheetsToRender.addAll(responsibleSheets.filter { it.sheetName != "Todos" })

        for (sheet in sheetsToRender) {
            val safeSheetName = sanitizeSheetName(sheet.sheetName)
            writer.append(""" <Worksheet ss:Name="$safeSheetName">""").append("\n")
            writer.append("""  <Table>""").append("\n")

            // Header row
            writer.append("""   <Row ss:StyleID="Header">""").append("\n")
            for (h in headers) {
                writer.append("""    <Cell><Data ss:Type="String">${escapeXml(h)}</Data></Cell>""").append("\n")
            }
            writer.append("""    <Cell><Data ss:Type="String">TELEFONE_NORMALIZADO</Data></Cell>""").append("\n")
            writer.append("""    <Cell><Data ss:Type="String">DUPLICADO</Data></Cell>""").append("\n")
            writer.append("""   </Row>""").append("\n")

            // Data rows
            for (lead in sheet.leads) {
                val styleId = if (lead.isDuplicate) "DuplicateStyle" else "TextStyle"
                writer.append("""   <Row ss:StyleID="$styleId">""").append("\n")

                for (h in headers) {
                    val rawVal = lead.rawData[h] ?: when (h.uppercase()) {
                        "NOME" -> lead.name
                        "TELEFONE", "CELULAR", "WHATSAPP" -> lead.originalPhone
                        "EMAIL", "E-MAIL" -> lead.email
                        "CURSO", "CONCURSO", "CURSO / CONCURSO", "CURSO/CONCURSO", "PRODUTO", "ITEM", "ITENS" -> lead.course
                        "TEMPERATURA", "TEMP" -> lead.temperature
                        "OBSERVACAO", "OBSERVAÇÃO", "OBS" -> lead.observation
                        "RESPONSAVEL", "RESPONSÁVEL" -> lead.responsible
                        "STATUS" -> lead.status
                        "CAMPANHA" -> lead.campaign
                        else -> ""
                    }
                    writer.append("""    <Cell><Data ss:Type="String">${escapeXml(rawVal)}</Data></Cell>""").append("\n")
                }

                // Add normalized phone and duplicate status
                writer.append("""    <Cell><Data ss:Type="String">${escapeXml(lead.normalizedPhone)}</Data></Cell>""").append("\n")
                writer.append("""    <Cell><Data ss:Type="String">${if (lead.isDuplicate) "SIM" else "NÃO"}</Data></Cell>""").append("\n")

                writer.append("""   </Row>""").append("\n")
            }

            writer.append("""  </Table>""").append("\n")
            writer.append(""" </Worksheet>""").append("\n")
        }

        writer.append("""</Workbook>""")
        return writer.toString()
    }

    /**
     * Generates a safe CSV with UTF-8 BOM and explicit text escaping for phone columns.
     * Prevents Excel from converting phone numbers into floats or scientific notation.
     */
    fun generateSafeCsv(
        leads: List<Lead>,
        headers: List<String>,
        delimiter: Char = ';'
    ): ByteArray {
        val sb = StringBuilder()
        // UTF-8 BOM for automatic Excel recognition
        sb.append('\uFEFF')

        // Header
        val allHeaders = headers + listOf("TELEFONE_NORMALIZADO", "DUPLICADO")
        sb.append(allHeaders.joinToString(delimiter.toString()) { quoteCsvField(it) }).append("\r\n")

        // Rows
        for (lead in leads) {
            val rowValues = mutableListOf<String>()
            for (h in headers) {
                val value = lead.rawData[h] ?: when (h.uppercase()) {
                    "NOME" -> lead.name
                    "TELEFONE", "CELULAR", "WHATSAPP" -> lead.originalPhone
                    "EMAIL", "E-MAIL" -> lead.email
                    "CURSO", "CONCURSO", "CURSO / CONCURSO", "CURSO/CONCURSO", "PRODUTO", "ITEM", "ITENS" -> lead.course
                    "TEMPERATURA", "TEMP" -> lead.temperature
                    "OBSERVACAO", "OBSERVAÇÃO", "OBS" -> lead.observation
                    "RESPONSAVEL", "RESPONSÁVEL" -> lead.responsible
                    "STATUS" -> lead.status
                    "CAMPANHA" -> lead.campaign
                    else -> ""
                }
                // If this is a phone column, format as Excel text formula to protect leading zeros
                if (h.equals("TELEFONE", ignoreCase = true) || h.equals("CELULAR", ignoreCase = true) || h.equals("WHATSAPP", ignoreCase = true)) {
                    rowValues.add(formatPhoneForCsv(value))
                } else {
                    rowValues.add(quoteCsvField(value))
                }
            }

            // Append normalized phone and duplicate flag
            rowValues.add(formatPhoneForCsv(lead.normalizedPhone))
            rowValues.add(quoteCsvField(if (lead.isDuplicate) "SIM" else "NÃO"))

            sb.append(rowValues.joinToString(delimiter.toString())).append("\r\n")
        }

        return sb.toString().toByteArray(StandardCharsets.UTF_8)
    }

    private fun formatPhoneForCsv(phone: String): String {
        if (phone.isBlank()) return ""
        // ="07999999999" forces Excel to display verbatim as text without losing 0s or doing E+10
        val clean = phone.replace("\"", "\"\"")
        return "\"=\"\"$clean\"\"\""
    }

    private fun quoteCsvField(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return "\"$escaped\""
    }

    private fun sanitizeSheetName(name: String): String {
        val clean = name.replace(Regex("""[/\\?*\[\]:]"""), " ")
            .trim()
            .take(31)
        return if (clean.isEmpty()) "Aba" else clean
    }

    private fun escapeXml(value: String): String {
        return value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
