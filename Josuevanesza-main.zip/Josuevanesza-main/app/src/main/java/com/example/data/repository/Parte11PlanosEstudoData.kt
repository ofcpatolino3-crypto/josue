package com.example.data.repository

import com.example.data.model.*

object Parte11PlanosEstudoData {
    fun getStudyPlans(): List<StudyPlan> {
        return listOf(
            create30DaysPlan(),
            create45DaysPlan(),
            create60DaysPlan(),
            create90DaysPlan()
        )
    }

    private fun create30DaysPlan(): StudyPlan {
        val days = (1..30).map { day ->
            when {
                day % 7 == 0 -> StudyDaySchedule(
                    dayNumber = day,
                    focusSubject = "Simulado e Revisão Semanal",
                    topicsToStudy = listOf("Resolução de Simulado Completo Cesgranrio (60 questões)", "Correção detalhada dos erros no caderno de erros", "Revisão dos resumos e flashcards"),
                    targetTheoryPages = 15,
                    targetQuestions = 60,
                    estimatedHours = 5.0f,
                    revisionItems = listOf("Mapas mentais dos 6 dias anteriores", "Fórmulas de matemática da semana")
                )
                day <= 10 -> StudyDaySchedule(
                    dayNumber = day,
                    focusSubject = "Ciclo 1: Língua Portuguesa + Dutos/Mecânica",
                    topicsToStudy = listOf("Capítulo ${day} de Português (Gramática e Texto)", "Tópicos de Conhecimentos Específicos do Edital"),
                    targetTheoryPages = 20,
                    targetQuestions = 35,
                    estimatedHours = 4.0f,
                    revisionItems = listOf("Revisão de 24h do dia anterior (15 min)")
                )
                day <= 20 -> StudyDaySchedule(
                    dayNumber = day,
                    focusSubject = "Ciclo 2: Matemática + Conhecimentos Específicos",
                    topicsToStudy = listOf("Capítulo ${day - 10} de Matemática (Teoria e Fórmulas)", "Operações de Terminais / Manutenção Industrial"),
                    targetTheoryPages = 22,
                    targetQuestions = 40,
                    estimatedHours = 4.5f,
                    revisionItems = listOf("Revisão semanal acumulada")
                )
                else -> StudyDaySchedule(
                    dayNumber = day,
                    focusSubject = "Ciclo 3: Revisão Turbo + Questões Diárias",
                    topicsToStudy = listOf("Bateria pesada de questões Cesgranrio", "Revisão dos pontos de alto rendimento (SMS, Bombas, Lei das Estatais)"),
                    targetTheoryPages = 25,
                    targetQuestions = 50,
                    estimatedHours = 5.0f,
                    revisionItems = listOf("Checklist de véspera e 100 conceitos de ouro")
                )
            }
        }

        return StudyPlan(
            id = "plano_30_dias",
            title = "Plano Sprint Reta Final — 30 Dias",
            targetHorizonDays = 30,
            recommendedDailyHours = 4.5f,
            description = "Plano acelerado para candidatos em reta final ou que já possuem base teórica e necessitam de foco absoluto em resolução de questões, revisão turbo e simulados semanais.",
            weeklyGoals = listOf(
                "Semana 1: Fechar os 10 capítulos mais cobrados de Português e fundamentos de Específicas.",
                "Semana 2: Dominar Matemática prática Cesgranrio (Porcentagem, Regra de 3, Áreas/Volumes) e Equipamentos Industriais.",
                "Semana 3: Aprofundar SMS, Segurança Operacional, Bombas/Tanques e Lei 13.303/16.",
                "Semana 4: Ciclo Turbo de Simulados, Caderno de Erros e Decoreba de Fórmulas e Mnemônicos."
            ),
            dailySchedules = days
        )
    }

    private fun create45DaysPlan(): StudyPlan {
        val days = (1..45).map { day ->
            StudyDaySchedule(
                dayNumber = day,
                focusSubject = if (day % 2 == 1) "Português e Específicas" else "Matemática e Específicas",
                topicsToStudy = listOf("Estudo do capítulo do dia da apostila digital", "Resolução do bloco de 10 questões com gabarito comentado"),
                targetTheoryPages = 18,
                targetQuestions = 30,
                estimatedHours = 3.5f,
                revisionItems = listOf("Revisão ativa espaçada (24h e 7d)")
            )
        }

        return StudyPlan(
            id = "plano_45_dias",
            title = "Plano Intensivo Estruturado — 45 Dias",
            targetHorizonDays = 45,
            recommendedDailyHours = 3.5f,
            description = "Equilíbrio perfeito entre teoria aprofundada e resolução de questões diárias, com folga programada para revisão de pontos fracos.",
            weeklyGoals = listOf(
                "Semanas 1-2: Varredura completa do módulo de Língua Portuguesa e Dutos Fundamentais.",
                "Semanas 3-4: Fechamento de Matemática e Manutenção Mecânica / Administração.",
                "Semanas 5-6: Treinamento intensivo de simulados oficiais e fixação de pegadinhas Cesgranrio."
            ),
            dailySchedules = days
        )
    }

    private fun create60DaysPlan(): StudyPlan {
        val days = (1..60).map { day ->
            StudyDaySchedule(
                dayNumber = day,
                focusSubject = "Estudo Gradual e Consistente (2 Horas Diárias)",
                topicsToStudy = listOf("Leitura didática de 1 capítulo", "Fixação de fórmulas e resolução de 20 questões"),
                targetTheoryPages = 15,
                targetQuestions = 20,
                estimatedHours = 2.5f,
                revisionItems = listOf("Resumo em tópicos no caderno de estudos")
            )
        }

        return StudyPlan(
            id = "plano_60_dias",
            title = "Plano Regular de Alta Performance — 60 Dias",
            targetHorizonDays = 60,
            recommendedDailyHours = 2.5f,
            description = "Ideal para quem trabalha ou estuda e dispõe de 2 a 3 horas diárias de dedicação com alto aproveitamento e sem sobrecarga cognitiva.",
            weeklyGoals = listOf(
                "Mês 1: Cobertura sólida de 100% da teoria do edital oficial.",
                "Mês 2: Ciclo de 500+ questões resolvidas e simulados quinzenais."
            ),
            dailySchedules = days
        )
    }

    private fun create90DaysPlan(): StudyPlan {
        val days = (1..90).map { day ->
            StudyDaySchedule(
                dayNumber = day,
                focusSubject = "Preparação Completa a Longo Prazo",
                topicsToStudy = listOf("Estudo aprofundado dos capítulos", "Elaboração de mapas mentais próprios e flashcards"),
                targetTheoryPages = 12,
                targetQuestions = 15,
                estimatedHours = 2.0f,
                revisionItems = listOf("Revisão programada de 30 dias")
            )
        }

        return StudyPlan(
            id = "plano_90_dias",
            title = "Plano Extensivo Completo — 90 Dias",
            targetHorizonDays = 90,
            recommendedDailyHours = 2.0f,
            description = "O caminho mais seguro e consistente para gabaritar a prova da Transpetro, construindo base sólida desde os conceitos fundamentais até o nível avançado.",
            weeklyGoals = listOf(
                "Mês 1: Fundamentos de Português, Matemática Básica e Noções Gerais de Petróleo.",
                "Mês 2: Especialização nos tópicos técnicos e normas regulamentadoras (NR-20, NR-33, NR-35, Lei 13.303).",
                "Mês 3: Lapidação final, simulados de 4 horas e domínio dos padrões da Cesgranrio."
            ),
            dailySchedules = days
        )
    }
}
