package com.example.data.repository

import com.example.data.model.ExamSimulation
import com.example.data.model.PracticeQuestion

object Parte10SimuladosData {
    fun getSimulations(): List<ExamSimulation> {
        val allQuestions = Parte8QuestionBankData.getAllQuestions()

        val sim1Questions = allQuestions.take(60)
        val sim2Questions = allQuestions.filter { it.subject in listOf("Língua Portuguesa", "Matemática") }.take(40)
        val sim3Questions = allQuestions.filter { it.subject == "Dutos e Terminais" || it.subject in listOf("Língua Portuguesa", "Matemática") }.take(60)
        val sim4Questions = allQuestions.filter { it.subject == "Manutenção Mecânica" || it.subject in listOf("Língua Portuguesa", "Matemática") }.take(60)
        val sim5Questions = allQuestions.filter { it.subject == "Administração e Controle" || it.subject in listOf("Língua Portuguesa", "Matemática") }.take(60)

        return listOf(
            ExamSimulation(
                id = "simulado_01_geral",
                title = "Simulado 1 — Geral Cesgranrio Transpetro 2026",
                description = "Simulado completo padrão prova oficial: 10 Língua Portuguesa + 10 Matemática + 40 Conhecimentos Específicos com cronômetro de 4 horas.",
                targetRole = "PSP Transpetro — Todos os Cargos de Nível Médio",
                durationMinutes = 240,
                questions = sim1Questions.ifEmpty { allQuestions.take(20) },
                cutoffScore = 70.0f
            ),
            ExamSimulation(
                id = "simulado_02_basico",
                title = "Simulado 2 — Foco Conhecimentos Básicos (Português + Matemática)",
                description = "Treinamento intensivo nos 52 tópicos fundamentais da Cesgranrio para garantir a nota máxima nas disciplinas eliminatórias.",
                targetRole = "Nível Médio / Técnico",
                durationMinutes = 120,
                questions = sim2Questions.ifEmpty { allQuestions.take(20) },
                cutoffScore = 75.0f
            ),
            ExamSimulation(
                id = "simulado_03_dutos",
                title = "Simulado 3 — Ênfase Operação de Dutos e Terminais",
                description = "Simulado direcionado para candidatos de Operação de Dutos, Terminais Terrestres, Aquaviários e Logística Petrolífera.",
                targetRole = "Técnico(a) de Operação e Dutos",
                durationMinutes = 240,
                questions = sim3Questions.ifEmpty { allQuestions.take(20) },
                cutoffScore = 72.0f
            ),
            ExamSimulation(
                id = "simulado_04_mecanica",
                title = "Simulado 4 — Ênfase Manutenção Mecânica Industrial",
                description = "Simulado com foco em Elementos de Máquinas, Soldagem AWS, Bombas, Compressores, Alinhamento a Laser e Preditiva.",
                targetRole = "Técnico(a) de Manutenção — Mecânica",
                durationMinutes = 240,
                questions = sim4Questions.ifEmpty { allQuestions.take(20) },
                cutoffScore = 70.0f
            ),
            ExamSimulation(
                id = "simulado_05_admin",
                title = "Simulado 5 — Ênfase Administração, Suprimentos e Controle",
                description = "Simulado especializado em Gestão de Materiais, Curva ABC/XYZ, Lei das Estatais (Lei 13.303/16), Custos e Compliance.",
                targetRole = "Técnico(a) de Administração e Controle",
                durationMinutes = 240,
                questions = sim5Questions.ifEmpty { allQuestions.take(20) },
                cutoffScore = 75.0f
            )
        )
    }
}
