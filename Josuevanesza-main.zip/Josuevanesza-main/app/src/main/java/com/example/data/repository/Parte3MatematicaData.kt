package com.example.data.repository

import com.example.data.model.*

object Parte3MatematicaData {
    fun getChapters(): List<EBookChapter> {
        val list = mutableListOf<EBookChapter>()

        val rawChapters = listOf(
            Triple(1, "Operações Fundamentais", "Propriedades da adição, subtração, multiplicação, divisão e potenciação em conjuntos numéricos."),
            Triple(2, "Frações e Números Fracionários", "Operações com frações, simplificação, MMC, MDC e resolução de problemas práticos."),
            Triple(3, "Números Decimais e Dízimas", "Transformações de fração em decimal, operações com vírgula e dízimas periódicas simples/compostas."),
            Triple(4, "Razão e Aplicações", "Conceito de razão, escala cartográfica, velocidade média, densidade e vazão volumétrica."),
            Triple(5, "Proporção e Propriedades", "Propriedade fundamental das proporções, cálculo do termo desconhecido e propriedades de soma."),
            Triple(6, "Regra de Três Simples", "Grandezas diretamente e inversamente proporcionais, montagem prática e cálculo."),
            Triple(7, "Regra de Três Composta", "Método das grandezas (flechas) e método direto de Processo vs. Produto."),
            Triple(8, "Porcentagem", "Fatores de aumento (1 + i) e desconto (1 - i), variações percentuais sucessivas e taxas acumuladas."),
            Triple(9, "Juros Simples", "Fórmula J = C · i · t, cálculo de montante e taxas proporcionais equivalentes no regime simples."),
            Triple(10, "Juros Compostos", "Fórmula M = C · (1 + i)^t, capitalização exponencial e comparação prática com juros simples."),
            Triple(11, "Equações do 1º e 2º Graus", "Resolução algébrica, fórmula de Bhaskara, relações de Girard (soma e produto) e modelagem."),
            Triple(12, "Sistemas de Equações", "Método da substituição, método da adição e problemas com duas variáveis em logística."),
            Triple(13, "Problemas Matemáticos Contextualizados", "Estratégia de modelagem de problemas de concurso estilo Cesgranrio com tanques e misturas."),
            Triple(14, "Grandezas Proporcionais", "Divisão em partes diretamente e inversamente proporcionais e coeficientes de rateio."),
            Triple(15, "Unidades de Medida e Conversões", "Sistema Internacional (SI), comprimento, área, volume, massa, capacidade (L e m³) e tempo."),
            Triple(16, "Geometria Plana e Triângulos", "Ângulos, triângulos retângulos, Teorema de Pitágoras e relações métricas fundamentais."),
            Triple(17, "Cálculo de Área de Figuras Planas", "Fórmulas de área: retângulo, quadrado, triângulo, trapézio, losango e círculo (πr²)."),
            Triple(18, "Perímetro e Comprimento de Circunferência", "Soma de lados, perímetro de figuras compostas e comprimento da circunferência (C = 2πr)."),
            Triple(19, "Volume e Capacidade de Sólidos", "Cálculo de volume para paralelepípedos, cilindros (tanques verticais), esferas e cones."),
            Triple(20, "Estatística Básica", "Conceitos de população, amostra, rol, frequência absoluta e frequência relativa."),
            Triple(21, "Médias, Mediana e Moda", "Média aritmética simples, média ponderada, identificação de mediana em rol par/ímpar e moda."),
            Triple(22, "Interpretação de Tabelas", "Leitura crítica de tabelas simples e de dupla entrada com dados operacionais."),
            Triple(23, "Interpretação de Gráficos", "Gráficos de colunas, barras horizontais, setores circulares e gráficos de linhas temporais."),
            Triple(24, "Raciocínio Lógico-Matemático", "Sequências numéricas e de figuras, padrões lógicos, diagramas de Venn e deduções.")
        )

        for ((num, title, desc) in rawChapters) {
            list.add(createMathChapter(num, title, desc))
        }

        return list
    }

    private fun createMathChapter(num: Int, title: String, desc: String): EBookChapter {
        val formulas = getFormulasForChapter(num)
        val theory = getMathTheory(num, title)
        val example = getMathExample(num, title)
        val questions = createSampleMathQuestions(num, title)

        return EBookChapter(
            id = "math_cap_$num",
            partId = "part_3",
            partNumber = 3,
            partTitle = "PARTE 3 — MATEMÁTICA",
            chapterNumber = num,
            title = "Capítulo $num — $title",
            subtitle = desc,
            readTimeMinutes = 15,
            strategicSummary = "A Matemática da Cesgranrio no PSP Transpetro foca em raciocínio prático e rapidez de cálculo sem calculadora.",
            highYieldAlerts = listOf(
                "A banca sempre inclui alternativas baseadas nos erros mais comuns (ex: esquecer de inverter grandezas na regra de três ou somar porcentagens sucessivas diretamente).",
                "Domine a conversão rápida de unidades: 1 m³ = 1.000 Litros; 1 barril ≈ 159 Litros; 1 tonelada = 1.000 kg."
            ),
            examTraps = listOf(
                "Aumento e desconto de mesma taxa percentual: Se um preço sobe 20% e depois cai 20%, o valor final NÃO volta ao original (fica 4% menor: 1,20 × 0,80 = 0,96).",
                "Na média ponderada, esquecer de dividir pela SOMA DOS PESOS e dividir pela quantidade de itens."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Teoria e Fórmulas Fundamentais",
                    body = theory,
                    formulas = formulas,
                    bulletPoints = listOf(
                        "Fórmulas consagradas para resolução direta sem perda de tempo.",
                        "Identificação das variáveis do problema e alinhamento de unidades.",
                        "Métodos de simplificação fracionária antes da multiplicação."
                    ),
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO NO CÁLCULO (SEM CALCULADORA)",
                            content = "Na prova você não terá calculadora! Treine contas à mão todos os dias e utilize a técnica da fatoração e simplificação de frações para não multiplicar números gigantes à toa.",
                            iconType = "FORMULA"
                        )
                    )
                ),
                ContentSection(
                    title = "2. Exemplo Resolvido Passo a Passo",
                    body = "Veja como modelar uma questão típica da Fundação Cesgranrio:",
                    practicalExamples = listOf(example)
                )
            ),
            questions = questions
        )
    }

    private fun getMathTheory(num: Int, title: String): String {
        return when (num) {
            6 -> """A Regra de Três Simples relaciona duas grandezas dependentes.

Passo a Passo para Resolver com 100% de Certeza:
1. Monte a tabela identificando claramente as grandezas e suas unidades.
2. Analise se as grandezas são Diretamente ou Inversamente Proporcionais:
   - DIRETAS: Se uma grandeza AUMENTA, a outra também AUMENTA na mesma proporção (Multiplica-se em CRUZ: a/b = c/d).
   - INVERSAS: Se uma grandeza AUMENTA, a outra DIMINUI na mesma proporção (Multiplica-se em LINHA RETA: a · b = c · d).
Exemplos clássicos:
• Vazão da bomba e Tempo de enchimento do tanque: INVERSAS (bomba com maior vazão gasta MENOS tempo).
• Consumo de diesel e Distância percorrida pelo navio: DIRETAS (maior distância gasta MAIS combustível)."""

            8 -> """A Porcentagem é uma fração de denominador 100.

1. Fator Multiplicativo (Técnica dos Campeões):
• Aumento de i%: Multiplica por (1 + i/100). Exemplo: Aumento de 15% → multiplicar por 1,15.
• Desconto de i%: Multiplica por (1 - i/100). Exemplo: Desconto de 25% → multiplicar por 0,75.
2. Aumentos e Descontos Sucessivos:
• Nunca some nem subtraia porcentagens diretamente!
• Multiplique os fatores: F_final = F1 × F2 × ... × Fn.
Exemplo: Um reajuste de +10% seguido de +20% resulta em: 1,10 × 1,20 = 1,32 (Aumento real de 32%, e não 30%!)."""

            9, 10 -> """Noções de Juros Simples e Compostos.

1. Juros Simples:
• Os juros incidem SEMPRE sobre o capital inicial C.
• Fórmulas: J = C · i · t e M = C + J = C · (1 + i · t).
• A taxa i e o tempo t DEVEM estar na MESMA unidade temporal (taxa ao mês com tempo em meses).

2. Juros Compostos (Juros sobre Juros):
• Os juros de cada período são incorporados ao capital para render no período seguinte.
• Fórmula do Montante: M = C · (1 + i)^t.
• O crescimento é exponencial, ao passo que no juro simples o crescimento é linear."""

            17, 19 -> """Geometria: Áreas e Volumes de Instalações Industriais.

1. Áreas de Superfície:
• Retângulo: A = b · h
• Quadrado: A = L²
• Triângulo: A = (b · h) / 2
• Trapézio: A = [(B + b) · h] / 2
• Círculo: A = π · r² (comprimento da borda: C = 2 · π · r)

2. Volumes de Armazenamento:
• Cilindro Reto (Tanque de Petróleo): V = Área da Base × Altura = π · r² · h
• Paralelepípedo Reto: V = a · b · c (comprimento × largura × altura)
• Esfera (Tanque de GLP): V = (4/3) · π · r³
Relação Fundamental de Capacidade: 1 m³ = 1.000 Litros; 1 dm³ = 1 Litro; 1 cm³ = 1 mL."""

            21 -> """Estatística Descritiva: Médias, Mediana e Moda.

1. Média Aritmética Simples:
   x̄ = (x₁ + x₂ + ... + xₙ) / n
2. Média Ponderada:
   x̄_p = (x₁ · p₁ + x₂ · p₂ + ... + xₙ · pₙ) / (p₁ + p₂ + ... + pₙ)
3. Mediana (Me):
   - Primeiro passo OBRIGATÓRIO: Organizar os dados em ordem crescente (ROL).
   - Se a quantidade n de elementos for ÍMPAR: é o valor central exato.
   - Se a quantidade n for PAR: é a média aritmética dos dois valores centrais.
4. Moda (Mo): O valor que aparece com maior frequência no conjunto."""

            else -> """O assunto $title requer domínio da fundamentação matemática e aplicação estruturada de regras operacionais.

Dicas para o estudo:
• Sempre desenhe o problema ou esquematize os dados antes de iniciar os cálculos.
• Preste atenção na pergunta final (muitas vezes a Cesgranrio pergunta a diferença ou a porcentagem restante, e não o valor direto)."""
        }
    }

    private fun getFormulasForChapter(num: Int): List<FormulaItem> {
        return when (num) {
            6, 7 -> listOf(
                FormulaItem("Regra de Três Direta", "a / b = c / d  ⇒  a · d = b · c", "a, b, c: termos conhecidos; d: incógnita", "Multiplicação cruzada para grandezas de mesmo sentido."),
                FormulaItem("Regra de Três Inversa", "a · b = c · d  ⇒  d = (a · b) / c", "a, b: linha 1; c, d: linha 2", "Multiplicação linear para grandezas que variam em sentidos opostos.")
            )
            8 -> listOf(
                FormulaItem("Fator de Aumento", "F = 1 + (i / 100)", "i: taxa percentual de aumento", "Multiplique o valor inicial pelo fator para obter o valor com acréscimo."),
                FormulaItem("Fator de Desconto", "F = 1 - (i / 100)", "i: taxa percentual de desconto", "Multiplique pelo fator para encontrar o valor líquido pós-desconto.")
            )
            9 -> listOf(
                FormulaItem("Juros Simples", "J = C · i · t", "C: capital; i: taxa unitária; t: tempo", "i e t devem estar no mesmo período temporal."),
                FormulaItem("Montante Simples", "M = C + J = C · (1 + i · t)", "M: valor acumulado final", "Crescimento linear do capital.")
            )
            10 -> listOf(
                FormulaItem("Montante Composto", "M = C · (1 + i)^t", "C: capital inicial; i: taxa por período; t: número de períodos", "Crescimento exponencial (juros sobre juros).")
            )
            17, 19 -> listOf(
                FormulaItem("Volume do Tanque Cilíndrico", "V = π · r² · h", "r: raio da base cilíndrica; h: altura ou nível do líquido", "Para obter o resultado em Litros, converta m³ multiplicando por 1.000."),
                FormulaItem("Área do Círculo", "A = π · r²", "r: raio do círculo (r = diâmetro / 2)", "Utilize π ≈ 3,14 quando solicitado pela banca.")
            )
            21 -> listOf(
                FormulaItem("Média Ponderada", "x̄_p = Σ(x_i · p_i) / Σ(p_i)", "x_i: valores; p_i: respectivos pesos", "Sempre divida pela soma de todos os pesos!")
            )
            else -> emptyList()
        }
    }

    private fun getMathExample(num: Int, title: String): PracticalExampleData {
        return when (num) {
            19 -> PracticalExampleData(
                scenario = "Um tanque vertical cilíndrico em um terminal da Transpetro possui raio da base igual a 10 metros e altura útil de 12 metros. Considerando π = 3,14, determine a capacidade total desse tanque em Litros.",
                stepByStepSolution = """Passo 1: Aplicar a fórmula do volume do cilindro:
V = π · r² · h
V = 3,14 · (10 m)² · 12 m
V = 3,14 · 100 · 12 = 314 · 12 = 3.768 m³

Passo 2: Converter metros cúbicos para Litros (sabendo que 1 m³ = 1.000 L):
Capacidade = 3.768 × 1.000 = 3.768.000 Litros (ou 3.768 m³).""",
                keyTakeaway = "Lembre-se sempre de elevar o raio ao quadrado antes de multiplicar pela altura e pelo valor de π."
            )
            8 -> PracticalExampleData(
                scenario = "O custo operacional de bombeamento de um oleoduto sofreu um aumento de 15% em janeiro devido ao custo da energia elétrica. Em fevereiro, graças a um programa de eficiência energética, houve uma redução de 10% sobre o novo valor. Qual foi a variação percentual real acumulada no bimestre?",
                stepByStepSolution = """Passo 1: Determinar o fator do aumento de 15%:
F1 = 1 + 0,15 = 1,15

Passo 2: Determinar o fator do desconto de 10%:
F2 = 1 - 0,10 = 0,90

Passo 3: Multiplicar os fatores sucessivos:
F_final = 1,15 × 0,90 = 1,035

Passo 4: Interpretar o resultado:
Variação = (1,035 - 1) × 100% = +3,5% de aumento real.""",
                keyTakeaway = "Nunca faça 15% - 10% = 5%! Em variações sucessivas, a resposta correta é obtida multiplicando os fatores (resultando em +3,5%)."
            )
            else -> PracticalExampleData(
                scenario = "Resolução prática de problema sobre $title em contexto de concurso público da Transpetro.",
                stepByStepSolution = "1. Listar os dados fornecidos pelo enunciado; 2. Alinhar as unidades de medida; 3. Isolar a variável incógnita; 4. Conferir a resolução numérica.",
                keyTakeaway = "Verifique sempre se as unidades de tempo, comprimento e volume estão perfeitamente compatibilizadas."
            )
        }
    }

    private fun createSampleMathQuestions(chapNum: Int, title: String): List<PracticeQuestion> {
        return listOf(
            PracticeQuestion(
                id = "math_q_${chapNum}_1",
                code = "MAT-$chapNum-01",
                subject = "Matemática",
                topic = title,
                difficulty = "Médio",
                statement = "Uma bomba centrífuga de alta vazão opera na transferência de óleo diesel transferindo 450 m³ em 3 horas contínuas. Se forem acionadas 3 bombas idênticas operando simultaneamente com a mesma taxa de eficiência, quanto tempo levará para transferir um lote de 1.800 m³ de diesel?",
                options = listOf(
                    "A) 2 horas",
                    "B) 3 horas",
                    "C) 4 horas",
                    "D) 5 horas",
                    "E) 6 horas"
                ),
                correctIndex = 2,
                detailedExplanation = "Vazão de 1 bomba: 450 m³ / 3 h = 150 m³/h. Com 3 bombas em paralelo, a vazão conjunta é de 3 × 150 m³/h = 450 m³/h. Para transferir 1.800 m³: Tempo = 1.800 m³ / 450 m³/h = 4 horas.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: 2 horas resultaria em apenas 900 m³ transferidos.",
                    1 to "Incorreto: 3 horas transferiria 1.350 m³.",
                    3 to "Incorreto: 5 horas transferiria 2.250 m³.",
                    4 to "Incorreto: 6 horas seria o tempo se houvesse apenas 2 bombas."
                ),
                highYieldTip = "Em associação de bombas em paralelo com vazões idênticas, basta somar as vazões individuais (Q_total = Q1 + Q2 + ... + Qn)."
            ),
            PracticeQuestion(
                id = "math_q_${chapNum}_2",
                code = "MAT-$chapNum-02",
                subject = "Matemática",
                topic = title,
                difficulty = "Difícil",
                statement = "Um lote de tubos de aço para gasoduto sofreu um reajuste de 20% no primeiro trimestre e, no segundo trimestre, devido a incentivos fiscais, teve um desconto de 15% sobre o preço reajustado. Se o preço final passou a ser de R$ 102.000,00, qual era o preço original do lote antes do primeiro reajuste?",
                options = listOf(
                    "A) R$ 90.000,00",
                    "B) R$ 95.000,00",
                    "C) R$ 98.000,00",
                    "D) R$ 100.000,00",
                    "E) R$ 105.000,00"
                ),
                correctIndex = 3,
                detailedExplanation = "Fator 1 (aumento 20%): 1,20. Fator 2 (desconto 15%): 0,85. Fator acumulado = 1,20 × 0,85 = 1,02. Preço Final = Preço Inicial × 1,02 ⇒ 102.000 = P_0 × 1,02 ⇒ P_0 = 102.000 / 1,02 = R$ 100.000,00.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: 90.000 × 1,02 = 91.800.",
                    1 to "Incorreto: 95.000 × 1,02 = 96.900.",
                    2 to "Incorreto: 98.000 × 1,02 = 99.960.",
                    4 to "Incorreto: O valor original antes do aumento não poderia ser maior do que o preço com variação positiva de 2%."
                ),
                highYieldTip = "Para desfazer aumentos/descontos sucessivos e voltar ao valor inicial, NUNCA aplique as porcentagens inversas somadas; sempre divida pelo produto dos fatores (P_inicial = P_final / Fator_total)."
            )
        )
    }
}
