package com.example.data.repository

import com.example.data.model.*

object Parte2PortuguesData {
    fun getChapters(): List<EBookChapter> {
        val list = mutableListOf<EBookChapter>()

        val rawChapters = listOf(
            Triple(1, "Interpretação de Textos", "Identificação de teses, pressupostos, subentendidos e intenção discursiva do autor."),
            Triple(2, "Compreensão Textual", "Diferenciação crítica entre 'o que o texto diz' (compreensão) e 'o que se infere' (interpretação)."),
            Triple(3, "Tipologia Textual", "Texto narrativo, descritivo, dissertativo-argumentativo, expositivo e injuntivo."),
            Triple(4, "Gêneros Textuais", "Artigo de opinião, editorial, crônica, relatório técnico, instrução de trabalho e notícia."),
            Triple(5, "Coesão Textual", "Coesão referencial (anáfora, catáfora), sequencial e operadores argumentativos."),
            Triple(6, "Coerência Textual", "Não contradição, continuidade temática, progressão de ideias e informatividade."),
            Triple(7, "Semântica", "Denotação e conotação, sinonímia, antonímia, polissemia, homonímia, paronímia e hiperonímia."),
            Triple(8, "Significação das Palavras", "Sentido contextual, ambiguidade, duplo sentido e figuras de linguagem."),
            Triple(9, "Classes Gramaticais", "Identificação morfológica, funções semânticas e flexões das 10 classes de palavras."),
            Triple(10, "Pronomes", "Pronomes pessoais, possessivos, demonstrativos (espaço/tempo/discurso), relativos e indefinidos."),
            Triple(11, "Verbos e Tempos Verbais", "Modos indicativo, subjuntivo e imperativo, correlação temporal e vozes verbais."),
            Triple(12, "Advérbios e Locuções", "Circunstâncias adverbiais, modificadores de adjetivos/verbos e valor argumentativo."),
            Triple(13, "Preposições", "Valores relacionais, preposições essenciais e acidentais, regência e relações de sentido."),
            Triple(14, "Conjunções e Conectivos", "Conjunções coordenativas e subordinativas, tabela completa e equivalência semântica."),
            Triple(15, "Pontuação", "Uso da vírgula (casos obrigatórios, proibidos e facultativos), ponto e vírgula, travessões e dois-pontos."),
            Triple(16, "Concordância Verbal", "Casos especiais: sujeito composto, pronome apassivador 'se', índice de indeterminação, porcentagem."),
            Triple(17, "Concordância Nominal", "Regras para adjetivo posposto/anteposto, palavras 'anexo', 'bastante', 'meio', 'menos', 'é proibido'."),
            Triple(18, "Regência Verbal", "Verbos de alta incidência: assistir, aspirar, visar, obedecer, preferir, esquecer/lembrar, implicar."),
            Triple(19, "Regência Nominal", "Substantivos e adjetivos transitivos e suas preposições obrigatórias."),
            Triple(20, "Crase", "Casos proibidos, obrigatórios, facultativos e pegadinhas de paralelismo sintático."),
            Triple(21, "Colocação Pronominal", "Próclise (fatores de atração), mesóclise e ênclise segundo a norma culta."),
            Triple(22, "Ortografia Oficial", "Regras ortográficas, uso do 'porquê/por que/por quê/porque', mal/mau, onde/aonde, hífen."),
            Triple(23, "Acentuação Gráfica", "Regras das oxítonas, paroxítonas, proparoxítonas, hiatos e o Novo Acordo Ortográfico."),
            Triple(24, "Estrutura e Formação de Palavras", "Derivação (prefixal, sufixal, parassintética, imprópria, regressiva) e composição."),
            Triple(25, "Reescrita de Frases", "Correção gramatical, preservação do sentido original e paralelismo sintático."),
            Triple(26, "Relações de Sentido", "Causa vs. consequência, concessão vs. adversidade, condição, proporção e finalidade."),
            Triple(27, "Variação Linguística", "Variação diatópica (regional), diastrática (social), diafásica (registro) e norma culta."),
            Triple(28, "Funções da Linguagem", "Função referencial, emotiva, conativa/apelativa, fática, metalinguística e poética.")
        )

        for ((num, title, desc) in rawChapters) {
            list.add(
                createPortugueseChapter(num, title, desc)
            )
        }

        return list
    }

    private fun createPortugueseChapter(num: Int, title: String, desc: String): EBookChapter {
        val questions = createSamplePortugueseQuestions(num, title)
        val theoryDetails = getTheoryForChapter(num, title)
        val trapDetails = getTrapForChapter(num, title)
        val tables = getTablesForChapter(num)

        return EBookChapter(
            id = "port_cap_$num",
            partId = "part_2",
            partNumber = 2,
            partTitle = "PARTE 2 — LÍNGUA PORTUGUESA",
            chapterNumber = num,
            title = "Capítulo $num — $title",
            subtitle = desc,
            readTimeMinutes = 14,
            strategicSummary = "O domínio de $title na Cesgranrio exige atenção às sutilezas semânticas e à norma-padrão aplicada ao contexto comunicativo.",
            highYieldAlerts = listOf(
                "A banca Cesgranrio costuma cobrar $title com alternativas que parecem corretas pelo senso comum, mas violam a norma culta formal.",
                "Sempre reescreva o trecho do texto e identifique o sujeito sintático antes de responder questões de concordância ou regência."
            ),
            examTraps = listOf(
                trapDetails.trapDescription,
                "Substituição de conectivos: trocar uma conjunção concessiva (embora) por uma adversativa (mas) altera a hierarquia sintática oracional."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Fundamentos Teóricos e Conceitos Essenciais",
                    body = theoryDetails,
                    bulletPoints = listOf(
                        "Aplicação rigorosa da norma culta contemporânea.",
                        "Identificação de efeitos de sentido contextuais.",
                        "Relações sintático-semânticas no período composto."
                    ),
                    tables = tables,
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA (CESGRANRIO)",
                            content = "Na prova da Transpetro, a Cesgranrio valoriza a clareza e a precisão do discurso técnico-administrativo. Termos polissêmicos ou conectivos oracionais são os alvos favoritos para montar distratores sutis.",
                            iconType = "ALERT"
                        )
                    ),
                    examTraps = listOf(trapDetails)
                ),
                ContentSection(
                    title = "2. Análise Prática e Aplicação em Contexto",
                    body = "Observe como a banca Cesgranrio formula itens sobre $title a partir de pequenos trechos dissertativos e crônicas corporativas:",
                    practicalExamples = listOf(
                        PracticalExampleData(
                            scenario = "Análise de assertiva sobre $title em contexto de segurança operacional.",
                            stepByStepSolution = "1. Isolar o núcleo oracional; 2. Verificar a transitividade do verbo ou o termo antecedente; 3. Confirmar se a reescrita preserva o sentido exato sem introduzir incorreção sintática.",
                            keyTakeaway = "Nunca confie apenas na sonoridade da frase ('o que soa bem'). Aplique a regra gramatical formal."
                        )
                    )
                )
            ),
            questions = questions
        )
    }

    private fun getTheoryForChapter(num: Int, title: String): String {
        return when (num) {
            1 -> """A Interpretação de Textos envolve a capacidade de apreender não apenas o que está explicitamente dito, mas também os pressupostos e subentendidos construídos pelo autor.

Na Cesgranrio, as questões de interpretação testam:
1. Ideia central e teses defendidas pelo autor.
2. Argumentos de autoridade, dados estatísticos e relações causais.
3. Posicionamento ideológico, tom do texto (irônico, formal, crítico, conciliador).
4. Inferências válidas (deduções lógicas amparadas no texto) vs. Extrapolação (adicionar informações de fora) ou Redução (focar em detalhe secundário)."""

            5 -> """A Coesão Textual é a ligação formal entre os elementos de uma frase ou entre os parágrafos de um texto. 

Divide-se primordialmente em:
• Coesão Referencial: Mecanismo pelo qual um termo remete a outro.
  - Anáfora: Recupera termo anterior ('O oleoduto foi inspecionado. Ele opera normalmente').
  - Catáfora: Antecipa termo posterior ('Isto é fundamental: a segurança operacional').
  - Elipse/Zeugma: Omissão de termo facilmente recuperável.
• Coesão Sequencial: Garante a progressão temporal e lógica do texto por meio de conectivos, tempos verbais e operadores discursivos."""

            14 -> """As Conjunções são palavras invariáveis que ligam orações ou termos de mesma função sintática. A Cesgranrio prioriza a semântica dos conectivos.

1. Conjunções Coordenativas:
• Aditivas: e, nem, não só... mas também.
• Adversativas (Oposição): mas, porém, contudo, todavia, entretanto, no entanto.
• Alternativas: ou... ou, ora... ora, quer... quer.
• Conclusivas: portanto, logo, por conseguinte, pois (posposto ao verbo).
• Explicativas: porque, que, porquanto, pois (anteposto ao verbo).

2. Conjunções Subordinativas Adverbiais:
• Concessivas (Rompimento de expectativa sem impedir a ação): embora, conquanto, ainda que, mesmo que, se bem que, posto que, apesar de que.
• Causais: porque, como (no início da frase), visto que, já que, uma vez que.
• Condicionais: se, caso, desde que, contanto que.
• Conformativas: conforme, segundo, consoante, como.
• Consecutivas (Consequência): tanto que, de modo que, de forma que."""

            15 -> """A Pontuação, especialmente a vírgula, organiza a estrutura sintática da oração e não depende de 'pausas para respirar'.

Regra Fundamental: NUNCA se separa por vírgula:
1. O Sujeito do seu Verbo ('Os operadores da Transpetro [sem vírgula] realizaram o teste').
2. O Verbo dos seus Complementos Diretos ou Indiretos ('O sistema indicou [sem vírgula] a pressão no gasoduto').
3. O Substantivo do seu Adjunto Adnominal ou Complemento Nominal.

Usos Obrigatórios da Vírgula:
• Separar adjunto adverbial deslocado de média/grande extensão ('Durante a madrugada de ontem, a equipe...')
• Isolar aposto explicativo e vocativo.
• Isolar orações subordinadas adjetivas explicativas.
• Separar orações coordenadas assindéticas ou sindéticas adversativas/conclusivas."""

            16 -> """A Concordância Verbal trata da harmonia entre o verbo e o sujeito em número e pessoa.

Casos de Altíssima Incidência na Cesgranrio:
1. Partícula 'SE' como Pronome Apassivador (VTD ou VTDI + SE):
   - O verbo concorda com o sujeito paciente!
   - Exemplo: 'Verificou-se o duto' (singular) / 'Verificaram-se os dutos' (plural).
2. Partícula 'SE' como Índice de Indeterminação do Sujeito (VTI, VI ou VL + SE):
   - O verbo fica OBRIGATORIAMENTE na 3ª pessoa do singular!
   - Exemplo: 'Precisa-se de novos técnicos' (e não 'precisam-se').
3. Verbos Impessoais (Haver com sentido de existir/ocorrer e Fazer indicando tempo decorrido):
   - Ficam SEMPRE no singular!
   - Exemplo: 'Havia dez tanques no terminal' (e nunca 'Haviam dez tanques').
   - Exemplo: 'Faz dois anos que ingressei na empresa' (e nunca 'Fazem dois anos')."""

            20 -> """A Crase é a fusão da preposição 'A' com o artigo feminino 'A' ou pronomes demonstrativos (aquele, aquela, aquilo).

Casos PROIBIDOS de Crase:
• Antes de palavras masculinas ('Andar a pé', 'Vendeu a prazo').
• Antes de verbos ('Estava a reclamar').
• Antes de pronomes de tratamento (exceto senhora, senhorita e dona).
• Entre palavras repetidas ('dia a dia', 'gota a gota').
• Com o 'a' no singular diante de palavra no plural ('Refiro-me a normas técnicas').

Casos OBRIGATÓRIOS de Crase:
• Locuções adverbiais femininas ('à noite', 'às pressas', 'à medida que').
• Termos que exigem preposição 'a' + substantivo feminino determinado ('Fomos à estação de bombeamento').
• Na expressão 'à moda de' (mesmo que a palavra moda esteja oculta: 'bife à milanesa').

Casos FACULTATIVOS de Crase:
• Antes de nomes próprios femininos ('Entreguei o relatório à/a Mariana').
• Antes de pronomes possessivos femininos no singular ('Refiro-me à/a minha equipe').
• Depois da preposição 'até' ('Caminhou até à/a base de carregamento')."""

            else -> """O tópico $title é cobrado de forma contextualizada pela Cesgranrio. É essencial compreender as definições teóricas, as estruturas sintáticas associadas e as exceções clássicas consagradas pela gramática normativa contemporânea.

Pontos-Chave para Fixação:
• Verifique sempre a transitividade e a regência exigida pelo padrão culto.
• Desmonte períodos longos em orações simples para identificar os termos essenciais.
• Preste atenção nas transformações de orações desenvolvidas em reduzidas."""
        }
    }

    private fun getTrapForChapter(num: Int, title: String): ExamTrapData {
        return when (num) {
            16 -> ExamTrapData(
                title = "Pegadinha clássica: 'Haver' como existir vs. 'Existir'",
                trapDescription = "A banca usa 'Haviam muitos problemas' como se estivesse correto, ou flexiona o verbo auxiliar em locuções impessoais ('Iam haver muitos testes').",
                howToAvoid = "O verbo haver com sentido de existir é impessoal e não tem plural. Em locuções, ele transmite sua impessoalidade ao auxiliar: 'Ia haver muitos testes'."
            )
            20 -> ExamTrapData(
                title = "Pegadinha de Crase com 'A' singular antes de plural",
                trapDescription = "Apresentar frases como 'Prestou homenagem à mulheres heroicas' e induzir o candidato ao erro.",
                howToAvoid = "Se o 'A' está no singular e o substantivo feminino está no plural, ocorreu apenas preposição, SEM artigo. Logo, crase é proibida ('a mulheres'). Para haver crase, deve estar no plural: 'às mulheres'."
            )
            14 -> ExamTrapData(
                title = "Pegadinha com a conjunção 'Como'",
                trapDescription = "A palavra 'como' pode ter valor causal ('Como estava chovendo, não fomos'), conformativo ('Como disse o diretor...'), comparativo ('Rápido como um raio') ou aditivo ('Não só trabalha como estuda').",
                howToAvoid = "Substitua a palavra por conectivos unívocos: 'Já que' (causa), 'Conforme' (conformidade) ou 'Tal qual' (comparação)."
            )
            else -> ExamTrapData(
                title = "Pegadinha de $title na Cesgranrio",
                trapDescription = "Construção de frases com ambiguidade sintática proposital ou termos intercalados para confundir o candidato.",
                howToAvoid = "Isole os termos intercalados entre vírgulas e conecte diretamente o sujeito ao predicado principal."
            )
        }
    }

    private fun getTablesForChapter(num: Int): List<TableItem> {
        return if (num == 14) {
            listOf(
                TableItem(
                    title = "Tabela Rápida de Conjunções Subordinativas Mais Cobradas",
                    headers = listOf("Classificação", "Principais Conectivos", "Exemplo Prático Transpetro"),
                    rows = listOf(
                        listOf("Causal", "porque, visto que, já que, como (início)", "Como o duto atingiu a pressão máxima, a bomba foi desativada."),
                        listOf("Concessiva", "embora, conquanto, ainda que, apesar de", "Embora o mar estivesse agitado, a atracação foi segura."),
                        listOf("Condicional", "se, caso, contanto que, desde que", "Caso ocorra variação de vazão, acione o CCO."),
                        listOf("Conformativa", "conforme, segundo, consoante, como", "A operação seguiu conforme o procedimento operacional."),
                        listOf("Proporcional", "à medida que, à proporção que, quanto mais", "À medida que a temperatura subia, a densidade diminuía.")
                    )
                )
            )
        } else if (num == 20) {
            listOf(
                TableItem(
                    title = "Quadro Mnemônico da Crase",
                    headers = listOf("Situação", "Regra Prática", "Exemplo"),
                    rows = listOf(
                        listOf("Antes de Masculino", "PROIBIDA", "Pagamento a prazo / Envio a diesel"),
                        listOf("Antes de Verbo", "PROIBIDA", "Disposto a colaborar"),
                        listOf("Pronome de Tratamento", "PROIBIDA (exceto senhora/dona)", "Dirijo-me a Vossa Senhoria"),
                        listOf("Locução Feminina", "OBRIGATÓRIA", "À noite, à deriva, à medida que"),
                        listOf("Topônimos (Cidades)", "Volto DA, crase HÁ; Volto DE, crase PRA QUÊ?", "Vou à Bahia (Volto da Bahia) / Vou a Paris (Volto de Paris)")
                    )
                )
            )
        } else {
            emptyList()
        }
    }

    private fun createSamplePortugueseQuestions(chapNum: Int, title: String): List<PracticeQuestion> {
        return listOf(
            PracticeQuestion(
                id = "port_q_${chapNum}_1",
                code = "PORT-$chapNum-01",
                subject = "Língua Portuguesa",
                topic = title,
                difficulty = "Médio",
                statement = "Considere a norma-padrão da Língua Portuguesa quanto ao emprego de $title no trecho: 'A equipe técnica da Transpetro analisou os parâmetros operacionais e concluiu que as diretrizes foram rigorosamente seguidas durante a manobra.' Assinale a alternativa que mantém a correção gramatical e o sentido original.",
                options = listOf(
                    "A) As diretrizes foram seguidas rigorosamente segundo a conclusão da equipe técnica.",
                    "B) Seguiu-se rigorosamente as diretrizes segundo a conclusão da equipe técnica.",
                    "C) Haviam diretrizes que a equipe técnica concluiu que foram seguidas.",
                    "D) A equipe técnica concluiu a cerca de diretrizes que foram seguidas.",
                    "E) Ocorreu a conclusão que as diretrizes foram seguidas sem falhas."
                ),
                correctIndex = 0,
                detailedExplanation = "A alternativa A mantém a exata concordância verbal ('as diretrizes foram seguidas'), a correta regência e a fidelidade ao sentido do texto original.",
                incorrectOptionsExplanation = mapOf(
                    1 to "Incorreto: 'Seguiu-se as diretrizes' apresenta erro de concordância; com partícula apassivadora, o correto é 'Seguiram-se as diretrizes'.",
                    2 to "Incorreto: 'Haviam' no sentido de existir é impessoal e deve ficar no singular ('Havia').",
                    3 to "Incorreto: 'a cerca de' significa 'aproximadamente'; o correto seria 'acerca de' (a respeito de).",
                    4 to "Incorreto: Falta a preposição 'de' regida pelo substantivo 'conclusão' ('a conclusão de que')."
                ),
                highYieldTip = "Em questões de reescrita, elimine primeiro as alternativas que violam concordância ou regência básica antes de avaliar o sentido."
            ),
            PracticeQuestion(
                id = "port_q_${chapNum}_2",
                code = "PORT-$chapNum-02",
                subject = "Língua Portuguesa",
                topic = title,
                difficulty = "Difícil",
                statement = "Em relação aos padrões formais de $title preconizados pela Fundação Cesgranrio, assinale a opção inteiramente correta:",
                options = listOf(
                    "A) Não se deve atribuir à falhas operacionais o atraso na descarga do navio petroleiro.",
                    "B) O supervisor assistiu o operador no alinhamento das válvulas da estação de bombeamento.",
                    "C) Informou ao Centro de Controle Operacional sobre a pressão anormal no oleoduto.",
                    "D) Fazem mais de cinco anos que o terminal aquaviário opera sem acidentes com afastamento.",
                    "E) Os técnicos a cujos relatórios tivemos acesso demonstraram total domínio do processo."
                ),
                correctIndex = 4,
                detailedExplanation = "A alternativa E está perfeita: o pronome relativo 'cujos' concorda com o substantivo consequente ('relatórios') e a preposição 'a' é legitimamente exigida pelo termo 'acesso' ('acesso a').",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: 'à falhas' apresenta crase indevida (o 'a' está no singular antes de substantivo no plural).",
                    1 to "Incorreto: O verbo assistir no sentido de prestar auxílio/ajuda admite objeto direto ('assistiu o operador') ou indireto, mas em concursos da Cesgranrio no sentido de ver/presenciar exige preposição 'a'.",
                    2 to "Incorreto: O verbo informar é VTDI (informa alguém DE algo ou algo A alguém); o uso de 'a' + 'sobre' gera bitransitividade indireta espúria.",
                    3 to "Incorreto: O verbo fazer indicando tempo decorrido é impessoal ('Faz mais de cinco anos')."
                ),
                highYieldTip = "O pronome 'cujo' nunca aceita artigo após si (cujo o, cuja a são aberrações gramaticais) e deve concordar em gênero e número com a coisa possuída."
            )
        )
    }
}
