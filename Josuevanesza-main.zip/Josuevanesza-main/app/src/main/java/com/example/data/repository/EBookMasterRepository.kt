package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object EBookMasterRepository {

    private val _modules = MutableStateFlow<List<EBookModule>>(emptyList())
    val modules: StateFlow<List<EBookModule>> = _modules.asStateFlow()

    private val _completedChapters = MutableStateFlow<Set<String>>(emptySet())
    val completedChapters: StateFlow<Set<String>> = _completedChapters.asStateFlow()

    private val _favoriteChapterIds = MutableStateFlow<Set<String>>(emptySet())
    val favoriteChapterIds: StateFlow<Set<String>> = _favoriteChapterIds.asStateFlow()

    private val _userQuizAnswers = MutableStateFlow<Map<String, Int>>(emptyMap())
    val userQuizAnswers: StateFlow<Map<String, Int>> = _userQuizAnswers.asStateFlow()

    init {
        loadAllContent()
    }

    private fun loadAllContent() {
        val list = mutableListOf<EBookModule>()

        // Modulo 1: Apresentação & Metodologia
        list.add(
            EBookModule(
                id = "mod_1",
                moduleNumber = 1,
                title = "PARTE 1 — APRESENTAÇÃO & EDITAL 003/2026",
                subtitle = "Visão Geral da Transpetro, Estrutura do Processo Seletivo e Método de Alta Performance",
                description = "Entenda o perfil da Transpetro, a remuneração, os benefícios e o plano estratégico de estudo.",
                chapters = listOf(Parte1ApresentacaoData.getChapter()),
                iconName = "Business",
                estimatedTotalMinutes = 20
            )
        )

        // Modulo 2: Língua Portuguesa Completa (28 Capítulos)
        list.add(
            EBookModule(
                id = "mod_2",
                moduleNumber = 2,
                title = "PARTE 2 — LÍNGUA PORTUGUESA COMPLETA",
                subtitle = "28 Capítulos com Teoria Gramatical, Interpretação Textual e Pegadinhas Cesgranrio",
                description = "Ortografia, acentuação, crase, concordâncias, regências, sintaxe, pontuação e redação técnica oficial.",
                chapters = Parte2PortuguesData.getChapters(),
                iconName = "MenuBook",
                estimatedTotalMinutes = 420
            )
        )

        // Modulo 3: Matemática (24 Capítulos)
        list.add(
            EBookModule(
                id = "mod_3",
                moduleNumber = 3,
                title = "PARTE 3 — MATEMÁTICA OPERACIONAL COMPLETA",
                subtitle = "24 Capítulos com Fórmulas, Resoluções Passo a Passo e Raciocínio Lógico",
                description = "Frações, porcentagens, juros simples/compostos, regra de 3, equações, áreas, volumes e estatística.",
                chapters = Parte3MatematicaData.getChapters(),
                iconName = "Calculate",
                estimatedTotalMinutes = 360
            )
        )

        // Modulo 4: Dúvidas Estratégicas e Método Cesgranrio
        list.add(
            EBookModule(
                id = "mod_4",
                moduleNumber = 4,
                title = "PARTE 4 — DÚVIDAS ESTRATÉGICAS: O MÉTODO CESGRANRIO",
                subtitle = "Como a Cesgranrio Cobra, Gestão de Tempo, Eliminação de Alternativas e Pegadinhas",
                description = "Manual prático de inteligência de prova para não cair nas armadilhas clássicas da banca.",
                chapters = listOf(Parte4DuvidasEstrategicasData.getChapter()),
                iconName = "Psychology",
                estimatedTotalMinutes = 25
            )
        )

        // Modulo 5: Conhecimentos Específicos — Dutos e Terminais (52 Tópicos Integrados)
        list.add(
            EBookModule(
                id = "mod_5",
                moduleNumber = 5,
                title = "PARTE 5 — DUTOS E TERMINAIS (CONHECIMENTOS ESPECÍFICOS)",
                subtitle = "10 Capítulos Completos Cobrindo os 52 Tópicos do Edital Oficial",
                description = "Petróleo, derivadas, tubulações API 5L, válvulas, bombas, tanques, medição, navios, SMS e CCO.",
                chapters = Parte5DutosTerminaisData.getChapters(),
                iconName = "LocalShipping",
                estimatedTotalMinutes = 240
            )
        )

        // Modulo 6: Conhecimentos Específicos — Manutenção Mecânica
        list.add(
            EBookModule(
                id = "mod_6",
                moduleNumber = 6,
                title = "PARTE 6 — MANUTENÇÃO MECÂNICA (CONHECIMENTOS ESPECÍFICOS)",
                subtitle = "Elementos de Máquinas, Soldagem AWS, Compressores, Lubrificação e Preditiva",
                description = "Mancais, engrenagens, acoplamentos, metalurgia, processos de solda, alinhamento laser e vibrações.",
                chapters = Parte6ManutencaoMecanicaData.getChapters(),
                iconName = "Build",
                estimatedTotalMinutes = 150
            )
        )

        // Modulo 7: Conhecimentos Específicos — Administração e Controle
        list.add(
            EBookModule(
                id = "mod_7",
                moduleNumber = 7,
                title = "PARTE 7 — ADMINISTRAÇÃO E CONTROLE (CONHECIMENTOS ESPECÍFICOS)",
                subtitle = "Gestão de Materiais, Curva ABC/XYZ, Lei 13.303/16, Custos e Compliance",
                description = "Teoria geral, compras nas estatais, fiscalização contratual, contabilidade gerencial e ética corporativa.",
                chapters = Parte7AdministracaoControleData.getChapters(),
                iconName = "AccountBalance",
                estimatedTotalMinutes = 140
            )
        )

        // Modulo 8: Revisão Turbo de Véspera
        list.add(
            EBookModule(
                id = "mod_12",
                moduleNumber = 8,
                title = "PARTE 12 — REVISÃO TURBO TRANSPETRO & 100 CONCEITOS DE OURO",
                subtitle = "Checklist de Véspera, Tabelas de Fórmulas e Mnemônicos Mais Cobrados",
                description = "Resumo relâmpago para fixação de última hora e consolidação das regras mais frequentes.",
                chapters = listOf(Parte12RevisaoTurboData.getChapter()),
                iconName = "FlashOn",
                estimatedTotalMinutes = 25
            )
        )

        // Modulo 9: Mapas Mentais Textuais
        list.add(
            EBookModule(
                id = "mod_13",
                moduleNumber = 9,
                title = "PARTE 13 — MAPAS MENTAIS EM FORMATO TEXTUAL",
                subtitle = "Diagramas Lógicos em Árvore para Revisão Visual Instantânea",
                description = "Estruturas hierárquicas esquematizadas de Português, Matemática, Dutos, Mecânica e Gestão.",
                chapters = listOf(Parte13MapasMentaisData.getChapter()),
                iconName = "AccountTree",
                estimatedTotalMinutes = 20
            )
        )

        // Modulo 10: Estratégia de Prova & Admissão
        list.add(
            EBookModule(
                id = "mod_14",
                moduleNumber = 10,
                title = "PARTE 14 — ESTRATÉGIA DE PROVA & MENTALIDADE VENCEDORA",
                subtitle = "Roteiro Minuto a Minuto das 4 Horas de Prova e Próximos Passos de Carreira",
                description = "Como controlar o tempo, gerenciar a ansiedade, interpor recursos e se preparar para a posse.",
                chapters = listOf(Parte14EstrategiaProvaData.getChapter()),
                iconName = "EmojiEvents",
                estimatedTotalMinutes = 20
            )
        )

        _modules.value = list
    }

    fun getAllChapters(): List<EBookChapter> {
        return _modules.value.flatMap { it.chapters }
    }

    fun getChapterById(id: String): EBookChapter? {
        return getAllChapters().find { it.id == id }
    }

    fun toggleChapterCompletion(chapterId: String) {
        val current = _completedChapters.value.toMutableSet()
        if (current.contains(chapterId)) {
            current.remove(chapterId)
        } else {
            current.add(chapterId)
        }
        _completedChapters.value = current
    }

    fun toggleFavoriteChapter(chapterId: String) {
        val current = _favoriteChapterIds.value.toMutableSet()
        if (current.contains(chapterId)) {
            current.remove(chapterId)
        } else {
            current.add(chapterId)
        }
        _favoriteChapterIds.value = current
    }

    fun recordQuizAnswer(questionId: String, selectedIndex: Int) {
        val current = _userQuizAnswers.value.toMutableMap()
        current[questionId] = selectedIndex
        _userQuizAnswers.value = current
    }

    fun getStudyPlans(): List<StudyPlan> {
        return Parte11PlanosEstudoData.getStudyPlans()
    }

    fun getSimulations(): List<ExamSimulation> {
        return Parte10SimuladosData.getSimulations()
    }

    fun getQuestionBank(): List<PracticeQuestion> {
        return Parte8QuestionBankData.getAllQuestions()
    }

    fun searchContent(query: String): List<EBookChapter> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        return getAllChapters().filter {
            it.title.lowercase().contains(q) ||
            it.subtitle.lowercase().contains(q) ||
            it.contentSections.any { sec -> sec.body.lowercase().contains(q) || sec.title.lowercase().contains(q) } ||
            it.questions.any { quest -> quest.statement.lowercase().contains(q) || quest.topic.lowercase().contains(q) }
        }
    }
}
