package com.example.data.repository

import com.example.data.model.*

object Parte6ManutencaoMecanicaData {
    fun getChapters(): List<EBookChapter> {
        return listOf(
            createElementosMaquinasChapter(),
            createSoldagemMateriaisChapter(),
            createMaquinasFluxoCompressorChapter(),
            createLubrificacaoManutencaoPreditivaChapter(),
            createMetrologiaAlinhamentoSegurancaChapter()
        )
    }

    private fun createElementosMaquinasChapter(): EBookChapter {
        return EBookChapter(
            id = "mecanica_cap_1",
            partId = "part_6",
            partNumber = 6,
            partTitle = "PARTE 6 — CONHECIMENTOS ESPECÍFICOS: MANUTENÇÃO MECÂNICA",
            chapterNumber = 1,
            title = "Capítulo 1 — Elementos de Máquinas, Transmissão Mecânica e Uniões Roscadas",
            subtitle = "Eixos, Chavetas, Mancais de Rolamento/Deslizamento, Engrenagens Cilíndricas/Cônicas, Correias e Acoplamentos",
            readTimeMinutes = 24,
            strategicSummary = "Estudo dos componentes mecânicos fundamentais de bombas, compressores e redutores, cálculo de relações de transmissão, seleção de rolamentos e critérios de fixação roscada.",
            highYieldAlerts = listOf(
                "Rolamentos de Rolos Cônicos suportam altas cargas axiais e radiais simultâneas; Rolamentos Rígidos de Esferas suportam altas velocidades e cargas radiais moderadas com pequena carga axial.",
                "Relação de Transmissão (i): i = n₁ / n₂ = d₂ / d₁ = z₂ / z₁ (o diâmetro e o número de dentes são inversamente proporcionais à rotação).",
                "Chavetas Paralelas trabalham predominantemente sob esforço de cisalhamento e esmagamento lateral."
            ),
            examTraps = listOf(
                "Esquecer que engrenagens helicoidais geram força axial indesejada no eixo (exigindo rolamentos de encosto ou engrenagens bi-helicoidais tipo 'espinha de peixe').",
                "Apertar parafusos além do torque de escoamento especificado, provocando deformação plástica irreversível da rosca."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Mancais de Rolamento vs. Mancais de Deslizamento (Buchas)",
                    body = """Os mancais apoiam e guiam eixos rotativos, absorvendo as cargas operacionais:

1. Mancais de Deslizamento (Casquilhos / Buchas):
• Operam sob regime de lubrificação hidrodinâmica (onde uma cunha de filme de óleo pressurizado separa completamente as superfícies metálicas durante a rotação).
• Vantagens: Altíssima capacidade de amortecimento de choques e vibrações, operação silenciosa e vida útil quase ilimitada se o filme fluido for preservado. Usados em eixos de grandes turbinas e motores de grande porte.
• Materiais: Metal Patente (Babbitt - liga de estanho/chumbo), bronze fosforoso e materiais poliméricos.

2. Mancais de Rolamento (Elementos Rolantes):
• O atrito é de rolamento (muito inferior ao atrito estático de deslizamento na partida).
• Componentes: Anel externo, anel interno, corpos rolantes (esferas, rolos cilíndricos, rolos cônicos, agulhas) e gaiola separadora.
• Tipos Principais:
  - Rígido de Esferas (Série 6000): Versátil, altas rotações, carga radial pura e pequena carga axial.
  - Rolos Cilíndricos: Suporta altíssimas cargas radiais puras, sem capacidade axial.
  - Rolos Cônicos: Suporta cargas combinadas (radial + axial em um sentido); montados em pares opostos.
  - Autocompensador de Esferas/Rolos: Permite desalinhamento angular do eixo (flexão de eixo).""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo de Elementos de Transmissão Mecânica",
                            headers = listOf("Elemento", "Tipo de Contato", "Vantagens", "Desvantagens", "Lubrificação"),
                            rows = listOf(
                                listOf("Correias em V", "Atrito nas faces laterais", "Absorve choques, fusível mecânico (desliza em sobrecarga)", "Não mantém sincronismo angular exato", "A seco (nunca aplicar óleo)"),
                                listOf("Correias Dentadas", "Engrenamento positivo", "Mantém sincronismo rigoroso sem escorregamento", "Menor amortecimento de impactos", "A seco"),
                                listOf("Correntes de Rolos", "Engrenamento com roda dentada", "Transmite altos torques a distâncias médias sem deslize", "Ruído em alta velocidade; desgaste de pinos", "Obrigatória (óleo/gotejamento)"),
                                listOf("Engrenagens Cilíndricas Dentes Retos", "Linha reta instantânea", "Sem força axial; fabricação econômica", "Ruidosa em alta velocidade; dentes entram em contato de impacto", "Banho de óleo / Circulação forçada"),
                                listOf("Engrenagens Helicoidais", "Contato progressivo helicoidal", "Operação suave e silenciosa para alto torque e alta rotação", "Gera força axial empurrando o eixo", "Banho de óleo sob pressão")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Acoplamentos Mecânicos e Uniões Roscadas",
                    body = """Acoplamentos unem eixos de máquinas motoras (motores/turbinas) a máquinas movidas (bombas/compressores):

• Acoplamentos Rígidos (Flangeados, Luvas): Exigem alinhamento perfeito dos eixos; não absorvem desalinhamentos nem choques térmicos.
• Acoplamentos Flexíveis:
  - Flexíveis Elásticos (Pneu, Garras com elastômero, cruzetas de poliuretano): Absorvem vibrações torcionais, choques e pequenos desalinhamentos axiais, radiais e angulares.
  - Flexíveis Metálicos (Engrenagens, Lâminas/Discos de Aço - Thomas): Alta rigidez torcional, suportam altas temperaturas e torques extremos em bombas de processo da Transpetro.

Uniões Roscadas e Classes de Resistência (ISO 898-1):
Parafusos de aço possuem marcações na cabeça (ex: 8.8, 10.9, 12.9):
• O primeiro número multiplicado por 100 indica o Limite de Resistência à Tração (S_ut) em MPa (ex: 8.8 ⇒ 8 × 100 = 800 MPa).
• O segundo número multiplicado por 10 indica a porcentagem do Limite de Escoamento (S_y) em relação à resistência à tração (ex: 8.8 ⇒ 80% de 800 MPa = 640 MPa).""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: CLASSES DE PARAFUSOS",
                            content = "Para um parafuso classe 10.9: Resistência à Tração = 1.000 MPa (10 × 100); Limite de Escoamento = 900 MPa (90% de 1.000). A Cesgranrio cobra frequentemente esse cálculo direto!",
                            iconType = "FORMULA"
                        )
                    )
                )
            ),
            questions = createMecanicaTopicQuestions(1, "Elementos de Máquinas")
        )
    }

    private fun createSoldagemMateriaisChapter(): EBookChapter {
        return EBookChapter(
            id = "mecanica_cap_2",
            partId = "part_6",
            partNumber = 6,
            partTitle = "PARTE 6 — CONHECIMENTOS ESPECÍFICOS: MANUTENÇÃO MECÂNICA",
            chapterNumber = 2,
            title = "Capítulo 2 — Processos de Soldagem, Metalurgia dos Aços e Tratamentos Térmicos",
            subtitle = "Processos SMAW, GMAW/MIG-MAG, GTAW/TIG, SAW, Classificação AWS e Diagrama Ferro-Carbono",
            readTimeMinutes = 24,
            strategicSummary = "Soldagem de tubulações e equipamentos industriais, classificação de eletrodos (AWS A5.1 / A5.5), descontinuidades em juntas soldadas e tratamentos térmicos (têmpera, revenimento, recozimento, alívio de tensões).",
            highYieldAlerts = listOf(
                "Processo GTAW / TIG: Utiliza eletrodo não consumível de Tungstênio sob atmosfera de gás inerte (Argônio/Hélio). Padrão para passe de raiz de tubulações de alta pressão devido à sua excelente qualidade radiográfica.",
                "Eletrodo Revestido AWS E7018: 'E' = Eletrodo; '70' = Resistência mínima à tração de 70.000 psi (~ 485 MPa); '1' = Soldagem em todas as posições; '8' = Revestimento básico de baixo hidrogênio.",
                "Tratamento de Alívio de Tensões (TTAT / PWHT): Aquecimento subcrítico pós-soldagem para eliminar tensões residuais e evitar trincas por corrosão sob tensão (SCC)."
            ),
            examTraps = listOf(
                "Achar que o processo TIG utiliza eletrodo consumível (o eletrodo de tungstênio NÃO se funde; o metal de adição é inserido externamente).",
                "Confundir MIG com MAG: MIG usa gás inerte puro (Argônio/Hélio, para alumínio e inox); MAG usa gás ativo ou mistura com CO₂/O₂ (para aços carbono)."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Processos Industriais de Soldagem e Eletrodos AWS",
                    body = """A soldagem é a união permanente de materiais por coalescência localizada provocada por calor e/ou pressão:

1. SMAW (Shielded Metal Arc Welding - Eletrodo Revestido):
• O arco elétrico queima entre a alma metálica e a peça. O revestimento funde-se formando escória protetora e gases que blindam a poça de fusão contra oxigênio e nitrogênio do ar.
• Eletrodo E6010 (Celulósico): Alta penetração, ideal para passes de raiz verticais descendentes em oleodutos em campo.
• Eletrodo E7018 (Básico): Baixo teor de hidrogênio difusível, alta tenacidade ao impacto, ideal para enchimento e acabamento em estruturas críticas. Exige estufa de secagem a 300-350 °C para não absorver umidade.

2. GMAW / FCAW (MIG/MAG e Arame Tubular):
• Alimentação contínua de arame eletrodo consumível por tocha motorizada. Alta taxa de deposição e alto fator de ocupação do soldador.

3. GTAW (Gas Tungsten Arc Welding - TIG):
• Arco elétrico de altíssima estabilidade e acabamento estético sem respingos nem escória.

4. SAW (Submerged Arc Welding - Arco Submerso):
• O arco elétrico queima sob um colchão espesso de fluxo mineral granular. Processo 100% mecanizado com altíssima taxa de fusão, utilizado na fabricação seriada de tubos API 5L de grande diâmetro.""",
                    tables = listOf(
                        TableItem(
                            title = "Descodificação da Norma AWS para Eletrodos Revestidos (ex: E7018)",
                            headers = listOf("Dígito", "Símbolo", "Significado Técnico"),
                            rows = listOf(
                                listOf("Prefixo", "E", "Eletrodo para soldagem a arco manual"),
                                listOf("Dois Primeiros Dígitos", "70", "Limite de Resistência à Tração Mínimo = 70.000 psi (70 ksi)"),
                                listOf("Terceiro Dígito", "1", "Posição de Soldagem: 1 = Todas as posições; 2 = Plana e horizontal"),
                                listOf("Quarto Dígito", "8", "Tipo de Revestimento: Básico com pó de ferro e baixo hidrogênio difusível"),
                                listOf("Sufixo Opcional", "-1 / -H4", "Maior tenacidade a baixas temperaturas / Teor máximo de 4 mL de H₂/100g")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Metalurgia, Aços e Tratamentos Térmicos",
                    body = """Tratamentos Térmicos dos Aços:
• Têmpera: Aquecimento acima da zona crítica (austenitização) seguido de resfriamento ultrarrápido em água ou óleo. Transforma a austenita em MARTENSITA (microestrutura de altíssima dureza e fragilidade).
• Revenimento: Aquecimento subcrítico realizado OBRIGATORIAMENTE após a têmpera para aliviar tensões internas, reduzir a fragilidade e aumentar a tenacidade do aço temperado.
• Recozimento Pleno: Aquecimento e resfriamento ultralento dentro do forno desligado. Elimina a dureza, refina o grão e confere máxima ductilidade e usinabilidade à peça.
• Normalização: Resfriamento ao ar calmo; produz perlita fina homogênea e boas propriedades mecânicas gerais.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: ZTA (ZONA TERMICAMENTE AFETADA)",
                            content = "A ZTA (Zona Termicamente Afetada) é a região do metal de base adjacente ao cordão de solda que não chegou a fundir, mas teve sua microestrutura e propriedades mecânicas modificadas pelo calor da soldagem. É a região mais suscetível a trincas a frio e corrosão.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createMecanicaTopicQuestions(2, "Soldagem e Materiais")
        )
    }

    private fun createMaquinasFluxoCompressorChapter(): EBookChapter {
        return EBookChapter(
            id = "mecanica_cap_3",
            partId = "part_6",
            partNumber = 6,
            partTitle = "PARTE 6 — CONHECIMENTOS ESPECÍFICOS: MANUTENÇÃO MECÂNICA",
            chapterNumber = 3,
            title = "Capítulo 3 — Máquinas de Fluxo, Compressores Industriais e Manutenção de Válvulas",
            subtitle = "Compressores Alternativos de Pistão, Parafuso Rotativo, Centrifugos, Selagem Mecânica (Selos API 682) e Gaxetas",
            readTimeMinutes = 24,
            strategicSummary = "Operação e manutenção de compressores de gás natural e ar comprimido, selos mecânicos de cartucho duplo para hidrocarbonetos perigosos e planos de selagem API.",
            highYieldAlerts = listOf(
                "Compressores Alternativos (Pistão): Ideais para baixas vazões e altíssimas pressões; exigem válvulas automáticas de sucção e descarga (tipo disco ou palheta).",
                "Compressores Centrífugos (Dinâmicos): Operam em altas rotações e grandes vazões contínuas. Risco operacional crítico: SURGE (Surto / Bombeamento), que ocorre em baixas vazões e provoca oscilações violentas de pressão.",
                "Selos Mecânicos (API 682): Substituem gaxetas na vedação do eixo de bombas de petróleo, reduzindo emissões fugitivas a zero com anéis de silício, tungstênio e carbono."
            ),
            examTraps = listOf(
                "Apertar a sobreposta do preme-gaxeta até cessar completamente o gotejamento de água/óleo: Gaxeta convencional EXIGE gotejamento mínimo de lubrificação e resfriamento (10 a 30 gotas/min), senão queima o eixo!",
                "Partir compressor alternativo com a válvula de descarga fechada (risco de explosão da carcaça do cilindro)."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Compressores Industriais e Fenômeno de Surge",
                    body = """Os compressores elevam a pressão de fluidos compressíveis (ar e gases):

1. Compressores de Deslocamento Positivo:
• Alternativos (Pistão / Êmbolo): O gás é admitido na câmara, comprimido pela redução do volume do cilindro e descarregado quando a pressão interna supera a pressão da linha. Dotados de camisas refrigeradas a água e anéis de segmento de teflon ou ferro fundido.
• Parafuso Rotativo (Twin Screw): Dois rotores helicoidais (macho e fêmea) engrenados comprimem o gás axialmente de forma contínua e sem pulsação de pressão.

2. Compressores Dinâmicos (Centrífugos e Axiais):
• Aceleração aerodinâmica do gás por impelidores radiais.
• O Fenômeno de Surge (Surto): Quando a vazão de gás cai abaixo do limite estável, a contrapressão do sistema supera a pressão gerada pelo rotor, provocando uma reversão violenta e cíclica do fluxo de gás com estrondos e destruição dos mancais axiais. Protegido por Válvulas Anti-Surge de abertura ultrarrápida.""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo: Gaxetas Trançadas vs. Selo Mecânico",
                            headers = listOf("Característica", "Engaxetamento Convencional", "Selo Mecânico de Alta Performance (API 682)"),
                            rows = listOf(
                                listOf("Princípio de Vedação", "Compressão radial de anéis de teflon/grafite contra o eixo", "Contato axial plano de duas faces lapeadas de altíssima precisão"),
                                listOf("Vazamento Operacional", "Exige gotejamento constante para lubrificação e resfriamento", "Vazamento visual nulo (nível microscópico de vapor)"),
                                listOf("Desgaste do Eixo/Luva", "Desgasta e risca a luva protetora com o tempo", "Não desgasta o eixo da bomba"),
                                listOf("Consumo de Potência", "Maior perda por atrito mecânico", "Mínimo atrito mecânico"),
                                listOf("Aplicação em Hidrocarbonetos", "Proibido em produtos tóxicos e voláteis da Transpetro", "Obrigatório em refinarias, oleodutos e terminais")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Planos de Selagem API (API Piping Plans)",
                    body = """Os sistemas de apoio a selos mecânicos (Planos API) garantem o ambiente térmico e de pressão ideal:
• Plano API 11: Recirculação interna da descarga da bomba para a câmara de selagem para resfriamento e lavagem das faces.
• Plano API 53A/B: Sistema de selo duplo pressurizado com fluído barreira sintético incompatível com o produto a uma pressão superior à câmara de bombeamento, garantindo emissão zero para o meio ambiente.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: VÁLVULAS DE COMPRESSORES ALTERNATIVOS",
                            content = "Mais de 60% das paradas não planejadas de compressores alternativos são causadas por falha ou quebra de palhetas/molas de válvulas automáticas de sucção e descarga por fadiga ou arraste de condensado líquido.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createMecanicaTopicQuestions(3, "Máquinas de Fluxo e Compressores")
        )
    }

    private fun createLubrificacaoManutencaoPreditivaChapter(): EBookChapter {
        return EBookChapter(
            id = "mecanica_cap_4",
            partId = "part_6",
            partNumber = 6,
            partTitle = "PARTE 6 — CONHECIMENTOS ESPECÍFICOS: MANUTENÇÃO MECÂNICA",
            chapterNumber = 4,
            title = "Capítulo 4 — Lubrificação Industrial, Tipos de Manutenção e Técnicas Preditivas",
            subtitle = "Viscosidade ISO VG, Graxas NLGI, Análise de Vibrações (FFT), Termografia, Ferrografia, MTBF e MTTR",
            readTimeMinutes = 24,
            strategicSummary = "Regimes de lubrificação (hidrodinâmica, elastohidrodinâmica, limite), seleção de lubrificantes, estratégias de PCM (Preventiva, Corretiva, Preditiva, RCM) e indicadores de confiabilidade.",
            highYieldAlerts = listOf(
                "Índice de Viscosidade (IV): Mede a variação da viscosidade com a temperatura. Quanto MAIOR o IV, MENOR é a variação da viscosidade quando a máquina esquenta.",
                "Análise de Vibrações (Espectro FFT): Identifica desbalanceamento (1X rotação), desalinhamento de eixos (2X rotação + componente axial) e folgas mecânicas (harmônicos múltiplos).",
                "Indicadores de Confiabilidade: MTBF (Tempo Médio Entre Falhas) mede a confiabilidade; MTTR (Tempo Médio Para Reparo) mede a mantenabilidade."
            ),
            examTraps = listOf(
                "Misturar graxas com espessantes incompatíveis (ex: graxa à base de sabão de lítio com graxa de cálcio complexo ou poliureia), o que provoca a perda total da estrutura coloidal e vazamento do óleo base!",
                "Achar que manutenção preditiva é agendada por tempo fixo: preditiva monitora a condição em tempo real e atua apenas antes da falha funcional."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Fundamentos da Tribologia e Lubrificação Industrial",
                    body = """A lubrificação reduz o atrito e o desgaste, dissipa o calor, previne a corrosão e remove contaminantes:

1. Óleos Lubrificantes:
• Óleo Base (Mineral, Sintético PAO/Éster ou Semissintético) + Pacote de Aditivos (Antioxidantes, Antidesgaste ZDDP, Extrema Pressão EP, Detergentes, Antiespumantes).
• Grau de Viscosidade ISO VG (ISO 3448): Define a viscosidade cinemática do óleo em centistokes (cSt) medida rigorosamente a 40 °C (ex: ISO VG 46 = 46 cSt ± 10% a 40 °C).

2. Graxas Lubrificantes:
• Composição: Óleo Lubrificante Base (70-90%) + Espessante / Sabão Metálico (10-20%) + Aditivos.
• Consistência NLGI (Graus 000 a 6): Medida pelo penetrômetro cônico normalizado a 25 °C. Grau NLGI 2 é a consistência padrão para rolamentos industriais de motores e bombas.""",
                    formulas = listOf(
                        FormulaItem(
                            name = "Indicadores de Manutenção: MTBF, MTTR e Disponibilidade",
                            expression = "MTBF = Tempo Total em Operação / Nº de Falhas  |  MTTR = Tempo Total de Reparo / Nº de Falhas  |  D = MTBF / (MTBF + MTTR)",
                            variables = "MTBF: Mean Time Between Failures; MTTR: Mean Time To Repair; D: Disponibilidade Inerente da Planta.",
                            applicationTip = "Para aumentar a disponibilidade, deve-se elevar o MTBF (menos quebras) e reduzir o MTTR (reparos mais rápidos)."
                        )
                    )
                ),
                ContentSection(
                    title = "2. Manutenção Preditiva e Diagnóstico de Falhas",
                    body = """Técnicas Preditivas Não Invasivas:
• Análise de Vibrações: Sensores piezoelétricos (acelerômetros) captam o sinal temporal de vibração que é convertido pelo algoritmo FFT (Fast Fourier Transform) em um espectro de frequência. Permite diagnosticar falhas nas pistas de rolamentos (BPFO, BPFI, BSF), defeitos em dentes de engrenagens e desbalanceamentos.
• Termografia Infravermelha: Câmeras radiométricas detectam aquecimentos anormais causados por atrito excessivo, sobrecarga elétrica ou falta de lubrificação em mancais e conexões.
• Análise de Óleo e Ferrografia:
  - Análise Físico-Química: Viscosidade, TAN (Número de Acidez Total), teor de água (Karl Fischer).
  - Ferrografia Analítica: Separação magnética das partículas de desgaste do óleo para determinar sua morfologia e severidade (fadiga, abrasão, atrito severo).""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: CURVA P-F (POTENCIAL-FUNCIONAL)",
                            content = "A curva P-F descreve o intervalo entre a detecção do primeiro sintoma de falha potencial (P) por ensaios preditivos e a ocorrência da falha funcional (F) com perda de operação. A manutenção preditiva opera exatamente no intervalo P-F.",
                            iconType = "TECH"
                        )
                    )
                )
            ),
            questions = createMecanicaTopicQuestions(4, "Lubrificação e Preditiva")
        )
    }

    private fun createMetrologiaAlinhamentoSegurancaChapter(): EBookChapter {
        return EBookChapter(
            id = "mecanica_cap_5",
            partId = "part_6",
            partNumber = 6,
            partTitle = "PARTE 6 — CONHECIMENTOS ESPECÍFICOS: MANUTENÇÃO MECÂNICA",
            chapterNumber = 5,
            title = "Capítulo 5 — Metrologia Dimensional, Alinhamento de Eixos e Segurança em Manutenção",
            subtitle = "Leitura de Paquímetro, Micrômetro, Relógio Comparador, Alinhamento a Laser e Bloqueio de Energia (LOTO)",
            readTimeMinutes = 24,
            strategicSummary = "Instrumentos de medição de precisão (resolução em mm e polegada fracionária/milesimal), cálculo de calços para alinhamento de conjuntos moto-bomba, balanceamento e procedimentos de bloqueio e etiquetagem (Lockout/Tagout).",
            highYieldAlerts = listOf(
                "Resolução do Paquímetro: R = Menor divisão da escala fixa (1 mm) / Número de divisões do nônio (ex: nônio de 20 divisões ⇒ R = 1/20 = 0,05 mm; nônio de 50 divisões ⇒ R = 1/50 = 0,02 mm).",
                "Alinhamento a Laser: Corrige simultaneamente o desalinhamento radial (paralelo) e angular (cônico) nos planos vertical e horizontal, considerando o crescimento térmico operacional das carcaças.",
                "LOTO (Lockout / Tagout): Bloqueio físico individual com cadeado e etiqueta de identificação de TODAS as fontes de energia perigosa (elétrica, hidráulica, pneumática, gravitacional e química) antes de intervir no equipamento."
            ),
            examTraps = listOf(
                "Leitura de micrômetro: Esquecer de somar a fração de 0,5 mm da escala intermediária da bainha antes de ler os centésimos no tambor graduado.",
                "Realizar alinhamento sem verificar o 'Pé Manco' (Soft Foot): Se uma das patas do motor não assentar perfeitamente na base, o aperto do parafuso empena a carcaça e desalinha todo o conjunto!"
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Metrologia Dimensional e Leitura de Instrumentos",
                    body = """A metrologia garante a precisão de ajustes e tolerâncias mecânicas:

1. Paquímetro Universal:
• Mede dimensões externas (orelhas principais), internas (orelhas superiores) e profundidade/ressaltos (haste).
• Resoluções usuais no Sistema Métrico: 0,05 mm (nônio 20 div) e 0,02 mm (nônio 50 div).

2. Micrômetro Externo:
• Baseado no mecanismo de fuso micrométrico com passo de rosca de 0,5 mm.
• A bainha é graduada em milímetros e meios-milímetros. O tambor possui 50 divisões periféricas:
  Resolução = 0,5 mm / 50 = 0,01 mm (um centésimo de milímetro).
• Dotado de catraca de fricção com limitador de torque para garantir pressão constante de medição sem deformar a peça.

3. Relógio Comparador:
• Medidor por amplificação de engrenagens de deslocamento linear. O mostrador graduado possui divisões de 0,01 mm (ou 0,001 mm no comparador milesimal).
• Utilizado para medir batimento radial (excentricidade), empenamento de eixos e paralelismo de flanges.""",
                    tables = listOf(
                        TableItem(
                            title = "Guia Rápido de Resolução de Instrumentos de Metrologia",
                            headers = listOf("Instrumento", "Divisões do Nônio / Tambor", "Cálculo da Resolução", "Resolução Final"),
                            rows = listOf(
                                listOf("Paquímetro Padrão", "20 divisões", "1 mm / 20", "0,05 mm"),
                                listOf("Paquímetro de Alta Precisão", "50 divisões", "1 mm / 50", "0,02 mm"),
                                listOf("Micrômetro Centesimal", "50 divisões (passo 0,5 mm)", "0,5 mm / 50", "0,01 mm"),
                                listOf("Relógio Comparador", "100 divisões por volta (1 mm)", "1 mm / 100", "0,01 mm"),
                                listOf("Goniômetro (Transferidor de Grau)", "12 divisões no nônio", "60 minutos / 12", "5 minutos de grau (5')")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Procedimento de Alinhamento e Bloqueio de Energias (LOTO)",
                    body = """Passo a Passo de um Alinhamento de Alta Precisão:
1. Aplicação do Procedimento LOTO no cubículo elétrico do motor.
2. Limpeza da base e verificação de 'Pé Manco' com relógio comparador (tolerância máxima < 0,05 mm em cada pata).
3. Instalação dos sensores laser ou relógios comparadores (Método Radial-Axial ou Reverso).
4. Medição inicial do desalinhamento e inserção de calços calibrados de aço inox sob os pés do motor para correção vertical.
5. Ajuste horizontal com parafusos empurradores laterais e aperto final com torquímetro.

Segurança Inegociável (LOTO):
• Teste de Energia Zero (Zero Energy State): Após bloquear o disjuntor e colocar o cadeado, o técnico DEVE tentar ligar o equipamento na botoeira local para comprovar fisicamente que a partida está desabilitada.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: TESTE DE ENERGIA ZERO",
                            content = "O cadeado LOTO é PESSOAL e INTRANSFERÍVEL. Cada profissional da equipe de manutenção deve colocar seu próprio cadeado na garra de bloqueio coletivo. É terminantemente proibido um operador remover o cadeado de outro colega.",
                            iconType = "LAW"
                        )
                    )
                )
            ),
            questions = createMecanicaTopicQuestions(5, "Metrologia e Alinhamento")
        )
    }

    private fun createMecanicaTopicQuestions(chapNum: Int, topicName: String): List<PracticeQuestion> {
        return listOf(
            PracticeQuestion(
                id = "mec_q_${chapNum}_1",
                code = "MEC-$chapNum-01",
                subject = "Manutenção Mecânica",
                topic = topicName,
                difficulty = "Médio",
                statement = "Na especificação de elementos mecânicos e procedimentos de manutenção industrial em unidades da Transpetro, analise as afirmativas e assinale a opção correta:",
                options = listOf(
                    "A) Os mancais de deslizamento hidrodinâmicos exigem que haja contato metálico direto entre o eixo e o casquilho durante a velocidade nominal de rotação.",
                    "B) Um parafuso de alta resistência mecânica classificado pela norma ISO como classe 10.9 possui limite de escoamento aproximado de 900 MPa.",
                    "C) O processo de soldagem TIG (GTAW) utiliza eletrodo consumível de tungstênio revestido com celulose para soldas de alta penetração.",
                    "D) O fenômeno de 'surge' em compressores centrífugos ocorre quando a vazão de gás ultrapassa a capacidade máxima de projeto do impelidor.",
                    "E) O índice de viscosidade (IV) de um óleo lubrificante quanto mais baixo for, menor será a variação de sua viscosidade com o aumento da temperatura."
                ),
                correctIndex = 1,
                detailedExplanation = "A alternativa B está correta: Na classe 10.9, o limite de tração é 10 × 100 = 1.000 MPa e o limite de escoamento é 90% desse valor = 900 MPa.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: Na lubrificação hidrodinâmica, forma-se uma cunha fluida que SEPARA completamente as superfícies metálicas.",
                    2 to "Incorreto: O eletrodo de tungstênio no processo TIG é NÃO CONSUMÍVEL.",
                    3 to "Incorreto: O surge ocorre em BAIXAS vazões, quando o compressor perde sustentação de fluxo contra a contrapressão.",
                    4 to "Incorreto: Quanto MAIOR o IV, MENOR é a variação da viscosidade com a temperatura."
                ),
                highYieldTip = "Propriedades de parafusos métricos: S_tração = 1º dígito × 100; S_escoamento = (1º dígito × 2º dígito) × 10."
            ),
            PracticeQuestion(
                id = "mec_q_${chapNum}_2",
                code = "MEC-$chapNum-02",
                subject = "Manutenção Mecânica",
                topic = topicName,
                difficulty = "Difícil",
                statement = "Em relação ao diagnóstico de falhas mecânicas por técnicas preditivas e medição de precisão, assinale a opção verdadeira:",
                options = listOf(
                    "A) O desbalanceamento dinâmico de um rotor é caracterizado no espectro de vibração por um pico predominante na frequência de 1X a rotação do eixo.",
                    "B) O ensaio de líquido penetrante é a técnica preditiva mais adequada para detectar trincas internas no núcleo de eixos forjados.",
                    "C) Um paquímetro com escala principal dividida em milímetros e nônio com 50 divisões apresenta uma resolução de 0,05 mm.",
                    "D) O tratamento térmico de têmpera tem como finalidade primordial aumentar a ductilidade e a tenacidade ao impacto do aço carbono.",
                    "E) A graxa classificada com consistência NLGI 000 é muito mais espessa e rígida do que uma graxa com consistência NLGI 3."
                ),
                correctIndex = 0,
                detailedExplanation = "A alternativa A está correta: O desbalanceamento de massa em rotores gera força centrífuga síncrona com a rotação, manifestando-se no espectro FFT como um pico dominante na frequência fundamental de 1X (1 vezes a rotação do eixo).",
                incorrectOptionsExplanation = mapOf(
                    1 to "Incorreto: Líquido penetrante detecta apenas trincas superficiais; defeitos internos exigem ultrassom.",
                    2 to "Incorreto: Nônio de 50 divisões tem resolução de 1/50 = 0,02 mm.",
                    3 to "Incorreto: A têmpera aumenta a dureza e fragilidade; o aumento de tenacidade é obtido pelo revenimento posterior.",
                    4 to "Incorreto: NLGI 000 é uma graxa semifluida (quase líquida), enquanto NLGI 3 é firme."
                ),
                highYieldTip = "Espectro de vibração: 1X = Desbalanceamento; 2X + axial = Desalinhamento; 3X, 4X, múltiplos = Folga mecânica."
            )
        )
    }
}
