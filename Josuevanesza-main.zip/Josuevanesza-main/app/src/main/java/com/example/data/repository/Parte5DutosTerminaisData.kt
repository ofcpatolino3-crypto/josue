package com.example.data.repository

import com.example.data.model.*

object Parte5DutosTerminaisData {
    fun getChapters(): List<EBookChapter> {
        return listOf(
            createPetroleoDerivadosChapter(),
            createDutosComponentesChapter(),
            createBombasEstacoesChapter(),
            createTanquesArmazenamentoChapter(),
            createMedicaoInstrumentacaoAutomacaoChapter(),
            createOperacoesTerminaisDutosChapter(),
            createOperacoesAquaviariasNaviosChapter(),
            createSmsSegurancaMeioAmbienteChapter(),
            createIntegridadeCorrosaoInspecaoChapter(),
            createAutomacaoCcoGestaoRiscosChapter()
        )
    }

    private fun createPetroleoDerivadosChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_1",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 1,
            title = "Capítulo 1 — Petróleo, Derivados, Características Físico-Químicas e Logística",
            subtitle = "Tópicos 1 a 4: Composição de Hidrocarbonetos, Grau °API, Viscosidade, Pontos de Fulgor/Fluidez e Logística Integrada",
            readTimeMinutes = 22,
            strategicSummary = "Compreensão aprofundada da classificação de petróleos e derivados, parâmetros de densidade (°API), viscosidade cinemática, volatilidade e a matriz logística da Transpetro.",
            highYieldAlerts = listOf(
                "Grau °API é inversamente proporcional à densidade relativa: quanto MAIOR o °API, mais leve é o óleo (ex: °API > 31,1 = Petróleo Leve).",
                "Ponto de Fulgor (Flash Point) é a menor temperatura na qual um líquido emite vapores suficientes para formar mistura inflamável momentânea em presença de fonte de ignição.",
                "Ponto de Fluidez (Pour Point) define a temperatura mínima na qual o óleo ainda escoa sob a ação da gravidade (fundamental para petróleos parafínicos)."
            ),
            examTraps = listOf(
                "Confundir Ponto de Fulgor com Ponto de Combustão ou Ponto de Autoignição. A Cesgranrio cobra a diferença exata entre os três!",
                "Achar que petróleo de 40 °API é mais pesado que petróleo de 18 °API (na verdade, 40 °API é muito mais leve!)."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Fundamentos do Petróleo e Principais Produtos Movimentados",
                    body = """O petróleo bruto é uma mistura complexa formada predominantemente por hidrocarbonetos (alcanos, cicloalcanos e aromáticos) e pequenas frações de compostos organossulfurados, nitrogenados e oxigenados.

Na malha dutoviária e nos terminais da Transpetro, os produtos movimentados são agrupados em duas grandes categorias:
1. Granéis Líquidos Claros (Derivados Claros):
• Gasolina Automotiva (tipo A sem etanol e tipo C com etanol anidro).
• Óleo Diesel (S-10 e S-500, com teor de enxofre em ppm).
• Querosene de Aviação (QAV-1 / Jet A-1), com severo controle de pureza e ausência de água livre.
• Nafta Petroquímica, solventes e Biocombustíveis (Etanol Hidratado e Anidro, Biodiesel).

2. Granéis Líquidos Escuros (Derivados Escuros e Petróleo Bruto):
• Petróleos Brutos de diversas bacias (Pré-Sal, Bacia de Campos, Recôncavo).
• Óleo Combustível (Fuel Oil / Bunker para navios).
• Asfalto e Resíduos Atmosféricos/Vácuo (que exigem aquecimento contínuo em tubulações isoladas termicamente).

3. Gases Liquefeitos e Gás Natural:
• GLP (mistura de Propano e Butano comercial) movimentado sob alta pressão ou refrigerado.
• Gás Natural (predominância de Metano CH₄ e Etano C₂H₆) transportado em gasodutos de alta pressão.""",
                    tables = listOf(
                        TableItem(
                            title = "Classificação ANP do Petróleo por Grau °API",
                            headers = listOf("Classificação", "Faixa de Grau °API", "Densidade Relativa (d)", "Características Operacionais"),
                            rows = listOf(
                                listOf("Extrapesado", "< 10,0 °API", "d > 1,00 (afunda na água)", "Altíssima viscosidade; exige aquecimento ou diluente."),
                                listOf("Pesado", "10,0 a 22,2 °API", "0,920 a 1,000", "Elevado teor de asfaltenos e resinas."),
                                listOf("Médio", "22,3 a 31,1 °API", "0,870 a 0,920", "Comum no pós-sal brasileiro; escoamento regular."),
                                listOf("Leve", "> 31,1 °API", "d < 0,870", "Predominante no Pré-Sal (ex: Campo de Búzios, Tupi); alto rendimento de diesel e gasolina.")
                            )
                        )
                    ),
                    formulas = listOf(
                        FormulaItem(
                            name = "Fórmula do Grau °API",
                            expression = "°API = (141,5 / d_60°F) - 131,5",
                            variables = "d_60°F: Densidade relativa do produto a 60 °F (15,56 °C) em relação à água pura a 60 °F.",
                            applicationTip = "Lembre-se: d = 1 (água) ⇒ °API = 141,5 - 131,5 = 10 °API."
                        )
                    )
                ),
                ContentSection(
                    title = "2. Propriedades Críticas: Viscosidade, Ponto de Fulgor, Fluidez e Pressão de Vapor",
                    body = """Para a operação de dutos e estações de bombeamento, o técnico da Transpetro monitora constantemente:

• Viscosidade Cinemática (ν): Resistência interna do fluido ao escoamento. Medida em centistokes (cSt) ou mm²/s. Fluidos de alta viscosidade provocam maiores perdas de carga por atrito ao longo do duto, exigindo maior potência de bombas ou injeção de aditivos redutores de atrito (DRA - Drag Reducing Agents).
• Ponto de Fulgor (Flash Point): Norma ASTM D93 / NBR 14598. Define a classificação de segurança em inflamáveis (Ponto de Fulgor ≤ 60 °C) e combustíveis (> 60 °C) conforme a NR-20.
• Ponto de Fluidez (Pour Point): Temperatura em que as parafinas começam a cristalizar e formam redes tridimensionais que impedem o escoamento. Para evitar o 'congelamento' do óleo no duto, utilizam-se estações de aquecimento ou aditivos depressores de ponto de fluidez (PPD).
• Pressão de Vapor Reid (PVR): Mede a volatilidade do hidrocarboneto a 37,8 °C (100 °F). Produtos com alta PVR (como gasolinas e GLP) liberam vapores facilmente, exigindo tanques de teto flutuante para conter perdas por evaporação e evitar cavitação nas bombas de sucção.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: NBR 17505 E NR-20",
                            content = "Líquidos Inflamáveis possuem Ponto de Fulgor ≤ 60 °C (ex: Gasolina: ~ -40 °C; Etanol: ~ 13 °C). Líquidos Combustíveis possuem Ponto de Fulgor > 60 °C e ≤ 93 °C (ex: Óleo Diesel S-10: Ponto de Fulgor mínimo de 38 °C a 55 °C conforme especificação local).",
                            iconType = "LAW"
                        )
                    ),
                    examTraps = listOf(
                        ExamTrapData(
                            title = "Ponto de Fulgor vs. Ponto de Autoignição",
                            trapDescription = "A banca diz que no ponto de fulgor o óleo pega fogo sozinho sem chama externa.",
                            howToAvoid = "No Ponto de Fulgor, necessita-se OBRIGATORIAMENTE de uma chama/centelha externa e a queima é momentânea. A queima espontânea sem chama ocorre apenas no Ponto de Autoignição (temperatura muito mais alta, superior a 250 °C)."
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(1, "Petróleo e Derivados")
        )
    }

    private fun createDutosComponentesChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_2",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 2,
            title = "Capítulo 2 — Transporte Dutoviário, Tubulações, Válvulas e Conexões",
            subtitle = "Tópicos 5 a 12: Classificação de Oleodutos/Gasodutos, Norma API 5L, Tipos de Válvulas, Flanges e Acessórios",
            readTimeMinutes = 24,
            strategicSummary = "Estudo pormenorizado da malha dutoviária, aços para tubulações, mecanismos de vedação, tipos e aplicações de válvulas industriais (gaveta, esfera, globo, retenção, borboleta, alívio de pressão) e classes de pressão ASME B16.5.",
            highYieldAlerts = listOf(
                "Oleodutos operam com líquidos incompressíveis; Gasodutos operam com gases compressíveis (exigindo estações de compressão em vez de bombeamento).",
                "Válvulas de Esfera (Ball Valves) de passagem plena (Full Bore) são as únicas que permitem a passagem livre de ferramentas de inspeção (PIGs).",
                "Válvula de Retenção (Check Valve) impede o refluxo de produto no sentido contrário, protegendo bombas contra retorno hidráulico."
            ),
            examTraps = listOf(
                "Usar Válvula Gaveta para regular vazão (estrangulamento): NUNCA! Válvula gaveta opera apenas totalmente aberta ou totalmente fechada sob risco de cavitação e erosão da cunha.",
                "Confundir classe de pressão ASME (150#, 300#, 600#, 900#) com pressão estática máxima em qualquer temperatura."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Classificação dos Dutos e Materiais (Norma API 5L)",
                    body = """Os dutos de transporte são o modal mais seguro, econômico e ambientalmente eficiente para transporte contínuo de granéis energéticos em grandes volumes e longas distâncias.

Classificação Funcional dos Dutos:
• Oleodutos de Transporte (Tronco): Unem grandes terminais marítimos a refinarias distantes, com diâmetros que variam de 16\" a 42\" e pressões que ultrapassam 80 bar.
• Polidutos: Transportam múltiplos derivados sucessivamente pelo mesmo tubo através do regime de batelada (batching), com rigoroso controle da zona de mistura (interface).
• Gasodutos de Transporte: Transportam gás natural sob alta pressão (geralmente entre 50 e 100 kgf/cm²), dotados de Estações de Compressão (ECOMP) e Estações de Redução de Pressão e Medição (ERPM).
• Minerodutos e Quimicodutos: Dutos específicos para minérios polpados ou insumos petroquímicos.

Tubulações e Aços API 5L:
Os tubos para dutos de petróleo e gás são fabricados segundo a norma API 5L (Graus B, X42, X52, X60, X65, X70, X80). O número indica o Limite Mínimo de Escoamento (SMYS - Specified Minimum Yield Strength) em milhares de psi (ex: X65 = 65.000 psi ≈ 448 MPa).""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo de Tipos de Válvulas em Dutos e Terminais",
                            headers = listOf("Tipo de Válvula", "Função Primária", "Vantagens", "Restrições Operacionais", "Permite Passagem de PIG?"),
                            rows = listOf(
                                listOf("Válvula Gaveta (Gate)", "Bloqueio (On/Off)", "Baixa perda de carga quando aberta; estanqueidade bidirecional.", "Não serve para regulagem de vazão; acionamento lento.", "Sim (se for passagem plena)"),
                                listOf("Válvula Esfera (Ball)", "Bloqueio rápido e estanque", "Abertura rápida de 1/4 de volta (90°); excelente estanqueidade.", "Custo elevado em diâmetros gigantescos.", "Sim (Full Bore obrigatório)"),
                                listOf("Válvula Globo (Globe)", "Regulagem de vazão / Estrangulamento", "Controle fino de fluxo; boa vedação.", "Alta perda de carga; fluxo sinuoso.", "NÃO"),
                                listOf("Válvula de Retenção (Check)", "Fluxo unidirecional automático", "Impede o contrafluxo instantaneamente sem acionador externo.", "Pode sofrer 'slamming' (fechamento brusco) se mal dimensionada.", "Apenas modelos basculantes específicos"),
                                listOf("Válvula Borboleta (Butterfly)", "Bloqueio e modulação leve", "Compacta, leve e econômica para grandes diâmetros em baixa pressão.", "Vedação menos robusta em pressões ultraelevadas.", "NÃO"),
                                listOf("Válvula de Segurança/Alívio (PSV)", "Proteção contra sobrepressão", "Abertura automática rápida ao atingir a pressão de ajuste (set point).", "Exige calibração periódica rigorosa.", "NÃO")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Flanges, Conexões e Classes de Pressão (ASME B16.5)",
                    body = """Os flanges unem seções de tubulações a válvulas, bombas e equipamentos, permitindo fácil desmontagem para manutenção:

Tipos de Flanges Mais Utilizados:
• Flange com Pescoço Soldável (Welding Neck - WN): O mais resistente a fadiga, vibração e flexão; transmite tensões uniformemente à tubulação.
• Flange Sobreposto (Slip-On - SO): Desliza sobre o tubo e é soldado por dentro e por fora; mais econômico, porém menor resistência mecânica.
• Flange Cego (Blind): Utilizado no bloqueio de extremidades de linhas ou bocais de tanques para testes hidrostáticos ou isolamento físico.

Classes de Pressão ASME (Rating):
As classes de pressão padronizadas (150#, 300#, 600#, 900#, 1500#, 2500#) determinam a espessura e a resistência do flange. A pressão máxima de trabalho diminui à medida que a temperatura de operação aumenta!""",
                    bulletPoints = listOf(
                        "Juntas de Vedação: Juntas metálicas espirais (camprofile / flexitallic) com anel de centralização para alta pressão e derivados inflamáveis.",
                        "Estanqueidade: O torqueamento de estojos deve ser realizado em padrão cruzado (estrela) com torquímetro calibrado para evitar empenamento da face do flange."
                    )
                )
            ),
            questions = createDutosTopicQuestions(2, "Dutos e Válvulas")
        )
    }

    private fun createBombasEstacoesChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_3",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 3,
            title = "Capítulo 3 — Bombas Hidráulicas, Estações de Bombeamento e Fenômeno de Cavitação",
            subtitle = "Tópicos 13 e 14: Bombas Centrífugas e Volumétricas, NPSH Requerido vs. Disponível, Curvas Características e Associação",
            readTimeMinutes = 24,
            strategicSummary = "Análise completa do princípio de funcionamento de bombas centrífugas e de deslocamento positivo, cálculo de altura manométrica, verificação de NPSH contra cavitação e associação de bombas em série e em paralelo.",
            highYieldAlerts = listOf(
                "Para evitar cavitação: NPSH_disponível DEVE ser SEMPRE MAIOR que o NPSH_requerido (NPSH_d > NPSH_r com margem de segurança de pelo menos 0,5 a 1,0 m).",
                "Associação de Bombas em SÉRIE: Soma as Alturas Manométricas (H_total = H1 + H2) mantendo a mesma vazão Q. Ideal para vencer grandes perdas de carga ou desníveis altimétricos.",
                "Associação de Bombas em PARALELO: Soma as Vazões (Q_total = Q1 + Q2) mantendo a mesma altura manométrica H. Ideal para aumentar o volume transportado."
            ),
            examTraps = listOf(
                "Afirmar que fechar a válvula de descarga de uma bomba de deslocamento positivo (pistão/engrenagem) reduz a carga no motor. Em bombas volumétricas, fechar a descarga estoura a linha se não houver válvula de alívio!",
                "Confundir cavitação com golpe de aríete: cavitação é a formação e implosão de bolhas de vapor na sucção/rotor por pressão abaixo da pressão de vapor."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Classificação das Bombas em Instalações da Transpetro",
                    body = """As bombas são máquinas geratrizes de fluxo que transferem energia mecânica para o fluido sob a forma de pressão e energia cinética:

1. Bombas Turbomáquinas (Centrífugas / Cinéticas):
• O fluido entra axialmente no centro do rotor (olho do rotor) e é acelerado radialmente pela força centrífuga até a voluta ou difusor, onde a energia cinética se converte em pressão hidrostática.
• São as bombas predominantes nos oleodutos e terminais da Transpetro devido à alta capacidade de vazão contínua, operação suave e facilidade de acoplamento direto a motores elétricos ou turbinas.
• Curva Característica Q × H: A altura manométrica (H) decresce suavemente à medida que a vazão (Q) aumenta.

2. Bombas de Deslocamento Positivo (Volumétricas):
• Deslocam um volume fixo a cada ciclo ou revolução, independente da contrapressão do sistema.
• Subtipos: Bombas de Parafuso (Screw Pumps - ideais para petróleos pesados e viscosos), Bombas de Engrenagens, Bombas de Pistão/Êmbolo (para altíssimas pressões e injeção de produtos químicos).
• Possuem vazão praticamente constante com variação de pressão, exigindo OBRIGATORIAMENTE válvula de alívio de segurança (PSV) na linha de descarga.""",
                    formulas = listOf(
                        FormulaItem(
                            name = "Condição Anti-Cavitação de NPSH",
                            expression = "NPSH_d = (P_atm / γ) ± z_s - (h_fs) - (P_v / γ) > NPSH_r",
                            variables = "P_atm: pressão atmosférica; γ: peso específico do fluido; z_s: cota do nível do tanque à bomba; h_fs: perda de carga na sucção; P_v: pressão de vapor do líquido na temperatura de bombeio.",
                            applicationTip = "Para aumentar o NPSH disponível: eleve o nível do tanque de sucção, reduza o comprimento da tubulação de sucção, aumente o diâmetro da linha ou resfrie o produto."
                        )
                    )
                ),
                ContentSection(
                    title = "2. Estações de Bombeamento e Golpe de Aríete",
                    body = """As Estações de Bombeamento Intermediárias (EBO) ao longo dos oleodutos compensam as perdas de carga por atrito acumuladas ao longo de dezenas de quilômetros:

O Perigo do Golpe de Aríete (Transiente Hidráulico):
Quando uma válvula é fechada bruscamente ou uma bomba desarma de forma repentina, a energia cinética do fluido em movimento se converte em uma onda de sobrepressão de choque que se propaga na velocidade do som no meio líquido (podendo atingir mais de 1.000 m/s no aço).
Dispositivos de Proteção contra Golpe de Aríete:
• Tanques Amortecedores de Onda (Surge Relief Skids com válvulas de alívio de resposta ultrarrápida tipo Axial Surge Relief).
• Tubos de Ventilação e Câmaras de Ar comprimido.
• Válvulas com atuadores de fechamento temporizado e programado em duas velocidades.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: CAVITAÇÃO",
                            content = "Sintomas clássicos de cavitação em bomba centrífuga: ruído característico semelhante a 'bombear brita/pedregulhos', vibração excessiva dos mancais, queda abrupta de vazão e pressão, e erosão mecânica por piteamento nas pás do rotor.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(3, "Bombas e Cavitação")
        )
    }

    private fun createTanquesArmazenamentoChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_4",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 4,
            title = "Capítulo 4 — Tanques de Armazenamento, Tipos de Tetos, Bacias de Contenção e Drenagem",
            subtitle = "Tópicos 15 e 16: Tanques Cilíndricos Verticais (API 650), Tetos Fixos, Flutuantes, Esferas de GLP e NBR 17505",
            readTimeMinutes = 22,
            strategicSummary = "Construção, operação, sistemas de vedação de teto flutuante, drenagem de água de fundo, esferas de GLP e requisitos de segurança de bacias de contenção de terminais.",
            highYieldAlerts = listOf(
                "Tanques de Teto Flutuante são obrigatórios para produtos voláteis (ex: petróleo bruto, gasolina) para eliminar o espaço vapor e reduzir perdas evaporativas e risco de atmosfera explosiva.",
                "Bacia de Contenção: Deve conter o volume do maior tanque da bacia + volume correspondente ao deslocamento dos demais tanques e margem de segurança contra chuvas (NBR 17505).",
                "Drenagem de Água de Fundo (Água Livre decantada): Operação crítica que exige vigilância contínua para não descartar óleo na caixa separadora API."
            ),
            examTraps = listOf(
                "Afirmar que tanques de teto fixo cônico possuem menor risco de emissões fugitivas do que tanques de teto flutuante (o teto flutuante apoia diretamente sobre o líquido, eliminando o colchão de vapor!).",
                "Esquecer que esferas e 'balas' horizontais pressurizadas são destinadas a gases liquefeitos sob pressão (GLP, Propano, Butano), enquanto tanques verticais são para líquidos à pressão atmosférica."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Tipos Construtivos de Tanques em Terminais Terrestres e Aquaviários",
                    body = """Os parques de tanques (tank farms) dos terminais da Transpetro operam conforme normas rigorosas (API 650, API 620, NBR 17505):

1. Tanques de Teto Cônico Fixo:
• Destinados a produtos de baixo ponto de fulgor e baixa volatilidade (ex: óleo diesel, óleo combustível, querosene, resíduos).
• Dotados de válvulas de alívio de pressão e vácuo (corta-chamas / breather valves) que operam em milímetros de coluna de água (mmH₂O) para equalizar as variações de respiração diurna/noturna e operações de carga/descarga.

2. Tanques de Teto Flutuante Externo (EFRT):
• O teto flutua diretamente sobre a superfície do líquido, subindo e descendo conforme o nível do produto no tanque.
• Dotados de sistemas de selagem mecânica primária (selo de sapata metálica ou lâmina líquida) e secundária (selo elastomérico contraintempéries) para vedar o espaço anular entre o teto e o costado.
• Possuem dreno articulado de teto (dreno central) para escoar águas pluviais sem contato com o hidrocarboneto.

3. Tanques de Teto Fixo com Teto Flutuante Interno (IFRT):
• Combinam um teto fixo geodésico de alumínio ou aço na parte superior (que protege contra chuvas e intempéries) e uma membrana flutuante interna sobre o produto. Ideal para gasolina e solventes em regiões chuvosas.

4. Esferas e Cilindros Pressurizados (API 620 / ASME VIII):
• Armazenam GLP (Propano e Butano) em fase líquida sob pressões de 8 a 18 kgf/cm² à temperatura ambiente.""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo de Tipos de Tanques e Produtos Armazenados",
                            headers = listOf("Tipo de Tanque", "Produtos Típicos", "Sistema de Vedação / Alívio", "Risco Operacional Principal"),
                            rows = listOf(
                                listOf("Teto Cônico Fixo", "Óleo Diesel, Bunker, Óleo Cru Pesado", "Válvula de Pressão e Vácuo (PVV) + Corta-chamas", "Colapso por vácuo em descarga rápida sem ventilação"),
                                listOf("Teto Flutuante Externo", "Petróleo Leve, Gasolina A, Nafta", "Selo Primário + Selo Secundário + Dreno de Teto", "Afundamento de teto por água de chuva ou emperramento"),
                                listOf("Teto Fixo c/ Membrana Interna", "Etanol Anidro, Gasolina C, QAV-1", "Selo periférico interno + ventilações no domo", "Acúmulo de vapor inflamável entre a membrana e o domo"),
                                listOf("Esfera Pressurizada", "GLP (Propano/Butano comercial)", "Válvulas de Alívio de Segurança duplas (PSV)", "BLEVE (Boiling Liquid Expanding Vapor Explosion) em incêndio")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Bacias de Contenção, Paredes Corta-Fogo e Drenagem Oleosa",
                    body = """Requisitos Estruturais e de SMS em Parques de Tanques:
• Bacia de Contenção Estanque: Pavimentada e impermeabilizada com solo compactado ou geomembrana de PEAD, impedindo que vazamentos alcancem o lençol freático.
• Parede Corta-Fogo / Diques Intermediários: Subdividem a bacia de contenção em compartimentos menores para conter derramamentos localizados e evitar que o fogo de um tanque atinja tanques vizinhos.
• Sistema de Drenagem Segregada:
  - Drenagem Pluvial Limpa: Coleta água de chuva fora das bacias e direciona para descarte ambiental.
  - Drenagem Oleosa: Coleta água contaminada e efluentes das bacias de contenção, direcionando para a Caixa Separadora de Água e Óleo (CSAO / Separador API) antes do tratamento final.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: RISCO DE AFUNDAMENTO DE TETO FLUTUANTE",
                            content = "Em caso de fortes temporais, o dreno central do teto flutuante DEVE estar com a válvula de bloqueio aberta e desobstruída. O acúmulo de lâmina d'água superior a poucos centímetros pode sobrecarregar a estrutura e afundar o teto, provocando derramamento catastrófico de petróleo.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(4, "Tanques de Armazenamento")
        )
    }

    private fun createMedicaoInstrumentacaoAutomacaoChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_5",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 5,
            title = "Capítulo 5 — Medição de Vazão, Pressão, Nível, Temperatura e Instrumentação Industrial",
            subtitle = "Tópicos 17 a 22: Medidores Coriolis, Turbina, Ultrassônico, Placa de Orifício, Transmissores 4-20 mA e Protocolo HART",
            readTimeMinutes = 24,
            strategicSummary = "Instrumentos primários de medição de grandezas físicas de processos petrolíferos, medição de custódia (fiscal e operacional), calibração por Provadores Compactos (Provers) e malhas de controle PID.",
            highYieldAlerts = listOf(
                "Medidores de Vazão Mássica por Efeito Coriolis medem diretamente a massa (kg/h) e a densidade em tempo real, independentemente da temperatura, pressão ou viscosidade do óleo.",
                "Medidores por Placa de Orifício baseiam-se na Equação de Bernoulli e na perda de pressão diferencial (ΔP) gerada pela restrição no fluxo (a vazão Q é proporcional à raiz quadrada de ΔP).",
                "O sinal analógico padrão da instrumentação de campo é 4 a 20 mA (com 'zero vivo' em 4 mA para diferenciar leitura zero de fio rompido)."
            ),
            examTraps = listOf(
                "Achar que medidor ultrassônico por tempo de trânsito funciona bem com fluidos contendo grande quantidade de sólidos em suspensão ou bolhas de gás (o tempo de trânsito exige fluidos limpos; fluidos com sólidos usam ultrassom Doppler!).",
                "Esquecer que a medição fiscal de petróleo exige correção do volume medido para a temperatura padrão de 20 °C (no Brasil, Portaria Conjunta ANP/Inmetro nº 01/2000)."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Medição de Vazão em Transferência de Custódia e Operações de Dutos",
                    body = """A medição de vazão na Transpetro divide-se em Medição Fiscal/Apropriação (com exigência legal de altíssima exatidão, incerteza < 0,1% a 0,3%) e Medição Operacional:

1. Medidores de Efeito Coriolis (Mássicos):
• Tubos oscilantes em vibração ressonante. Quando o fluido escoa pelo tubo em vibração, forças de Coriolis causam uma defasagem angular proporcional à vazão mássica direta.
• Vantagens: Mede massa e densidade simultaneamente sem partes móveis em contato com o fluido; ideal para transferência de custódia de óleos brutos e derivados.

2. Medidores Tipo Turbina (Volumétricos):
• Um rotor com pás helicoidais gira a uma velocidade angular proporcional à velocidade do fluxo linear. Um sensor indutivo capta a frequência dos pulsos gerados pelas pás.
• Fator K do medidor (pulsos por m³). Exige retificadores de fluxo e calibração periódica por Provador de Duto (Pipe Prover / Compact Prover).

3. Medidores Ultrassônicos Multipath (Tempo de Trânsito):
• Utilizam múltiplos pares de transdutores acústicos que emitem pulsos de alta frequência a favor e contra o fluxo. A diferença de tempo de propagação determina a velocidade média do escoamento.
• Padrão absoluto na medição de gás natural em gasodutos e grandes oleodutos de transporte.

4. Medidores de Pressão Diferencial (Placa de Orifício e Venturi):
• Norma ISO 5167 / AGA Report No. 3.
• Relação: Q = K · √(ΔP / ρ).""",
                    formulas = listOf(
                        FormulaItem(
                            name = "Equação Fundamental da Placa de Orifício",
                            expression = "Q_v = C_d · E · (π · d² / 4) · √(2 · ΔP / ρ)",
                            variables = "C_d: coeficiente de descarga; E: fator de aproximação da velocidade; d: diâmetro do orifício; ΔP: pressão diferencial; ρ: massa específica do fluido.",
                            applicationTip = "Se a pressão diferencial ΔP quadruplicar (fator 4), a vazão Q apenas dobra (pois √4 = 2)."
                        )
                    )
                ),
                ContentSection(
                    title = "2. Medição de Nível de Tanques e Instrumentação de Campo",
                    body = """Sistemas de Medição de Nível Automática de Tanques (Tank Gauging):
• Medição por Radar de Onda Livre (26 GHz / 80 GHz): Emite pulsos eletromagnéticos que refletem na superfície do óleo; sem contato mecânico, imune a variações de densidade.
• Medição por Servo-Posicionador: Um pequeno flutuador (displacer) é suspenso por um fio metálico conectado a um tambor de altíssima sensibilidade de torque. Mede nível, perfil de temperatura e densidade por estratificação.
• Medição Hidrostática: Transmissores de pressão manométrica diferencial instalados no fundo do tanque (P = ρ · g · h).

Instrumentação Eletrônica e Protocolos:
• Padrão 4 a 20 mA com 'Zero Vivo': 4 mA representa 0% da faixa de medição (Low Range Value) e 20 mA representa 100% (High Range Value). Se o transmissor emitir 0 mA, o sistema acusa falha de cabo quebrado (open circuit).
• Protocolo HART (Highway Addressable Remote Transducer): Modula sinal digital FSK (Bell 202) sobreposto à corrente analógica 4-20 mA sem interferir na malha de controle, permitindo calibração e diagnóstico remoto.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: CHAVES DE NÍVEL DE SEGURANÇA (HH E LL)",
                            content = "Todo tanque de petróleo possui sistemas independentes de intertravamento de segurança (SIS / SIL): Chave de Nível Muito Alto (LSHH) que fecha as válvulas de entrada para evitar transbordamento, e Chave de Nível Muito Baixo (LSLL) que desliga as bombas para impedir sucção em seco e cavitação.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(5, "Instrumentação e Medição")
        )
    }

    private fun createOperacoesTerminaisDutosChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_6",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 6,
            title = "Capítulo 6 — Operação de Dutos, Terminais Terrestres, Transferências e Pigging",
            subtitle = "Tópicos 23 a 31: Recebimento, Expedição, Operação em Batelada (Batching), Lançadores/Recebedores de PIG e Bases de Carregamento",
            readTimeMinutes = 24,
            strategicSummary = "Procedimentos de alinhamento de linhas, manobras de válvulas, controle de interfaces em polidutos, lançamento e recebimento de PIGs de limpeza e instrumentados, e bases de carregamento rodoviário (Top/Bottom Loading).",
            highYieldAlerts = listOf(
                "Lançador e Recebedor de PIG (Scraper Trap): Equipamentos pressurizados dotados de porta de fechamento rápido com intertravamento de segurança para não abrir pressurizado.",
                "PIGs Inteligentes (MFL - Fluxo Magnético Disperso e UT - Ultrassom): Mapeiam tridimensionalmente a espessura da parede do duto, corrosão interna/externa, amassamentos e trincas.",
                "Bottom Loading (Carregamento por Baixo): Sistema moderno em caminhões-tanque com acopladores secos (dry break), menor geração de vapores inflamáveis e recuperação de vapores (URV)."
            ),
            examTraps = listOf(
                "Abrir a porta rápida do lançador de PIG sem verificar a purga e o manômetro de pressão zero (risco de ejeção violenta e morte).",
                "Descartar a interface entre produtos nobres (ex: Gasolina e Diesel) sem respeitar a janela de corte de densidade estipulada pelo CCO."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Operações de Pigging (Inspeção e Limpeza de Dutos)",
                    body = """O PIG (Pipeline Inspection Gauge) é uma ferramenta que se desloca no interior do duto impulsionada pela própria pressão do fluido movimentado:

Tipos de PIGs:
1. PIGs Utilitários / de Limpeza (Foam, Mandrel, Escovas):
• Removem depósitos de parafina, borra de petróleo, água acumulada em pontos baixos e carepa de laminação.
• PIGs Esfera: Utilizados para separação física de bateladas e remoção de bolsas de ar durante o enchimento do duto.

2. PIGs Instrumentados / Inteligentes:
• PIG Geométrico (Caliper PIG): Mede deformações geométricas, ovalizações, mossas e restrições internas.
• PIG MFL (Magnetic Flux Leakage): Magnetiza a parede do duto de aço. Em regiões com perda de espessura por corrosão, as linhas de campo magnético vazam para fora do metal, sendo captadas por sensores de efeito Hall.
• PIG Ultrassônico (UT): Mede diretamente a espessura da parede através de transdutores piezoelétricos imersos em meio líquido.

Sequência Operacional de Lançamento de PIG:
1. Isolar o Lançador fechando as válvulas de bloqueio e equalização.
2. Despressurizar e drenar o barril do lançador para o sistema de slop.
3. Abrir a tampa de fechamento rápido e introduzir o PIG até que sua taça traseira encoste na redução da linha.
4. Fechar e travar a tampa rápida; equalizar a pressão abrindo a linha de desvio (kicker line).
5. Abrir a válvula de bloqueio principal do lançador e direcionar o fluxo através da kicker line, impulsionando o PIG para o tronco do duto.""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo: Carregamento Rodoviário Top Loading vs. Bottom Loading",
                            headers = listOf("Parâmetro", "Top Loading (Por Cima)", "Bottom Loading (Por Baixo)"),
                            rows = listOf(
                                listOf("Ponto de Conexão", "Bocal superior da escotilha aberta", "Válvulas API de engate rápido na parte inferior"),
                                listOf("Geração de Eletricidade Estática", "Elevada (devido ao respingo e queda livre)", "Mínima (enchimento por submersão com defletor)"),
                                listOf("Emissão de Vapores", "Emissão direta para a atmosfera", "Totalmente fechado com linha de retorno para URV"),
                                listOf("Ergonomia e Segurança", "Operador trabalha em altura sobre o caminhão", "Operador trabalha no solo com braços articulados e aterramento monitorado"),
                                listOf("Velocidade de Enchimento", "Limitada a ~ 1.500 L/min", "Alta: até 2.500 L/min por braço com corte óptico de sobre-enchimento")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Bateladas (Batching) e Transferências entre Tanques",
                    body = """Em polidutos, diferentes derivados (ex: Gasolina, Nafta, Diesel) são bombeados sequencialmente sem barreira física mecânica:

Controle da Interface de Batelada:
• No ponto de contato entre dois fluidos miscíveis, forma-se uma zona de mistura (interface) cujo comprimento cresce proporcionalmente à raiz quadrada da distância percorrida (Regime Turbulento com Re > 10.000 é mandatório para minimizar a espessura da interface).
• No terminal de chegada, densímetros de linha contínuos (tipo diapasão ressonante) monitoram a variação de densidade milimétrica em tempo real para acionar as válvulas de corte rápido, desviando o produto nobre para o tanque correspondente e a interface contaminada para tanques de repassagem/slop.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: ATERRAMENTO EM BASES DE CARREGAMENTO",
                            content = "Antes de qualquer manobra de conexão de mangote ou braço de carga, a garra de aterramento elétrico com monitoramento de continuidade estática (Scully) DEVE estar conectada ao chassi do caminhão-tanque para dissipar cargas eletrostáticas.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(6, "Operação e Pigging")
        )
    }

    private fun createOperacoesAquaviariasNaviosChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_7",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 7,
            title = "Capítulo 7 — Operações Aquaviárias, Terminais Marítimos, Navios Petroleiros e Monobóias",
            subtitle = "Tópicos 26 e 32: Píeres de Atracação, Braços Marítimos de Carregamento, Monobóias (CALM), Mangotes Flutuantes e Gás Inerte",
            readTimeMinutes = 24,
            strategicSummary = "Logística aquaviária da Transpetro, infraestrutura de píeres, monobóias em mar aberto, operação de braços rígidos com sistema de desconexão de emergência (PERC / ERC), sistema de gás inerte (IGS) e regras ISGOTT.",
            highYieldAlerts = listOf(
                "Sistema de Gás Inerte (IGS): Mantém o teor de oxigênio nos tanques de carga do navio abaixo de 8% em volume (e idealmente < 5%) para impedir formação de atmosfera explosiva.",
                "Braços de Carregamento Marítimo (Marine Loading Arms - MLA): Dotados de sistema de desconexão rápida de emergência (ERC/PERC) com dupla válvula de bloqueio que se desconecta automaticamente em caso de afastamento excessivo do navio.",
                "Monobóia tipo CALM (Catenary Anchor Leg Mooring): Permite que o navio petroleiro gire 360° em torno da bóia alinhando-se à direção do vento e das correntes (efeito 'veleta' / weathervaning)."
            ),
            examTraps = listOf(
                "Achar que o sistema de gás inerte apaga fogo; ele serve PREVENTIVAMENTE para inertizar a atmosfera dos tanques substituindo o oxigênio por gases de combustão purificados ou nitrogênio.",
                "Confundir operações de deslastro limpo com deslastro segregado (navios modernos possuem tanques de lastro segregados - SBT, que nunca entram em contato com petróleo)."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Píeres, Braços de Carga Marítimos e Segurança ISGOTT",
                    body = """Os terminais aquaviários da Transpetro (ex: Terminal de Angra dos Reis - Tebig, Terminal de São Sebastião - Tebar, Terminal de Madre de Deus - Temadre) operam sob rigorosas diretrizes internacionais (ISGOTT - International Safety Guide for Oil Tankers and Terminals):

1. Braços Marítimos de Carregamento (MLA):
• Estruturas metálicas articuladas autoportantes com juntas giratórias (swivel joints) de alta flexibilidade que acompanham os movimentos da maré, calado do navio e ondulação.
• Sistema ERS / PERC (Powered Emergency Release Coupler): Em caso de emergência (rompimento de amarras, incêndio), duas válvulas esfera fecham simultaneamente em menos de 5 segundos e o engate hidráulico libera o braço sem derramamento de produto no mar.

2. Lista de Verificação de Segurança Navio/Terminal (Ship/Shore Safety Checklist - SSSCL):
• Acordo operacional prévio assinado pelo Comandante/Imediato do navio e pelo Operador do Terminal da Transpetro antes de abrir qualquer válvula.
• Define taxas máximas de vazão, pressões limites de bombeamento, procedimento de parada de emergência (ESD - Emergency Shutdown) e canais de rádio VHF dedicados.""",
                    tables = listOf(
                        TableItem(
                            title = "Tipos de Navios Petroleiros da Frota Transpetro",
                            headers = listOf("Classe de Navio", "Porte Bruto (TPB / DWT)", "Comprimento Típico", "Aplicação Operacional"),
                            rows = listOf(
                                listOf("Handysize / Costeiro", "10.000 a 45.000 DWT", "120 a 180 m", "Cabotagem de derivados claros e escuros entre portos brasileiros."),
                                listOf("Panamax", "60.000 a 80.000 DWT", "220 a 230 m", "Transporte de óleo combustível e derivados pesados."),
                                listOf("Aframax", "80.000 a 120.000 DWT", "240 a 250 m", "Escoamento de petróleo cru das bacias marítimas para refinarias."),
                                listOf("Suezmax", "120.000 a 160.000 DWT", "270 a 280 m", "Grandes lotes de exportação e cabotagem oceânica de óleo bruto."),
                                listOf("VLCC (Very Large Crude Carrier)", "200.000 a 320.000 DWT", "330 m+", "Alívio de plataformas FPSO de grande calado em mar aberto.")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Operações em Monobóias e Ship-to-Ship (STS)",
                    body = """Monobóias Marítimas (CALM Buoy):
• Instaladas em alto-mar em lâminas d'água profundas (20 a 50+ metros) para permitir a amarração de grandes navios que não conseguem atracar em píeres rasos.
• O petróleo é transferido do navio através de mangotes marítimos flutuantes até a cabeça giratória da monobóia (swivel), descendo por mangotes submarinos (em configuração 'lazy-S' ou 'steep-S') até o PLEM (Pipeline End Manifold) no fundo do mar, seguindo por oleoduto submarino até o terminal em terra.

Operações Ship-to-Ship (STS):
• Transferência direta de petróleo entre dois navios petroleiros atracados a contrabordo em área abrigada autorizada pela Marinha do Brasil e órgãos ambientais, utilizando defensas pneumáticas Yokohama e mangotes especiais certificados.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: SISTEMA DE GÁS INERTE (IGS)",
                            content = "A atmosfera de um tanque de navio petroleiro só é considerada segura contra explosão quando o teor de Oxigênio (O₂) é inferior a 8% em volume e a pressão interna é mantida ligeiramente positiva para evitar entrada de ar atmosférico.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(7, "Operações Aquaviárias")
        )
    }

    private fun createSmsSegurancaMeioAmbienteChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_8",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 8,
            title = "Capítulo 8 — Segurança Operacional, SMS, Prevenção de Acidentes e Emergências",
            subtitle = "Tópicos 33 a 40: NR-20, NR-33, NR-35, Sistemas de Combate a Incêndio (LGE), Contenção de Derramamentos e PEI",
            readTimeMinutes = 24,
            strategicSummary = "Normas Regulamentadoras aplicadas a plantas petrolíferas, Permissão de Trabalho (PT), Análise Preliminar de Risco (APR), Sistemas de Espuma Mecânica (LGE), Barreiras de Contenção, Skimmers e Plano de Emergência Individual (PEI).",
            highYieldAlerts = listOf(
                "Tetraedro do Fogo: Combustível + Comburente (O₂) + Calor (Fonte de Ignição) + Reação em Cadeia.",
                "Classes de Incêndio: Classe B (Líquidos Inflamáveis) combate-se prioritariamente com Espuma Mecânica (LGE) ou Pó Químico Seco (PQS) — NUNCA com jato pleno de água!",
                "NR-33 (Espaço Confinado): Exige Permissão de Entrada e Trabalho (PET), medição contínua da atmosfera (O₂, inflamabilidade LEL, gases tóxicos H₂S e CO) e vigia externo permanente."
            ),
            examTraps = listOf(
                "Jogar jato sólido de água em tanque de óleo inflamável: Provoca o fenômeno de 'Boilover' ou 'Slopover', ejetando violentamente óleo em chamas a centenas de metros de distância!",
                "Confundir Limite Inferior de Inflamabilidade (LEL / LII) com Limite Superior (UEL / LSI). Se a concentração de gás estiver abaixo do LEL, a mistura é muito pobre para queimar; se estiver acima do UEL, é muito rica; entre o LEL e o UEL, a explosão é iminente."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Sistemas de Combate a Incêndio em Parques de Tanques",
                    body = """Os sistemas de combate a incêndio da Transpetro são projetados conforme normas ABNT NBR 17505 e NFPA 11/15/30:

1. Espuma Mecânica (LGE - Líquido Gerador de Espuma):
• Formada pela mistura de Água + Concentrado de LGE (geralmente dosagem de 3% ou 6%) + Ar introduzido por câmaras de espuma.
• Mecanismo de Extinção: Cria um colchão flutuante espesso e coeso sobre a superfície do líquido inflamável, agindo por ABAFAMENTO (isolando os vapores do oxigênio) e RESFRIAMENTO (pela água presente na espuma).
• Tipos de LGE: AFFF (Aqueous Film Forming Foam) e AR-AFFF (Resistente a Álcool, mandatório para etanol e misturas com solventes polares).

2. Sistema de Resfriamento por Água:
• Anéis de aspersores (sprinklers / deluge) instalados no costado e no teto dos tanques vizinhos ao tanque sinistrado para absorver o calor radiante e evitar a perda de resistência mecânica do aço.""",
                    tables = listOf(
                        TableItem(
                            title = "Classes de Fogo e Agentes Extintores Recomendados",
                            headers = listOf("Classe", "Tipo de Material Combustível", "Agente Extintor Principal", "Ação Proibida"),
                            rows = listOf(
                                listOf("Classe A", "Sólidos combustíveis (madeira, papel, tecido)", "Água pressurizada (resfriamento)", "Não usar em eletricidade energizada"),
                                listOf("Classe B", "Líquidos inflamáveis (gasolina, diesel, óleo cru)", "Espuma Mecânica (LGE), PQS, CO₂", "JATO SÓLIDO DE ÁGUA PROIBIDO"),
                                listOf("Classe C", "Equipamentos elétricos energizados (painéis, CCO)", "Gás Carbônico (CO₂), Pós especiais (PQS)", "ÁGUA CONDUTIVA PROIBIDA"),
                                listOf("Classe D", "Metais pirofóricos (magnésio, titânio, sódio)", "Pó químico especial Classe D", "Água e extintores comuns proibidos")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Contenção de Vazamentos no Mar e Plano de Emergência Individual (PEI)",
                    body = """Conforme a Resolução CONAMA nº 398/2008, todas as instalações portuárias e terminais petrolíferos possuem um Plano de Emergência Individual (PEI):

Equipamentos de Resposta a Emergências com Óleo no Mar:
• Barreiras de Contenção (Booms): Barreiras flutuantes com saias submersas que cercam e confinam a mancha de óleo na água, impedindo que atinja praias ou manguezais.
• Recolhedores de Óleo (Skimmers): Equipamentos mecânicos (oleofílicos de disco, escova ou vertedouro) que succionam a camada de óleo flutuante na água e a bombeiam para tanques de recolhimento temporário.
• Barreiras e Mantas Absorventes: Fibras sintéticas hidrofóbicas (absorvem óleo e repelem água) para recolhimento de pequenas manchas e acabamento.
• Dispersantes Químicos: Substâncias tensoativas aplicadas por embarcações especiais com autorização expressa do órgão ambiental (IBAMA) para fragmentar o óleo em microgotículas biodegradáveis em alto-mar.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: DIREITO DE RECUSA AO TRABALHO INSEGURO",
                            content = "Na Transpetro e no Sistema Petrobras, qualquer trabalhador tem o DEVER e o DIREITO DE RECUSA formal de interromper imediatamente qualquer atividade operacional que apresente risco grave e iminente à sua vida, à de colegas ou ao meio ambiente, sem sofrer qualquer retaliação.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(8, "SMS e Emergências")
        )
    }

    private fun createIntegridadeCorrosaoInspecaoChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_9",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 9,
            title = "Capítulo 9 — Integridade de Dutos, Corrosão, Proteção Catódica e Ensaios Não Destrutivos",
            subtitle = "Tópicos 41 a 47: Mecanismos Eletroquímicos de Corrosão, Proteção Catódica por Anodo de Sacrifício e Corrente Impressa, ENDs (UT, PM, LP, RX)",
            readTimeMinutes = 24,
            strategicSummary = "Ciência da corrosão em dutos enterrados e aéreos, potencial de proteção tubo-solo, dimensionamento de leitos de anodos, revestimentos anticorrosivos (FBE, PEAD tripla camada) e ensaios não destrutivos de soldas e chapas.",
            highYieldAlerts = listOf(
                "Critério de Proteção Catódica para Aço Carbono no Solo: Potencial tubo-solo polarizado mais negativo que -850 mV em relação ao eletrodo de referência de Cobre/Sulfato de Cobre (Cu/CuSO₄).",
                "Proteção por Corrente Impressa: Utiliza fonte retificadora externa de corrente contínua e anodos inertes de titânio/grafite; ideal para dutos longos de centenas de quilômetros.",
                "Proteção Galvânica (Anodo de Sacrifício): Baseia-se na diferença de potencial natural entre o aço e metais menos nobres (Zinco, Alumínio, Magnésio); dispensa energia elétrica externa."
            ),
            examTraps = listOf(
                "Achar que o duto protegido catodicamente atua como anodo. Na proteção catódica, a tubulação é conectada ao polo NEGATIVO para atuar como CÁTODO (onde ocorrem reações de redução que não desgastam o metal!).",
                "Confundir Ensaio por Líquido Penetrante (LP) com Ultrassom (UT). O LP detecta APENAS descontinuidades abertas para a superfície; descontinuidades internas exigem Ultrassom ou Radiografia."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Corrosão Eletroquímica e Proteção Catódica",
                    body = """A corrosão é a deterioração espontânea do metal pela reação com o eletrólito circundante (solo úmido ou água do mar).

Componentes de uma Pilha de Corrosão:
1. Ânodo: Região do metal onde ocorre OXIDAÇÃO (perda de elétrons e dissolução de íons metálicos: Fe → Fe²⁺ + 2e⁻). É o ponto que sofre o desgaste!
2. Cátodo: Região onde ocorre REDUÇÃO (ganho de elétrons, sem perda de metal: 2H₂O + O₂ + 4e⁻ → 4OH⁻).
3. Eletrólito: Solo ou água contendo íons que permite a condução iônica.
4. Conexão Metálica: O próprio duto que permite a condução elétrica de elétrons do anodo ao cátodo.

Métodos de Proteção Anticorrosiva:
• Revestimentos Passivos: Barreira física de altíssima rigidez dielétrica aplicada na fábrica (Polietileno Tripla Camada - 3LPE ou FBE - Fusion Bonded Epoxy).
• Proteção Catódica Ativa: Complementa o revestimento nas falhas inevitáveis (holidays). Transforma toda a superfície da tubulação de aço em cátodo de uma célula eletroquímica artificial.""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo: Proteção Catódica Galvânica vs. Corrente Impressa",
                            headers = listOf("Característica", "Anodos de Sacrifício (Galvânica)", "Corrente Impressa (Impressed Current)"),
                            rows = listOf(
                                listOf("Fonte de Energia", "Dispensa energia elétrica externa", "Exige fonte retificadora de Corrente Contínua (CC) ligada à rede"),
                                listOf("Metais dos Ânodos", "Zinco, Alumínio (água do mar), Magnésio (solo)", "Ânodos inertes: Titânio com óxidos metálicos mistos (MMO), Grafite"),
                                listOf("Alcance / Aplicação", "Pequenas estruturas, tanques, píeres locais", "Dutos de centenas de quilômetros de alta demanda"),
                                listOf("Controle e Ajuste", "Fixo pela natureza química do anodo", "Tensão e corrente totalmente ajustáveis no retificador"),
                                listOf("Risco de Interferência", "Praticamente nulo em estruturas vizinhas", "Exige cuidado contra correntes de fuga (interferência catódica)")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Ensaios Não Destrutivos (END) em Dutos e Instalações",
                    body = """Os Ensaios Não Destrutivos inspecionam juntas soldadas e espessuras sem danificar a peça:

• Ensaio Visual (VT): Primeiro ensaio obrigatório para identificar desalinhamentos, mordeduras e porosidades superficiais.
• Ensaio por Líquido Penetrante (PT/LP): Baseado na capilaridade. Aplica-se um líquido vermelho de alto poder penetrante e, após limpeza, um revelador branco. Detecta trincas e descontinuidades abertas para a superfície.
• Ensaio por Partículas Magnéticas (MT/PM): Aplicável apenas a materiais ferromagnéticos. Magnetiza-se a peça (Yoke) e aplicam-se partículas de ferro (secas ou fluorescentes). Detecta trincas superficiais e subsuperficiais (até poucos milímetros).
• Ensaio por Ultrassom (UT e Phased Array): Ondas acústicas de alta frequência refletem em descontinuidades internas e na parede oposta, permitindo medição exata de espessura remanescente e detecção tridimensional de defeitos no cordão de solda.
• Radiografia Industrial (RT - Raios X e Gamagrafia): Radiação ionizante projeta a imagem interna da solda em filme radiográfico, gerando registro permanente.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: TESTE HIDROSTÁTICO",
                            content = "Antes de entrar em operação comercial, todo duto novo ou reparado é submetido ao Teste Hidrostático com água a uma pressão de 125% a 150% da Pressão Máxima de Operação Admissível (PMO / MAOP) durante 8 a 24 horas contínuas para comprovar estanqueidade e resistência estrutural.",
                            iconType = "TECH"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(9, "Integridade e Corrosão")
        )
    }

    private fun createAutomacaoCcoGestaoRiscosChapter(): EBookChapter {
        return EBookChapter(
            id = "dutos_cap_10",
            partId = "part_5",
            partNumber = 5,
            partTitle = "PARTE 5 — CONHECIMENTOS ESPECÍFICOS: DUTOS E TERMINAIS",
            chapterNumber = 10,
            title = "Capítulo 10 — Automação, Sistemas SCADA, Centro de Controle Operacional (CCO) e Gestão de Riscos",
            subtitle = "Tópicos 48 a 52: CLP/RTU, Redes Industriais, Detecção de Vazamentos (LDS), CCO Centralizado, APR, HAZOP e Matriz de Riscos",
            readTimeMinutes = 24,
            strategicSummary = "Arquitetura do Centro de Controle Operacional (CCO) da Transpetro, sistemas de supervisão SCADA, detecção computadorizada de vazamentos, protocolos de automação e ferramentas de análise de risco operacional (HAZOP, APR, FMEA).",
            highYieldAlerts = listOf(
                "O Centro de Controle Operacional (CCO) monitora e controla remotamente 24 horas por dia válvulas, bombas e parâmetros de pressão de toda a malha dutoviária nacional.",
                "Sistemas de Detecção de Vazamentos (LDS - Leak Detection Systems): Utilizam algoritmos de balanço de massa transiente em tempo real (RTTM) e análise de ondas de pressão acústica.",
                "HAZOP (Hazard and Operability Study): Metodologia indutiva e estruturada baseada em palavras-guia (Mais, Menos, Nenhum, Reverso) para identificar desvios de processo em tubulações e plantas industriais."
            ),
            examTraps = listOf(
                "Confundir APR com HAZOP: A APR (Análise Preliminar de Risco) é feita no início do projeto ou antes de tarefas de campo para identificar perigos gerais; o HAZOP é uma análise detalhada e multidisciplinar do diagrama de tubulação e instrumentação (P&ID).",
                "Afirmar que a automação substitui totalmente o operador de campo. A automação fornece comandos remotos e proteção de emergência (ESD), mas a manutenção e inspeção física de campo são insubstituíveis."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Arquitetura de Automação, SCADA e Detecção de Vazamentos (LDS)",
                    body = """O sistema de automação da Transpetro opera em camadas hierárquicas interconectadas:

1. Nível 1 — Instrumentação e Atuadores de Campo:
• Transmissores inteligentes de vazão, pressão, temperatura e nível, válvulas com atuadores eletro-hidráulicos inteligentes e detectores de gás inflamável/H₂S.

2. Nível 2 — Unidades Remotas de Telemetria (UTRs / RTUs) e CLPs:
• Controladores Lógicos Programáveis instalados nas estações de bombeamento e válvulas de bloqueio intermediário ao longo dos dutos que executam lógicas locais de controle e intertravamentos de segurança.

3. Nível 3 — Sistema SCADA Centralizado no CCO:
• Servidores redundantes que recebem dados via satélite e fibra óptica, apresentando telas sinópticas interativas aos operadores do CCO. Permite o comando remoto de abertura/fechamento de válvulas e partida/parada de bombas a milhares de quilômetros de distância.

4. Módulo LDS (Leak Detection System):
• Compara continuamente a vazão injetada na origem com a vazão recebida no destino corrigidas por temperatura e pressão. Qualquer desbalanço de massa não justificado gera alarme imediato de suspeita de vazamento e calcula a localização geográfica provável da ruptura.""",
                    tables = listOf(
                        TableItem(
                            title = "Tabela de Palavras-Guia Utilizadas no Estudo de HAZOP",
                            headers = listOf("Palavra-Guia", "Parâmetro de Processo", "Desvio Identificado", "Consequência Típica em Dutos"),
                            rows = listOf(
                                listOf("NENHUM (No)", "Fluxo / Vazão", "Sem fluxo de produto", "Bloqueio acidental de válvula; cavitação de bomba"),
                                listOf("MAIS (More)", "Pressão", "Sobrepressão na linha", "Ruptura de duto; abertura de válvula de segurança (PSV)"),
                                listOf("MENOS (Less)", "Temperatura", "Queda de temperatura", "Cristalização de parafina em óleo cru; aumento de viscosidade"),
                                listOf("REVERSO (Reverse)", "Direção do Fluxo", "Contrafluxo de produto", "Falha de válvula de retenção; contaminação de tanques"),
                                listOf("OUTRO QUE NÃO (Other)", "Composição", "Produto fora de especificação", "Contaminação de batelada de combustível nobre")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Gestão de Riscos Operacionais e Ferramentas de Análise",
                    body = """A Transpetro adota ferramentas estruturadas de confiabilidade e gestão de riscos:

• Análise Preliminar de Risco (APR / JSA): Identifica perigos, causas, modos de detecção e medidas de controle antes da emissão da Permissão de Trabalho (PT).
• Matriz de Risco (Probabilidade × Severidade): Classifica os cenários acidentais em faixas de risco Tolerável, Moderado e Crítico (intolerável).
• FMEA / FMECA (Failure Modes, Effects and Criticality Analysis): Mapeia os modos de falha de componentes mecânicos (ex: selos mecânicos de bombas, mancais) e seu impacto na continuidade operacional.
• Sistema de Parada de Emergência (ESD - Emergency Shutdown): Botões tipo 'soco de emergência' e lógicas automáticas SIL que desenergizam bombas e fecham válvulas de bloqueio de área em fração de segundos para confinar incidentes.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO PARA A PROVA: ALARMES E CULTURA DE SEGURANÇA",
                            content = "Na operação do CCO da Transpetro, nenhum alarme crítico de sobrepressão ou variação de vazão pode ser silenciado ou ignorado sem a devida investigação e registro formal de ocorrência.",
                            iconType = "ALERT"
                        )
                    )
                )
            ),
            questions = createDutosTopicQuestions(10, "Automação e Gestão de Riscos")
        )
    }

    private fun createDutosTopicQuestions(chapNum: Int, topicName: String): List<PracticeQuestion> {
        return listOf(
            PracticeQuestion(
                id = "dutos_q_${chapNum}_1",
                code = "DUTOS-$chapNum-01",
                subject = "Dutos e Terminais",
                topic = topicName,
                difficulty = "Médio",
                statement = "Em relação às operações de transporte dutoviário e armazenamento de petróleo e derivados operadas pela Transpetro, assinale a opção tecnicamente correta:",
                options = listOf(
                    "A) Petróleos com grau °API mais elevado (ex: 38 °API) possuem maior densidade relativa do que petróleos pesados de 18 °API.",
                    "B) O NPSH disponível de uma instalação de bombeamento deve ser rigorosamente menor que o NPSH requerido pelo fabricante para prevenir a ocorrência de cavitação.",
                    "C) As válvulas de esfera de passagem plena (Full Bore) são instaladas em linhas troncais de oleodutos por permitirem a passagem desimpedida de ferramentas de inspeção (PIGs).",
                    "D) Os tanques de teto cônico fixo são os mais indicados para armazenar gasolina automotiva em virtude de sua alta volatilidade e pressão de vapor.",
                    "E) O ensaio não destrutivo por líquido penetrante permite quantificar a profundidade de trincas e vazios volumétricos internos no interior de cordões de solda."
                ),
                correctIndex = 2,
                detailedExplanation = "A alternativa C está correta: válvulas de esfera de passagem plena oferecem abertura circular desimpedida idêntica ao diâmetro interno do tubo, permitindo o trânsito livre de PIGs de limpeza e instrumentados.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: O grau °API é inversamente proporcional à densidade; logo, 38 °API é um óleo LEVE e menos denso.",
                    1 to "Incorreto: O NPSH disponível DEVE ser MAIOR que o requerido (NPSH_d > NPSH_r) para evitar cavitação.",
                    3 to "Incorreto: Gasolinas exigem tanques de teto flutuante para conter perdas por evaporação; tetos fixos são para derivados de baixa volatilidade (diesel, bunker).",
                    4 to "Incorreto: Líquido penetrante detecta APENAS descontinuidades superficiais abertas, e não internas."
                ),
                highYieldTip = "Lembre-se: Passagem de PIG = Válvula de Esfera Passagem Plena (Full Bore) ou Válvula Gaveta Passagem Plena."
            ),
            PracticeQuestion(
                id = "dutos_q_${chapNum}_2",
                code = "DUTOS-$chapNum-02",
                subject = "Dutos e Terminais",
                topic = topicName,
                difficulty = "Difícil",
                statement = "Durante a operação de combate a incêndios e contenção em instalações terrestres e marítimas, a equipe de SMS da Transpetro deve observar que:",
                options = listOf(
                    "A) A água em jato pleno deve ser lançada diretamente na superfície de tanques de óleo diesel em chamas para acelerar o resfriamento.",
                    "B) O Líquido Gerador de Espuma (LGE) do tipo AR-AFFF é obrigatório quando o produto armazenado envolve solventes polares ou combustíveis com álcool.",
                    "C) A proteção catódica por corrente impressa conecta a tubulação de aço enterrada ao polo positivo do retificador para induzir sua oxidação.",
                    "D) A atmosfera de um tanque de navio petroleiro é considerada inerte quando o teor de oxigênio atinge valores superiores a 15% em volume.",
                    "E) O fenômeno do golpe de aríete é amenizado com o fechamento instantâneo e abrupto de válvulas de gaveta na descarga de bombas."
                ),
                correctIndex = 1,
                detailedExplanation = "A alternativa B está correta: produtos polares como etanol degradam a espuma AFFF convencional. Para hidrocarbonetos com álcool ou etanol puro, é mandatório o uso de LGE Resistente a Álcool (AR-AFFF).",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: Jato pleno de água em óleo em chamas provoca violento 'slopover' ou 'boilover'.",
                    2 to "Incorreto: A tubulação é conectada ao polo NEGATIVO para atuar como cátodo protegido.",
                    3 to "Incorreto: Atmosfera inerte exige teor de O₂ abaixo de 8% em volume.",
                    4 to "Incorreto: Fechamento abrupto AGRAVA e gera o golpe de aríete; a proteção exige fechamento gradual."
                ),
                highYieldTip = "LGE resistente a álcool (AR-AFFF) possui polímeros que formam membrana protetora impedindo que o álcool dissolva a água da espuma."
            )
        )
    }
}
