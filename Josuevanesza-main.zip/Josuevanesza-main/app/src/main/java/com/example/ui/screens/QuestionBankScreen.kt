package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PracticeQuestion
import com.example.data.repository.EBookMasterRepository
import com.example.ui.components.QuestionInteractiveCard
import com.example.ui.theme.TranspetroGreenSuccess
import com.example.ui.theme.TranspetroNavyPrimary
import com.example.ui.viewmodel.EBookUiState
import com.example.ui.viewmodel.EBookViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionBankScreen(
    viewModel: EBookViewModel,
    uiState: EBookUiState,
    modifier: Modifier = Modifier
) {
    val allQuestions = remember { EBookMasterRepository.getQuestionBank() }
    var searchQuery by remember { mutableStateOf("") }

    val subjects = listOf("Todas", "Língua Portuguesa", "Matemática", "Dutos e Terminais", "Manutenção Mecânica", "Administração e Controle")
    val difficulties = listOf("Todas", "Fácil", "Médio", "Difícil")

    var selectedSubject by remember { mutableStateOf("Todas") }
    var selectedDifficulty by remember { mutableStateOf("Todas") }

    val filteredQuestions = remember(allQuestions, selectedSubject, selectedDifficulty, searchQuery) {
        allQuestions.filter { q ->
            val matchSub = selectedSubject == "Todas" || q.subject.equals(selectedSubject, ignoreCase = true)
            val matchDiff = selectedDifficulty == "Todas" || q.difficulty.equals(selectedDifficulty, ignoreCase = true)
            val matchQ = searchQuery.isBlank() ||
                    q.statement.contains(searchQuery, ignoreCase = true) ||
                    q.topic.contains(searchQuery, ignoreCase = true) ||
                    q.code.contains(searchQuery, ignoreCase = true)
            matchSub && matchDiff && matchQ
        }
    }

    val answeredCount = uiState.userQuizAnswers.size
    val correctCount = uiState.userQuizAnswers.count { (qid, ans) ->
        val q = allQuestions.find { it.id == qid }
        q != null && q.correctIndex == ans
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        // Top Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TranspetroNavyPrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "BANCO DE QUESTÕES CESGRANRIO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                    Text(
                        text = "360+ Questões com Gabarito Comentado",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Respondidas: $answeredCount/${allQuestions.size}",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        Text(
                            text = "Acertos: $correctCount (${if (answeredCount > 0) (correctCount * 100 / answeredCount) else 0}%)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TranspetroGreenSuccess
                        )
                    }
                }
            }
        }

        // Search in Questions
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Pesquisar enunciado ou tema...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = null)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .testTag("question_search_input"),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )
        }

        // Filter Chips - Disciplina
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                subjects.forEach { sub ->
                    FilterChip(
                        selected = selectedSubject == sub,
                        onClick = { selectedSubject = sub },
                        label = { Text(sub, fontSize = 12.sp) }
                    )
                }
            }
        }

        // Filter Chips - Dificuldade
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                difficulties.forEach { diff ->
                    FilterChip(
                        selected = selectedDifficulty == diff,
                        onClick = { selectedDifficulty = diff },
                        label = { Text("Nível: $diff", fontSize = 12.sp) }
                    )
                }
            }
        }

        // Question List
        item {
            Text(
                text = "Questões Encontradas (${filteredQuestions.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        items(filteredQuestions) { q ->
            val selected = uiState.userQuizAnswers[q.id]
            QuestionInteractiveCard(
                question = q,
                selectedOption = selected,
                onOptionSelected = { idx -> viewModel.answerQuizQuestion(q.id, idx) }
            )
        }
    }
}
