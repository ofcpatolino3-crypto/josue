package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Petroleum Palette
val TranspetroNavyDark = Color(0xFF071E3D)
val TranspetroNavyPrimary = Color(0xFF0B2545)
val TranspetroTeal = Color(0xFF134074)
val TranspetroBlueAccent = Color(0xFF1D5C96)
val TranspetroCyan = Color(0xFF8DA9C4)
val TranspetroIce = Color(0xFFEEF4F8)

// Accent & Badges
val TranspetroGold = Color(0xFFF4A261)
val TranspetroGoldDark = Color(0xFFE76F51)
val TranspetroGreenSuccess = Color(0xFF2A9D8F)
val TranspetroRedAlert = Color(0xFFE63946)

// Neutral Colors
val SurfaceLight = Color(0xFFF7F9FC)
val CardBackgroundLight = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF1E293B)
val TextSecondaryLight = Color(0xFF64748B)

val SurfaceDark = Color(0xFF0B1320)
val CardBackgroundDark = Color(0xFF152238)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
