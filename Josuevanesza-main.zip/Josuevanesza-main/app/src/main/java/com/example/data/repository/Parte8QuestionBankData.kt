package com.example.data.repository

import com.example.data.model.PracticeQuestion

object Parte8QuestionBankData {
    fun getAllQuestions(): List<PracticeQuestion> {
        val list = mutableListOf<PracticeQuestion>()

        // Add questions from all chapters
        Parte2PortuguesData.getChapters().forEach { chap ->
            list.addAll(chap.questions)
        }
        Parte3MatematicaData.getChapters().forEach { chap ->
            list.addAll(chap.questions)
        }
        Parte5DutosTerminaisData.getChapters().forEach { chap ->
            list.addAll(chap.questions)
        }
        Parte6ManutencaoMecanicaData.getChapters().forEach { chap ->
            list.addAll(chap.questions)
        }
        Parte7AdministracaoControleData.getChapters().forEach { chap ->
            list.addAll(chap.questions)
        }

        // Add specialized Cesgranrio mega-bank questions
        list.addAll(getSpecializedCesgranrioMegaBank())

        return list
    }

    private fun getSpecializedCesgranrioMegaBank(): List<PracticeQuestion> {
        return listOf(
            PracticeQuestion(
                id = "bank_cesgranrio_01",
                code = "CESG-PT-01",
                subject = "Língua Portuguesa",
                topic = "Concordância Verbal e Nominal",
                difficulty = "Médio",
                statement = "Considere a frase: 'Tratam-se de questões que exigem atenção dos engenheiros'. Quanto à norma-padrão da língua portuguesa, assinale a opção correta:",
                options = listOf(
                    "A) A frase está correta, pois o pronome 'se' atua como partícula apassivadora.",
                    "B) A frase é incorreta, pois o verbo deveria estar no singular ('Trata-se de questões...'), visto que 'questões' é objeto indireto e 'se' é índice de indeterminação do sujeito.",
                    "C) A concordância é facultativa, podendo ser empregada no singular ou no plural.",
                    "D) O verbo deveria flexionar no particípio passado.",
                    "E) A presença da preposição 'de' atrai a flexão do verbo obrigatoriamente para o plural."
                ),
                correctIndex = 1,
                detailedExplanation = "Correto: Verbos transitivos indiretos (como 'tratar de') acompanhados do pronome 'se' formam orações com Sujeito Indeterminado. Nesse caso, o verbo DEVE ficar rigorosamente na 3ª pessoa do SINGULAR: 'Trata-se de questões...'.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: Não há partícula apassivadora com verbo transitivo indireto regido pela preposição 'de'.",
                    2 to "Incorreto: A concordância com índice de indeterminação não é facultativa.",
                    3 to "Incorreto: A voz verbal não exige particípio.",
                    4 to "Incorreto: A preposição 'de' impede que o termo seguinte seja sujeito."
                ),
                highYieldTip = "Verbo Transitivo Indireto + SE = Verbo OBRIGATORIAMENTE no Singular (Índice de Indeterminação do Sujeito)."
            ),
            PracticeQuestion(
                id = "bank_cesgranrio_02",
                code = "CESG-MAT-01",
                subject = "Matemática",
                topic = "Porcentagem e Variações Acumuladas",
                difficulty = "Médio",
                statement = "Um lote de bombas industriais para terminais marítimos teve seu preço aumentado sucessivamente em 10% no primeiro mês e em 20% no segundo mês. Se uma empresa obteve um desconto promocional de 30% sobre o valor acumulado no terceiro mês, qual foi a variação final do preço em relação ao valor original?",
                options = listOf(
                    "A) Aumento de 0%",
                    "B) Desconto de 7,6%",
                    "C) Desconto de 10%",
                    "D) Aumento de 2,4%",
                    "E) Desconto de 5%"
                ),
                correctIndex = 1,
                detailedExplanation = "Fator 1 (aumento de 10%): 1,10. Fator 2 (aumento de 20%): 1,20. Fator 3 (desconto de 30%): 0,70. Fator acumulado = 1,10 × 1,20 × 0,70 = 1,32 × 0,70 = 0,924. Variação = 0,924 - 1 = -0,076 = -7,6% (ou seja, desconto de 7,6%).",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: Não faça 10 + 20 - 30 = 0%.",
                    2 to "Incorreto: Cálculo sem composição fracionária.",
                    3 to "Incorreto: O valor final é inferior a 1,0.",
                    4 to "Incorreto: Estimativa imprecisa."
                ),
                highYieldTip = "Multiplique sempre os fatores (1+i) ou (1-i) em variações sucessivas."
            ),
            PracticeQuestion(
                id = "bank_cesgranrio_03",
                code = "CESG-DUT-01",
                subject = "Dutos e Terminais",
                topic = "Sistemas de Alívio e Proteção contra Sobrepressão",
                difficulty = "Difícil",
                statement = "Em uma estação de bombeamento de oleoduto da Transpetro, o desligamento acidental e simultâneo de duas bombas centrífugas principais pode provocar o fenômeno do Golpe de Aríete. Para mitigar esse risco e proteger a integridade estrutural das tubulações, o sistema deve contar com:",
                options = listOf(
                    "A) Fechamento instantâneo e descontrolado das válvulas de retenção na sucção.",
                    "B) Skids de alívio rápido de transiente (Surge Relief Valves) e tanques de amortecimento de sobrepressão.",
                    "C) Aumento abrupto da pressão de regulagem das válvulas globo da linha principal.",
                    "D) Injeção de água do mar a montante das bombas.",
                    "E) Isolamento imediato dos sistemas de proteção catódica por corrente impressa."
                ),
                correctIndex = 1,
                detailedExplanation = "Correto: Skids de alívio de transiente (Surge Relief Skids) equipados com válvulas de abertura ultrarrápida (Axial Surge Valves) aliviam o pico de onda de pressão decorrente do transiente hidráulico para tanques de alívio, evitando a ruptura do duto.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: O fechamento brusco amplifica o choque hidráulico.",
                    2 to "Incorreto: Válvulas globo geram restrição adicional prejudicial.",
                    3 to "Incorreto: Água salgada contaminaria o hidrocarboneto e aceleraria corrosão.",
                    4 to "Incorreto: Proteção catódica não tem relação com ondas de choque mecânicas."
                ),
                highYieldTip = "Golpe de Aríete = Transiente Hidráulico protegido por Válvulas de Alívio de Surto (Surge Valves) e atuadores com fechamento programado."
            ),
            PracticeQuestion(
                id = "bank_cesgranrio_04",
                code = "CESG-MEC-01",
                subject = "Manutenção Mecânica",
                topic = "Tribologia e Lubrificação de Mancais",
                difficulty = "Médio",
                statement = "Em relação à viscosidade dos óleos industriais conforme a classificação ISO VG (ISO 3448), a designação ISO VG 68 indica que:",
                options = listOf(
                    "A) O óleo possui ponto de fulgor mínimo de 68 °C.",
                    "B) A viscosidade cinemática do óleo a 40 °C é de 68 centistokes (cSt ou mm²/s) com tolerância de ± 10%.",
                    "C) O índice de viscosidade mínimo do lubrificante é 68 na escala Saybolt.",
                    "D) O produto suporta carga estática de 68 kgf/cm² sem cisalhar o filme.",
                    "E) O teor de água tolerado é de 68 partes por milhão."
                ),
                correctIndex = 1,
                detailedExplanation = "Correto: A classificação ISO VG padroniza a viscosidade cinemática dos lubrificantes industriais medida rigorosamente a 40 °C. Assim, ISO VG 68 significa que o óleo possui 68 mm²/s (cSt) a 40 °C (faixa admissível de 61,2 a 74,8 cSt).",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: Não se refere ao ponto de fulgor.",
                    2 to "Incorreto: O IV é um número adimensional calculado entre 40 °C e 100 °C.",
                    3 to "Incorreto: Não expressa carga estática de ruptura.",
                    4 to "Incorreto: Não expressa limite de contaminação por água."
                ),
                highYieldTip = "ISO VG = Viscosidade Cinemática em centistokes (cSt ou mm²/s) a 40 °C."
            ),
            PracticeQuestion(
                id = "bank_cesgranrio_05",
                code = "CESG-ADM-01",
                subject = "Administração e Controle",
                topic = "Lei das Estatais (Lei 13.303/2016) e Contratos",
                difficulty = "Médio",
                statement = "De acordo com a Lei Federal nº 13.303/2016, a contratação de fornecedor de produtos ou serviços com a Transpetro mediante Inexigibilidade de Licitação é juridicamente justificada quando houver:",
                options = listOf(
                    "A) Comprovada inviabilidade jurídica de competição, tal como na aquisição de materiais que só possam ser fornecidos por produtor exclusivo.",
                    "B) Valor contratual inferior ao limite fixado para compras diretas de pequeno valor.",
                    "C) Situação de emergência ou calamidade pública que exija atendimento imediato de risco.",
                    "D) Licitação anterior deserta em virtude de ausência de interessados habilitados.",
                    "E) Contratação de remanescente de obra rescindida com aproveitamento da ordem de classificação."
                ),
                correctIndex = 0,
                detailedExplanation = "Correto: A inexigibilidade de licitação (art. 30 da Lei 13.303/2016) tem como pressuposto inafastável a inviabilidade de competição, cujo principal exemplo legal é a exclusividade de fornecedor atestada por órgão competente.",
                incorrectOptionsExplanation = mapOf(
                    1 to "Incorreto: Pequeno valor é caso de DISPENSA de licitação (art. 29, I e II).",
                    2 to "Incorreto: Emergência é caso de DISPENSA de licitação (art. 29, XV).",
                    3 to "Incorreto: Licitação deserta é caso de DISPENSA de licitação.",
                    4 to "Incorreto: Remanescente de contrato é hipótese de contratação direta por dispensa."
                ),
                highYieldTip = "Competição Inviável = Inexigibilidade (art. 30). Competição Viável mas Dispensada = Dispensa (art. 29)."
            )
        )
    }
}
