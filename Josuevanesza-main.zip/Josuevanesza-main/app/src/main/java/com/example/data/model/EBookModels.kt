package com.example.data.model

data class EBookModule(
    val id: String,
    val moduleNumber: Int,
    val title: String,
    val subtitle: String,
    val description: String,
    val chapters: List<EBookChapter> = emptyList(),
    val iconName: String = "MenuBook",
    val estimatedTotalMinutes: Int = 120
)

data class EBookChapter(
    val id: String,
    val partId: String,
    val partNumber: Int,
    val partTitle: String,
    val chapterNumber: Int,
    val title: String,
    val subtitle: String = "",
    val readTimeMinutes: Int = 12,
    val contentSections: List<ContentSection> = emptyList(),
    val questions: List<PracticeQuestion> = emptyList(),
    val strategicSummary: String = "",
    val highYieldAlerts: List<String> = emptyList(),
    val examTraps: List<String> = emptyList()
)

data class ContentSection(
    val title: String,
    val body: String,
    val formulas: List<FormulaItem> = emptyList(),
    val tables: List<TableItem> = emptyList(),
    val bulletPoints: List<String> = emptyList(),
    val attentionBoxes: List<AttentionBoxData> = emptyList(),
    val examTraps: List<ExamTrapData> = emptyList(),
    val practicalExamples: List<PracticalExampleData> = emptyList()
)

data class FormulaItem(
    val name: String,
    val expression: String,
    val variables: String,
    val applicationTip: String
)

data class TableItem(
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>
)

data class AttentionBoxData(
    val title: String,
    val content: String,
    val iconType: String = "ALERT" // "ALERT", "LAW", "FORMULA", "TECH"
)

data class ExamTrapData(
    val title: String,
    val trapDescription: String,
    val howToAvoid: String
)

data class PracticalExampleData(
    val scenario: String,
    val stepByStepSolution: String,
    val keyTakeaway: String
)

data class PracticeQuestion(
    val id: String,
    val code: String,
    val subject: String, // "Português", "Matemática", "Dutos e Terminais", "Manutenção Mecânica", "Administração e Controle"
    val topic: String,
    val difficulty: String, // "Fácil", "Médio", "Difícil"
    val statement: String,
    val options: List<String>, // 5 items: A, B, C, D, E
    val correctIndex: Int, // 0 to 4
    val detailedExplanation: String,
    val incorrectOptionsExplanation: Map<Int, String> = emptyMap(),
    val highYieldTip: String = ""
)

data class ExamSimulation(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val description: String = "",
    val targetRole: String = "PSP Transpetro 2026",
    val emphasis: String = "Geral",
    val durationMinutes: Int = 240,
    val cutoffScore: Float = 70.0f,
    val questions: List<PracticeQuestion> = emptyList(),
    val portugueseQuestions: List<PracticeQuestion> = emptyList(),
    val mathQuestions: List<PracticeQuestion> = emptyList(),
    val specificQuestions: List<PracticeQuestion> = emptyList()
) {
    val allQuestions: List<PracticeQuestion>
        get() = if (questions.isNotEmpty()) questions else (portugueseQuestions + mathQuestions + specificQuestions)
}

data class StudyPlan(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val description: String = "",
    val targetHorizonDays: Int = 30,
    val totalDays: Int = targetHorizonDays,
    val recommendedDailyHours: Float = 3.0f,
    val dailyHoursRecommended: Double = recommendedDailyHours.toDouble(),
    val targetProfile: String = "Geral",
    val weeklyGoals: List<String> = emptyList(),
    val dailySchedules: List<StudyDaySchedule> = emptyList(),
    val weeks: List<StudyWeek> = emptyList()
)

data class StudyDaySchedule(
    val dayNumber: Int,
    val focusSubject: String,
    val topicsToStudy: List<String>,
    val targetTheoryPages: Int,
    val targetQuestions: Int,
    val estimatedHours: Float,
    val revisionItems: List<String> = emptyList()
)

data class StudyWeek(
    val weekNumber: Int,
    val focusTheme: String,
    val days: List<StudyDay>
)

data class StudyDay(
    val dayNumber: Int,
    val discipline: String,
    val topic: String,
    val studyActivity: String,
    val questionsGoal: Int,
    val reviewTopic: String,
    val estimatedMinutes: Int = 120,
    val completed: Boolean = false
)

data class MindMapNode(
    val id: String,
    val topic: String,
    val concept: String,
    val characteristics: List<String>,
    val applications: List<String>,
    val traps: List<String>,
    val quickReview: String
)

data class ReadingPreferences(
    val fontSizeSp: Float = 16f,
    val isSerif: Boolean = false,
    val lineSpacingMultiplier: Float = 1.3f,
    val themeMode: ReadingThemeMode = ReadingThemeMode.DARK_PETROLEUM
)

enum class ReadingThemeMode {
    DARK_PETROLEUM,
    LIGHT_EDITORIAL,
    SEPIA_PAPER,
    NAVY_BLUE
}

data class UserSimulationResult(
    val simulationId: String,
    val completedAtMillis: Long,
    val scorePortuguese: Int,
    val totalPortuguese: Int,
    val scoreMath: Int,
    val totalMath: Int,
    val scoreSpecific: Int,
    val totalSpecific: Int,
    val timeSpentSeconds: Long,
    val userAnswers: Map<String, Int>
) {
    val totalScore: Int get() = scorePortuguese + scoreMath + scoreSpecific
    val totalQuestions: Int get() = totalPortuguese + totalMath + totalSpecific
    val percentage: Float get() = if (totalQuestions > 0) (totalScore.toFloat() / totalQuestions) * 100f else 0f
    val isApproved: Boolean get() = scorePortuguese >= 5 && scoreMath >= 5 && scoreSpecific >= 20 && totalScore >= 36
}
