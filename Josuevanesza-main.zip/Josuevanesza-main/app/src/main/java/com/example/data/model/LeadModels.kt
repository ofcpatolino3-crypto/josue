package com.example.data.model

data class Lead(
    val id: String,
    val originalRowIndex: Int,
    val name: String,
    val originalPhone: String,
    val normalizedPhone: String,
    val email: String,
    val course: String = "", // Curso / Concurso
    val temperature: String = "", // Temperatura (Quente, Morno, Frio)
    val observation: String = "", // Observação
    val responsible: String = "",
    val status: String = "",
    val campaign: String = "",
    val rawData: Map<String, String> = emptyMap(),
    val isDuplicate: Boolean = false,
    val duplicateCount: Int = 1,
    val hasPhone: Boolean = originalPhone.isNotBlank(),
    val hasEmail: Boolean = email.isNotBlank(),
    val hasName: Boolean = name.isNotBlank(),
    val hasCourse: Boolean = course.isNotBlank(),
    val hasTemperature: Boolean = temperature.isNotBlank(),
    val hasObservation: Boolean = observation.isNotBlank()
)

data class ColumnMappingItem(
    val originalHeader: String,
    val targetField: String,
    val filledCount: Int,
    val hasConflict: Boolean = false,
    val conflictDetails: String? = null
)

data class FileParseResult(
    val fileName: String,
    val fileType: String,
    val detectedEncoding: String,
    val detectedDelimiter: Char?,
    val totalRowsRead: Int,
    val headers: List<String>,
    val leads: List<Lead>,
    val phoneColumnName: String?,
    val nameColumnName: String?,
    val emailColumnName: String?,
    val courseColumnName: String?,
    val temperatureColumnName: String?,
    val observationColumnName: String?,
    val responsibleColumnName: String?,
    val statusColumnName: String? = null,
    val campaignColumnName: String? = null,
    val readErrors: List<String> = emptyList(),
    val validationComparison: ImportValidationComparison? = null,
    val columnMappings: List<ColumnMappingItem> = emptyList(),
    val hasMappingConflict: Boolean = false,
    val mappingConflictMessage: String? = null
)

data class ImportValidationComparison(
    val totalRowsInFile: Int,
    val totalLeadsParsed: Int,
    val leadsWithDetectedName: Int,
    val leadsWithDetectedPhone: Int,
    val leadsWithDetectedEmail: Int,
    val leadsWithDetectedCourse: Int,
    val leadsWithDetectedTemperature: Int,
    val leadsWithDetectedObservation: Int,
    val courseColumnFound: String?,
    val phoneColumnFound: String?,
    val nameColumnFound: String?,
    val emailColumnFound: String?,
    val temperatureColumnFound: String?,
    val observationColumnFound: String?,
    val isCoursePreserved: Boolean = true,
    val columnMappings: List<ColumnMappingItem> = emptyList(),
    val hasMappingConflict: Boolean = false,
    val conflictDetails: String? = null
)

data class IntegrityReport(
    val totalLeads: Int,
    val leadsWithPhone: Int,
    val leadsWithoutPhone: Int,
    val leadsWithEmail: Int,
    val leadsWithCourse: Int = 0,
    val phonesPreserved: Int,
    val phonesLost: Int,
    val duplicatesCount: Int,
    val readErrorsCount: Int,
    val responsibleBreakdown: Map<String, Int> = emptyMap(),
    val isIntegrityVerified: Boolean = phonesLost == 0 && readErrorsCount == 0,
    val alerts: List<String> = emptyList()
)

data class ExportValidationResult(
    val inputLeadsCount: Int,
    val outputLeadsCount: Int,
    val inputPhonesCount: Int,
    val outputPhonesCount: Int,
    val lostPhones: Int,
    val lostEmails: Int,
    val lostNames: Int,
    val lostCourses: Int = 0,
    val canExport: Boolean,
    val blockerReasons: List<String> = emptyList(),
    val warnings: List<String> = emptyList()
)

data class ResponsibleSheet(
    val sheetName: String,
    val leads: List<Lead>,
    val leadCount: Int = leads.size,
    val leadsWithPhoneCount: Int = leads.count { it.hasPhone },
    val leadsWithCourseCount: Int = leads.count { it.hasCourse }
)
