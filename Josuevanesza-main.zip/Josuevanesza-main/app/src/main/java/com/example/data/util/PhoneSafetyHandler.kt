package com.example.data.util

import java.math.BigDecimal

object PhoneSafetyHandler {

    private val phoneHeaderKeywords = listOf(
        "telefone", "celular", "whatsapp", "phone", "mobile", "contato",
        "nº telefone", "no telefone", "num telefone", "numero telefone",
        "tel", "fone", "wpp", "zap", "cel", "tel1", "tel2", "telefone 1",
        "celular 1", "telefone contato", "contact"
    )

    /**
     * Safely recovers a phone number string from raw cell text or Excel numeric representation.
     * Prevents:
     * - Scientific notation (e.g., 7.99999E+10 -> 79999900000 or exact digits)
     * - Trailing decimals (.0 from float conversions)
     * - Discarding leading zeros (e.g., 07999999999)
     * - Losing country code (+55) or DDD
     */
    fun sanitizeRawPhone(rawInput: String?): String {
        if (rawInput == null) return ""
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return ""

        // Check if scientific notation
        if (trimmed.matches(Regex("""^[+-]?\d+([.,]\d+)?[eE][+-]?\d+$"""))) {
            return try {
                val normalizedDecimal = trimmed.replace(',', '.')
                val bigDec = BigDecimal(normalizedDecimal)
                bigDec.toPlainString().substringBefore('.')
            } catch (e: Exception) {
                trimmed
            }
        }

        // Check if trailing decimal like 79999999999.0 or 79999999999,0
        if (trimmed.matches(Regex("""^\+?\d+([.,]0+)$"""))) {
            return trimmed.substringBefore('.').substringBefore(',')
        }

        return trimmed
    }

    /**
     * Creates a normalized version of the phone (digits only).
     * Example: "(79) 99999-9999" -> "79999999999"
     * Example: "+55 (11) 98888-7777" -> "5511988887777"
     */
    fun normalizePhone(rawPhone: String): String {
        val sanitized = sanitizeRawPhone(rawPhone)
        val digits = sanitized.filter { it.isDigit() }
        return digits
    }

    /**
     * Checks if a column header name corresponds to a phone field.
     */
    fun isPhoneHeader(header: String): Boolean {
        val normalized = header.lowercase()
            .replace("ã", "a")
            .replace("á", "a")
            .replace("é", "e")
            .replace("í", "i")
            .replace("ó", "o")
            .replace("ú", "u")
            .replace("ç", "c")
            .trim()

        if (phoneHeaderKeywords.any { normalized == it || normalized.contains(it) }) {
            return true
        }
        return false
    }

    /**
     * Inspects column values across rows to detect if this column holds phone numbers.
     * Useful when columns are titled "Coluna 3" or have no headers.
     */
    fun isPhoneColumnBySampling(sampleValues: List<String>): Boolean {
        val nonEmpty = sampleValues.filter { it.isNotBlank() }
        if (nonEmpty.isEmpty()) return false

        var phoneMatchCount = 0
        for (v in nonEmpty) {
            val digits = v.filter { it.isDigit() }
            // Typical Brazilian or international phone: between 8 and 15 digits
            if (digits.length in 8..15) {
                phoneMatchCount++
            }
        }

        val matchRate = phoneMatchCount.toFloat() / nonEmpty.size
        return matchRate >= 0.4f
    }
}
