package com.example.data.repository

import com.example.data.model.*

object Parte1ApresentacaoData {
    fun getChapter(): EBookChapter {
        return EBookChapter(
            id = "part1_apresentacao",
            partId = "part_1",
            partNumber = 1,
            partTitle = "PARTE 1 — APRESENTAÇÃO E GUIA DO CANDIDATO",
            chapterNumber = 1,
            title = "Apresentação Institucional, Estratégia de Estudos e Edital Transpetro 2026",
            subtitle = "Guia Completo para o Processo Seletivo Público PSP/Terra/Nível Médio — Edital Nº 003/2026 (Cesgranrio)",
            readTimeMinutes = 20,
            strategicSummary = "A Transpetro é a maior empresa de logística de petróleo e derivados da América Latina. O processo seletivo da Fundação Cesgranrio exige precisão conceitual, velocidade de resolução e alta retenção nas disciplinas básicas e específicas.",
            highYieldAlerts = listOf(
                "A Transpetro opera mais de 15.000 km de dutos e 47 terminais terrestres e aquaviários.",
                "O Edital 003/2026 para Quadro de Terra exige nota mínima eliminatória em Conhecimentos Básicos (Português e Matemática) e Conhecimentos Específicos.",
                "A Fundação Cesgranrio valoriza a contextualização prática das operações industriais e não tolera decoreba desconexa."
            ),
            examTraps = listOf(
                "Subestimar Língua Portuguesa e Matemática: Zerar ou ficar abaixo de 50% em conhecimentos básicos desclassifica sumariamente o candidato.",
                "Não praticar controle de tempo: A prova de 60 questões em 4 horas concede uma média de 3 minutos e 40 segundos por questão, incluindo o preenchimento do cartão-resposta."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. O que é a Petrobras Transporte S.A. (Transpetro)",
                    body = """A Transpetro é a subsidiária integral da Petrobras responsável por todo o transporte e armazenamento de petróleo, derivados, gás natural e biocombustíveis no Brasil. 

Criada em 1997 pela Lei do Petróleo (Lei nº 9.478/1997), a Transpetro conecta as plataformas offshore na Bacia de Santos e Campos às refinarias do país e, subsequentemente, às distribuidoras de combustíveis em todo o território nacional.

A magnitude da infraestrutura operada pela Transpetro inclui:
• Mais de 15.000 km de oleodutos e gasodutos de transporte e transferência.
• Mais de 47 terminais (terminais terrestres e aquaviários estrategicamente distribuídos).
• Uma frota própria e afretada de navios petroleiros (DP, Suezmax, Aframax, gaseiros e de derivados).
• Centros de Controle Operacional (CCO) dotados de sistemas SCADA de altíssima confiabilidade e automação em tempo real.""",
                    bulletPoints = listOf(
                        "Subsidiária de direito privado com capital 100% sob controle da Petrobras.",
                        "Líder absoluta em movimentação de granéis líquidos na América do Sul.",
                        "Cultura de Segurança, Meio Ambiente e Saúde (SMS) como valor inegociável."
                    ),
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "AVISO LEGAL DE INDEPENDÊNCIA PEDAGÓGICA",
                            content = "Este material é independente e foi elaborado para fins educacionais de preparação de alto rendimento. Não possui vínculo institucional com a Transpetro, Petrobras ou Fundação Cesgranrio. Em caso de qualquer divergência factual ou regulamentar, deve prevalecer o edital oficial nº 003/2026 e suas retificações.",
                            iconType = "LAW"
                        )
                    )
                ),
                ContentSection(
                    title = "2. O Processo Seletivo Público (PSP/Terra/Nível Médio) e o Trabalho Técnico",
                    body = """O Processo Seletivo Público (PSP) da Transpetro para o Quadro de Terra destina-se a profissionais de nível médio e técnico que atuarão diretamente na linha de frente das operações industriais, manutenção eletromecânica e gestão administrativa.

O que significa trabalhar na área técnica da Transpetro:
1. Responsabilidade Operacional Máxima: O técnico é responsável pelo controle de fluxo de milhões de litros de hidrocarbonetos sob alta pressão e normas rigorosas de estanqueidade.
2. Cultura de Segurança (SMS): Parada imediata de qualquer operação insegura (Direito de Recusa) e aplicação diária de Permissões de Trabalho (PT) e Análise Preliminar de Risco (APR).
3. Trabalho em Turno e Regime Administrativo: Oportunidade de atuação em regimes de turno de revezamento (operando terminais 24/7) ou regime administrativo clássico com plano de carreira estruturado.""",
                    bulletPoints = listOf(
                        "Remuneração atrativa com salário base + adicionais (periculosidade, turno, sobreaviso).",
                        "Benefícios: Plano de saúde de excelência (AMS), previdência complementar (Petros), auxílio creche e participação nos lucros/resultados (PLR).",
                        "Estabilidade prática vinculada à CLT com regime jurídico de empresa pública de economia mista."
                    )
                ),
                ContentSection(
                    title = "3. Metodologia de Estudo Ativo e o Ciclo EER (Estudo, Exercício, Revisão)",
                    body = """Para conquistar uma vaga na Transpetro, o estudo passivo (apenas ler sem praticar) é insuficiente. Você deve adotar a metodologia EER:

1. Estudo Teórico Direcionado (40% do tempo):
Aprenda os conceitos fundamentais conectando a teoria às operações reais da Transpetro. Visualize os dutos, as bombas centrífugas, as válvulas de alívio e os sistemas de medição.

2. Exercício Massivo por Banca (40% do tempo):
Resolva dezenas de questões todos os dias. A Fundação Cesgranrio possui padrões textuais recorrentes, vocabulário formal e pegadinhas em enunciados longos.

3. Revisão Espaçada e Resumo Ativo (20% do tempo):
Utilize os Mapas Mentais Textuais e as seções de Revisão Turbo após 24h, 7 dias e 30 dias para consolidar a memória de longo prazo.""",
                    tables = listOf(
                        TableItem(
                            title = "Estrutura da Prova Objetiva Cesgranrio (PSP Transpetro)",
                            headers = listOf("Módulo", "Disciplina", "Nº de Questões", "Pontuação / Mínimo"),
                            rows = listOf(
                                listOf("Básicos", "Língua Portuguesa", "10 questões", "Mínimo: 50% de acertos"),
                                listOf("Básicos", "Matemática", "10 questões", "Mínimo: 50% de acertos"),
                                listOf("Específicos", "Conhecimentos Específicos da Ênfase", "40 questões", "Mínimo: 50% de acertos (Peso 2)"),
                                listOf("Total", "Prova Completa", "60 questões", "Tempo total: 4 horas")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "4. Como Estudar para a Fundação Cesgranrio",
                    body = """A Fundação Cesgranrio possui um estilo muito particular que você precisa dominar:
• Textos de Apoio Médios/Longos: Em Português, as questões não são meramente gramaticais; elas exigem interpretação da intenção comunicativa do autor e valores semânticos de conectivos no contexto.
• Matemática Aplicada: As questões de Matemática envolvem situações-problema práticas de consumo de combustível, transporte de carga, vazão volumétrica e estatística operacional.
• Específicas Diretas e Práticas: As questões técnicas cobram conceitos normativos (NRs, API, ABNT) e resolução de falhas operacionais em plantas industriais.""",
                    bulletPoints = listOf(
                        "Dica de Ouro 1: Grife no enunciado palavras restritivas como 'EXCETO', 'INCORRETO', 'SEMPRE' e 'NUNCA'.",
                        "Dica de Ouro 2: Em Matemática, verifique a compatibilidade de unidades (ex: converter m³/h para L/s ou bar para kgf/cm²).",
                        "Dica de Ouro 3: Comece a prova pela sua disciplina de maior domínio para construir confiança e poupar tempo para as questões que exigem cálculos."
                    )
                )
            )
        )
    }
}
