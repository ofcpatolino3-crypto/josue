package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.exporter.LeadExporter
import com.example.data.model.*
import com.example.data.processor.LeadManagerEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class LeadUiState(
    val parseResult: FileParseResult? = null,
    val pendingImportResult: FileParseResult? = null,
    val pendingImportBytes: ByteArray? = null,
    val pendingImportFileName: String? = null,
    val isPreImportPreviewOpen: Boolean = false,
    val allLeads: List<Lead> = emptyList(),
    val displayedLeads: List<Lead> = emptyList(),
    val selectedTab: String = "Todos",
    val availableTabs: List<String> = listOf("Todos"),
    val responsibleSheets: List<ResponsibleSheet> = emptyList(),
    val distinctResponsibles: List<String> = emptyList(),
    val responsibleFilterInput: String = "Josué e Wanessa",
    val searchQuery: String = "",
    val integrityReport: IntegrityReport? = null,
    val exportValidation: ExportValidationResult? = null,
    val isExportDialogOpen: Boolean = false,
    val isValidationBlockerOpen: Boolean = false,
    val isIntegrityReportOpen: Boolean = false,
    val isProcessing: Boolean = false,
    val feedbackMessage: String? = null,
    val exportedFileUri: Uri? = null,
    val exportedFileName: String? = null
)

class LeadViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(LeadUiState())
    val uiState: StateFlow<LeadUiState> = _uiState.asStateFlow()

    init {
        // Load initial verified starter dataset on startup
        loadInitialData()
    }

    private fun loadInitialData() {
        viewModelScope.launch(Dispatchers.Default) {
            val sampleBytes = LeadManagerEngine.getSampleLeadsCsv()
            val result = LeadManagerEngine.processFile("leads_iniciais_validados.csv", sampleBytes)
            val leads = result.leads
            val report = LeadManagerEngine.generateIntegrityReport(leads, result.readErrors)
            val distinct = LeadManagerEngine.getDistinctResponsibles(leads)
            val requestedNames = parseResponsibleNames(_uiState.value.responsibleFilterInput)
            val sheets = LeadManagerEngine.createResponsibleSheets(leads, requestedNames)
            val tabs = sheets.map { it.sheetName }

            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        parseResult = result,
                        allLeads = leads,
                        displayedLeads = leads,
                        selectedTab = "Todos",
                        availableTabs = tabs,
                        responsibleSheets = sheets,
                        distinctResponsibles = distinct,
                        integrityReport = report,
                        isProcessing = false
                    )
                }
            }
        }
    }

    /**
     * Loads user file and triggers the Pre-Import Confirmation flow (showing
     * detection stats and table: Nome | WhatsApp | E-mail | Curso/Concurso | Temperatura | Observação)
     * before any data is recorded.
     */
    fun loadUserFile(fileName: String, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }
            try {
                val context = getApplication<Application>()
                val inputStream = context.contentResolver.openInputStream(uri)
                val bytes = withContext(Dispatchers.IO) {
                    inputStream?.use { it.readBytes() } ?: ByteArray(0)
                }
                if (bytes.isNotEmpty()) {
                    prepareImport(fileName, bytes)
                } else {
                    _uiState.update {
                        it.copy(
                            isProcessing = false,
                            feedbackMessage = "Erro: O arquivo selecionado está vazio."
                        )
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        feedbackMessage = "Falha ao ler arquivo: ${e.message}"
                    )
                }
            }
        }
    }

    /**
     * Triggers the realistic 908 leads test dataset to test the exact scenario
     * "908 contatos detectados" and "Confirmar e Importar 908 Leads" with validation.
     */
    fun loadSample908Data() {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }
            val bytes = withContext(Dispatchers.Default) {
                LeadManagerEngine.getSample908LeadsCsv()
            }
            prepareImport("planilha_concursos_908_leads.csv", bytes)
        }
    }

    /**
     * Prepares import and opens the Pre-Import Verification Table screen.
     * Prevents importing whole databases with mapped errors.
     */
    private fun prepareImport(fileName: String, bytes: ByteArray) {
        viewModelScope.launch(Dispatchers.Default) {
            val result = LeadManagerEngine.processFile(fileName, bytes)
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        pendingImportResult = result,
                        pendingImportBytes = bytes,
                        pendingImportFileName = fileName,
                        isPreImportPreviewOpen = true,
                        isProcessing = false
                    )
                }
            }
        }
    }

    /**
     * Allows user to interactively re-map columns (e.g. Curso / Observação) in the Pre-Import Dialog.
     * Instantly updates the preview so the user sees courses mapped correctly before committing.
     */
    fun updateImportColumnMapping(customCourseCol: String?, customObsCol: String?) {
        val bytes = _uiState.value.pendingImportBytes ?: return
        val fileName = _uiState.value.pendingImportFileName ?: "planilha.csv"
        viewModelScope.launch(Dispatchers.Default) {
            val result = LeadManagerEngine.processFile(
                fileName = fileName,
                bytes = bytes,
                customCourseCol = customCourseCol,
                customObsCol = customObsCol
            )
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(pendingImportResult = result)
                }
            }
        }
    }

    /**
     * User confirmed the import in the pre-import verification screen.
     * Commits all leads, sets up responsible sheets, and guarantees data integrity.
     */
    fun confirmPendingImport() {
        val pending = _uiState.value.pendingImportResult ?: return
        val leads = pending.leads
        val report = LeadManagerEngine.generateIntegrityReport(leads, pending.readErrors)
        val distinct = LeadManagerEngine.getDistinctResponsibles(leads)
        val requestedNames = parseResponsibleNames(_uiState.value.responsibleFilterInput)
        val sheets = LeadManagerEngine.createResponsibleSheets(leads, requestedNames)
        val tabs = sheets.map { it.sheetName }

        _uiState.update {
            it.copy(
                parseResult = pending,
                allLeads = leads,
                displayedLeads = leads,
                selectedTab = "Todos",
                availableTabs = tabs,
                responsibleSheets = sheets,
                distinctResponsibles = distinct,
                integrityReport = report,
                pendingImportResult = null,
                pendingImportBytes = null,
                pendingImportFileName = null,
                isPreImportPreviewOpen = false,
                isProcessing = false,
                feedbackMessage = "Importação confirmada! ${leads.size} leads gravados com sucesso (100% de integridade)."
            )
        }
    }

    fun cancelPendingImport() {
        _uiState.update {
            it.copy(
                pendingImportResult = null,
                pendingImportBytes = null,
                pendingImportFileName = null,
                isPreImportPreviewOpen = false
            )
        }
    }

    /**
     * Moves observation to course for a specific lead (when the course was stored in observation).
     */
    fun moveObservationToCourse(leadId: String) {
        val currentLeads = _uiState.value.allLeads
        val updatedLeads = currentLeads.map { lead ->
            if (lead.id == leadId && lead.observation.isNotBlank()) {
                val newCourse = if (lead.course.isBlank()) lead.observation else "${lead.course} - ${lead.observation}"
                lead.copy(
                    course = newCourse,
                    observation = ""
                )
            } else {
                lead
            }
        }
        recalculateAndSetLeads(updatedLeads, "Curso atualizado com sucesso a partir da observação.")
    }

    /**
     * Moves observation to course for all leads where course is blank and observation is filled.
     */
    fun moveAllObservationsToCourses() {
        val currentLeads = _uiState.value.allLeads
        var countMoved = 0
        val updatedLeads = currentLeads.map { lead ->
            if (lead.course.isBlank() && lead.observation.isNotBlank()) {
                countMoved++
                lead.copy(
                    course = lead.observation,
                    observation = ""
                )
            } else {
                lead
            }
        }
        if (countMoved > 0) {
            recalculateAndSetLeads(updatedLeads, "$countMoved cursos foram movidos da coluna Observação para a coluna Curso!")
        }
    }

    private fun recalculateAndSetLeads(leads: List<Lead>, message: String) {
        val report = LeadManagerEngine.generateIntegrityReport(leads, emptyList())
        val distinct = LeadManagerEngine.getDistinctResponsibles(leads)
        val requestedNames = parseResponsibleNames(_uiState.value.responsibleFilterInput)
        val sheets = LeadManagerEngine.createResponsibleSheets(leads, requestedNames)
        val tabs = sheets.map { it.sheetName }

        _uiState.update {
            it.copy(
                allLeads = leads,
                responsibleSheets = sheets,
                availableTabs = tabs,
                distinctResponsibles = distinct,
                integrityReport = report,
                feedbackMessage = message
            )
        }
        updateDisplayedLeads()
    }

    fun applyResponsibleFilter(filterText: String) {
        val names = parseResponsibleNames(filterText)
        val allLeads = _uiState.value.allLeads
        val sheets = LeadManagerEngine.createResponsibleSheets(allLeads, names)
        val tabs = sheets.map { it.sheetName }

        _uiState.update {
            it.copy(
                responsibleFilterInput = filterText,
                responsibleSheets = sheets,
                availableTabs = tabs,
                selectedTab = "Todos"
            )
        }
        updateDisplayedLeads()
    }

    private fun parseResponsibleNames(input: String): List<String> {
        val delimiters = Regex("""(?i)\s*(?:,\s*|\s+e\s+|\s+ou\s+|\s*;\s*)\s*""")
        val rawTokens = input.split(delimiters)
        return rawTokens.map { it.trim() }
            .filter { it.isNotBlank() && it.length > 1 }
            .distinct()
    }

    fun selectTab(tabName: String) {
        _uiState.update { it.copy(selectedTab = tabName) }
        updateDisplayedLeads()
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        updateDisplayedLeads()
    }

    private fun updateDisplayedLeads() {
        val currentTab = _uiState.value.selectedTab
        val query = _uiState.value.searchQuery.trim().lowercase()

        val tabLeads = if (currentTab == "Todos") {
            _uiState.value.allLeads
        } else {
            val sheet = _uiState.value.responsibleSheets.find { it.sheetName == currentTab }
            sheet?.leads ?: _uiState.value.allLeads
        }

        val filtered = if (query.isEmpty()) {
            tabLeads
        } else {
            tabLeads.filter { lead ->
                lead.name.lowercase().contains(query) ||
                        lead.originalPhone.contains(query) ||
                        lead.normalizedPhone.contains(query) ||
                        lead.email.lowercase().contains(query) ||
                        lead.course.lowercase().contains(query) ||
                        lead.temperature.lowercase().contains(query) ||
                        lead.observation.lowercase().contains(query) ||
                        lead.responsible.lowercase().contains(query) ||
                        lead.campaign.lowercase().contains(query)
            }
        }

        _uiState.update { it.copy(displayedLeads = filtered) }
    }

    fun openExportDialog() {
        val allLeads = _uiState.value.allLeads
        val validation = LeadExporter.validateBeforeExport(allLeads, allLeads)

        if (!validation.canExport) {
            _uiState.update {
                it.copy(
                    exportValidation = validation,
                    isValidationBlockerOpen = true
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    exportValidation = validation,
                    isExportDialogOpen = true
                )
            }
        }
    }

    fun dismissExportDialog() {
        _uiState.update { it.copy(isExportDialogOpen = false, isValidationBlockerOpen = false) }
    }

    fun openIntegrityReport() {
        _uiState.update { it.copy(isIntegrityReportOpen = true) }
    }

    fun dismissIntegrityReport() {
        _uiState.update { it.copy(isIntegrityReportOpen = false) }
    }

    fun dismissFeedbackMessage() {
        _uiState.update { it.copy(feedbackMessage = null) }
    }

    fun executeExport(format: String, context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val allLeads = _uiState.value.allLeads
            val headers = _uiState.value.parseResult?.headers ?: listOf(
                "Nome", "WhatsApp", "Email", "Curso / Concurso", "Temperatura", "Observacao", "Responsavel", "Status", "Campanha"
            )
            val validation = LeadExporter.validateBeforeExport(allLeads, allLeads)

            if (!validation.canExport) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            exportValidation = validation,
                            isValidationBlockerOpen = true,
                            isExportDialogOpen = false
                        )
                    }
                }
                return@launch
            }

            try {
                val outputDir = File(context.cacheDir, "exports").apply { mkdirs() }
                val (file, uri) = if (format == "XLS") {
                    val xmlContent = LeadExporter.generateExcelXml(
                        allLeads = allLeads,
                        headers = headers,
                        responsibleSheets = _uiState.value.responsibleSheets
                    )
                    val exportFile = File(outputDir, "Leads_Transpetro_Organizados.xls")
                    exportFile.writeText(xmlContent, Charsets.UTF_8)
                    val fileUri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        exportFile
                    )
                    Pair(exportFile, fileUri)
                } else {
                    val csvBytes = LeadExporter.generateSafeCsv(allLeads, headers, ';')
                    val exportFile = File(outputDir, "Leads_Transpetro_Organizados.csv")
                    FileOutputStream(exportFile).use { it.write(csvBytes) }
                    val fileUri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        exportFile
                    )
                    Pair(exportFile, fileUri)
                }

                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            isExportDialogOpen = false,
                            exportedFileName = file.name,
                            exportedFileUri = uri,
                            feedbackMessage = "Exportação concluída com sucesso! 100% dos cursos, telefones e registros foram preservados."
                        )
                    }
                    shareExportedFile(context, uri, file.name)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            isExportDialogOpen = false,
                            feedbackMessage = "Erro ao exportar: ${e.message}"
                        )
                    }
                }
            }
        }
    }

    private fun shareExportedFile(context: Context, uri: Uri, fileName: String) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = if (fileName.endsWith(".xls")) "application/vnd.ms-excel" else "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Exportação Segura de Leads - $fileName")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Compartilhar ou Salvar Planilha"))
        } catch (e: Exception) {
            // Intent chooser fallback
        }
    }
}
