package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun AttentionBoxView(
    box: AttentionBoxData,
    modifier: Modifier = Modifier
) {
    val borderColor = when (box.iconType) {
        "ALERT" -> TranspetroRedAlert
        "LAW" -> TranspetroNavyPrimary
        "FORMULA" -> TranspetroTeal
        else -> TranspetroGoldDark
    }

    val bgColor = when (box.iconType) {
        "ALERT" -> TranspetroRedAlert.copy(alpha = 0.08f)
        "LAW" -> TranspetroNavyPrimary.copy(alpha = 0.08f)
        "FORMULA" -> TranspetroTeal.copy(alpha = 0.08f)
        else -> TranspetroGold.copy(alpha = 0.12f)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .border(1.5.dp, borderColor, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = when (box.iconType) {
                        "ALERT" -> Icons.Default.Warning
                        "LAW" -> Icons.Default.Gavel
                        "FORMULA" -> Icons.Default.Calculate
                        else -> Icons.Default.Info
                    },
                    contentDescription = null,
                    tint = borderColor,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = box.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = borderColor
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = box.content,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun ExamTrapCard(
    trap: ExamTrapData,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .border(1.5.dp, TranspetroRedAlert.copy(alpha = 0.7f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = TranspetroRedAlert.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(TranspetroRedAlert, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Dangerous,
                        contentDescription = "Pegadinha",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PEGADINHA DA CESGRANRIO: ${trap.title}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TranspetroRedAlert
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Como a banca arma a armadilha:",
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = trap.trapDescription,
                fontSize = 13.5.sp,
                lineHeight = 19.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = TranspetroGreenSuccess.copy(alpha = 0.12f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Como neutralizar e acertar:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TranspetroGreenSuccess
                    )
                    Text(
                        text = trap.howToAvoid,
                        fontSize = 13.5.sp,
                        lineHeight = 19.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun FormulaCard(
    formula: FormulaItem,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = TranspetroNavyDark),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formula.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TranspetroCyan
                )
                Badge(containerColor = TranspetroGoldDark) {
                    Text(
                        text = "FÓRMULA CHAVE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = TranspetroTeal.copy(alpha = 0.6f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = formula.expression,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White,
                    modifier = Modifier.padding(12.dp)
                )
            }
            if (formula.variables.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = formula.variables,
                    fontSize = 12.5.sp,
                    color = TranspetroIce.copy(alpha = 0.85f),
                    lineHeight = 17.sp
                )
            }
            if (formula.applicationTip.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Dica Prática: ${formula.applicationTip}",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = TranspetroGold,
                    lineHeight = 17.sp
                )
            }
        }
    }
}

@Composable
fun TableComponent(
    table: TableItem,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = table.title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Header row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                table.headers.forEach { header ->
                    Text(
                        text = header,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Rows
            table.rows.forEachIndexed { index, row ->
                val rowBg = if (index % 2 == 0) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.Transparent
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(rowBg)
                        .padding(8.dp)
                ) {
                    row.forEach { cell ->
                        Text(
                            text = cell,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuestionInteractiveCard(
    question: PracticeQuestion,
    selectedOption: Int?,
    onOptionSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var showExplanation by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("question_card_${question.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${question.code} • ${question.subject}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Surface(
                    color = when (question.difficulty) {
                        "Fácil" -> TranspetroGreenSuccess.copy(alpha = 0.2f)
                        "Médio" -> TranspetroGold.copy(alpha = 0.2f)
                        else -> TranspetroRedAlert.copy(alpha = 0.2f)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = question.difficulty,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (question.difficulty) {
                            "Fácil" -> TranspetroGreenSuccess
                            "Médio" -> TranspetroGoldDark
                            else -> TranspetroRedAlert
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = question.statement,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 21.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Options
            question.options.forEachIndexed { index, opt ->
                val isSelected = selectedOption == index
                val isCorrect = index == question.correctIndex
                val isAnswered = selectedOption != null

                val optBg = when {
                    !isAnswered -> if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    isCorrect -> TranspetroGreenSuccess.copy(alpha = 0.18f)
                    isSelected && !isCorrect -> TranspetroRedAlert.copy(alpha = 0.18f)
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                }

                val optBorder = when {
                    !isAnswered && isSelected -> MaterialTheme.colorScheme.primary
                    isAnswered && isCorrect -> TranspetroGreenSuccess
                    isAnswered && isSelected && !isCorrect -> TranspetroRedAlert
                    else -> Color.Transparent
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(optBg)
                        .border(1.2.dp, optBorder, RoundedCornerShape(8.dp))
                        .clickable(enabled = selectedOption == null) {
                            onOptionSelected(index)
                            showExplanation = true
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = opt,
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (isSelected || (isAnswered && isCorrect)) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                    if (isAnswered) {
                        if (isCorrect) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Correto",
                                tint = TranspetroGreenSuccess,
                                modifier = Modifier.size(20.dp)
                            )
                        } else if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Cancel,
                                contentDescription = "Incorreto",
                                tint = TranspetroRedAlert,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Explanation Section
            AnimatedVisibility(visible = showExplanation || selectedOption != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = TranspetroGoldDark,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "GABARITO COMENTADO",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TranspetroGoldDark
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = question.detailedExplanation,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (question.highYieldTip.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "💡 Dica Cesgranrio: ${question.highYieldTip}",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            lineHeight = 17.sp
                        )
                    }
                }
            }
        }
    }
}
