package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamSimulation
import com.example.data.repository.EBookMasterRepository
import com.example.ui.components.QuestionInteractiveCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.EBookUiState
import com.example.ui.viewmodel.EBookViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimuladosScreen(
    viewModel: EBookViewModel,
    uiState: EBookUiState,
    modifier: Modifier = Modifier
) {
    val simulations = remember { EBookMasterRepository.getSimulations() }
    val activeSim = uiState.activeSimulation

    if (activeSim != null) {
        ActiveSimulationRunner(
            simulation = activeSim,
            viewModel = viewModel,
            uiState = uiState,
            modifier = modifier
        )
    } else {
        SimulationListScreen(
            simulations = simulations,
            onStartSimulation = { viewModel.startSimulation(it) },
            modifier = modifier
        )
    }
}

@Composable
private fun SimulationListScreen(
    simulations: List<ExamSimulation>,
    onStartSimulation: (ExamSimulation) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TranspetroTeal)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "SIMULADOS COMPLETOS PADRÃO CESGRANRIO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TranspetroGold
                    )
                    Text(
                        text = "5 Simulados Oficiais com Cronômetro de 4 Horas",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Treine em condições reais de prova: 60 questões por caderno, contagem regressiva de 240 minutos, diagnóstico de nota de corte e gabarito comentado ao finalizar.",
                        fontSize = 13.sp,
                        color = TranspetroIce.copy(alpha = 0.9f),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        items(simulations) { sim ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("sim_card_${sim.id}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = sim.targetRole,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = TranspetroGoldDark,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${sim.durationMinutes} min",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TranspetroGoldDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = sim.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = sim.description,
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 17.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Nota de Corte Estimada: ${sim.cutoffScore.toInt()}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Button(
                            onClick = { onStartSimulation(sim) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Iniciar Simulado", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ActiveSimulationRunner(
    simulation: ExamSimulation,
    viewModel: EBookViewModel,
    uiState: EBookUiState,
    modifier: Modifier = Modifier
) {
    val totalSeconds = uiState.simRemainingSeconds
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val timeFormatted = String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)

    var currentQuestionIndex by remember { mutableIntStateOf(0) }
    val questions = simulation.questions

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = simulation.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = "Questão ${currentQuestionIndex + 1} de ${questions.size}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.exitSimulation() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Sair")
                    }
                },
                actions = {
                    // Timer Badge
                    Surface(
                        color = if (totalSeconds < 600) TranspetroRedAlert else TranspetroNavyDark,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = timeFormatted,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = modifier
    ) { innerPadding ->
        if (uiState.simIsFinished) {
            SimulationResultView(
                simulation = simulation,
                scorePercentage = uiState.simScorePercentage,
                answers = uiState.simAnswers,
                onExit = { viewModel.exitSimulation() },
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
            ) {
                // Matrix of Question Numbers
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Navegador de Questões (${uiState.simAnswers.size}/${questions.size} respondidas)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val displayCount = questions.size.coerceAtMost(10)
                            for (i in 0 until displayCount) {
                                val isSelected = currentQuestionIndex == i
                                val isAnswered = uiState.simAnswers.containsKey(questions[i].id)
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                isSelected -> MaterialTheme.colorScheme.primary
                                                isAnswered -> TranspetroGreenSuccess
                                                else -> MaterialTheme.colorScheme.surfaceVariant
                                            }
                                        )
                                        .clickable { currentQuestionIndex = i },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${i + 1}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected || isAnswered) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                // Current Question View
                if (questions.isNotEmpty() && currentQuestionIndex < questions.size) {
                    val currentQ = questions[currentQuestionIndex]
                    val selected = uiState.simAnswers[currentQ.id]

                    LazyColumn(modifier = Modifier.weight(1f)) {
                        item {
                            QuestionInteractiveCard(
                                question = currentQ,
                                selectedOption = selected,
                                onOptionSelected = { idx -> viewModel.recordSimAnswer(currentQ.id, idx) }
                            )
                        }
                    }

                    // Navigation Footer
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = { if (currentQuestionIndex > 0) currentQuestionIndex-- },
                            enabled = currentQuestionIndex > 0,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Anterior")
                        }

                        if (currentQuestionIndex < questions.size - 1) {
                            Button(
                                onClick = { currentQuestionIndex++ },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Próxima")
                            }
                        } else {
                            Button(
                                onClick = { viewModel.finishSimulation() },
                                colors = ButtonDefaults.buttonColors(containerColor = TranspetroGreenSuccess),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("finish_simulation_button")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Entregar Prova", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SimulationResultView(
    simulation: ExamSimulation,
    scorePercentage: Float,
    answers: Map<String, Int>,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val passed = scorePercentage >= simulation.cutoffScore

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (passed) TranspetroGreenSuccess.copy(alpha = 0.12f) else TranspetroRedAlert.copy(alpha = 0.12f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = if (passed) Icons.Default.EmojiEvents else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (passed) TranspetroGreenSuccess else TranspetroRedAlert,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (passed) "PARABÉNS! APROVADO NO SIMULADO!" else "PONTUAÇÃO ABAIXO DO CORTE",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = if (passed) TranspetroGreenSuccess else TranspetroRedAlert
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Sua Nota: ${scorePercentage.toInt()}% (Corte: ${simulation.cutoffScore.toInt()}%)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (passed)
                            "Seu desempenho está alinhado com as vagas diretas do PSP Transpetro 2026. Mantenha as revisões ativas para consolidar sua vaga!"
                        else
                            "Não desanime! Identifique os tópicos com erros abaixo, releia a teoria e refaça as questões no caderno de erros.",
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Button(
                onClick = onExit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Voltar à Lista de Simulados", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Gabarito Detalhado das Questões da Prova",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        items(simulation.questions) { q ->
            val userAns = answers[q.id]
            QuestionInteractiveCard(
                question = q,
                selectedOption = userAns,
                onOptionSelected = {}
            )
        }
    }
}
