package com.example.data.parser

import java.io.ByteArrayInputStream
import java.io.InputStreamReader
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets

object CsvParser {

    data class RawTable(
        val headers: List<String>,
        val rows: List<Map<String, String>>,
        val detectedDelimiter: Char,
        val detectedEncoding: String
    )

    /**
     * Detects charset: UTF-8, UTF-8 with BOM, ISO-8859-1 (Latin1), Windows-1252
     */
    fun detectCharset(bytes: ByteArray): Charset {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return StandardCharsets.UTF_8
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return StandardCharsets.UTF_16BE
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return StandardCharsets.UTF_16LE
        }

        // Try decoding as UTF-8
        return try {
            val decoder = StandardCharsets.UTF_8.newDecoder()
            decoder.decode(java.nio.ByteBuffer.wrap(bytes))
            StandardCharsets.UTF_8
        } catch (e: Exception) {
            try {
                Charset.forName("Windows-1252")
            } catch (e2: Exception) {
                StandardCharsets.ISO_8859_1
            }
        }
    }

    /**
     * Auto-detects delimiter by analyzing the first candidate lines.
     * Supports semicolon (;), comma (,), tab (\t), and pipe (|).
     */
    fun detectDelimiter(sampleText: String): Char {
        val lines = sampleText.lineSequence().filter { it.isNotBlank() }.take(5).toList()
        if (lines.isEmpty()) return ';'

        val candidates = listOf(';', ',', '\t', '|')
        var bestDelimiter = ';'
        var highestScore = -1

        for (delimiter in candidates) {
            val counts = lines.map { line -> countDelimiterOutsideQuotes(line, delimiter) }
            val firstCount = counts.firstOrNull() ?: 0
            val allEqual = counts.all { it == firstCount && it > 0 }

            val score = if (allEqual && firstCount > 0) firstCount * 10 else firstCount
            if (score > highestScore) {
                highestScore = score
                bestDelimiter = delimiter
            }
        }

        return bestDelimiter
    }

    private fun countDelimiterOutsideQuotes(line: String, delimiter: Char): Int {
        var count = 0
        var inQuotes = false
        for (ch in line) {
            if (ch == '"') {
                inQuotes = !inQuotes
            } else if (ch == delimiter && !inQuotes) {
                count++
            }
        }
        return count
    }

    /**
     * Parses CSV / TSV text with RFC 4180 compliance (quotes, escaped quotes, newlines in quotes).
     */
    fun parse(bytes: ByteArray): RawTable {
        val charset = detectCharset(bytes)
        var text = String(bytes, charset)

        // Remove BOM if present
        if (text.startsWith("\uFEFF")) {
            text = text.substring(1)
        }

        val delimiter = detectDelimiter(text)
        val allRows = parseDelimitedText(text, delimiter)

        if (allRows.isEmpty()) {
            return RawTable(emptyList(), emptyList(), delimiter, charset.name())
        }

        val rawHeaders = allRows.first()
        val sanitizedHeaders = rawHeaders.mapIndexed { index, header ->
            val clean = header.trim()
            if (clean.isEmpty()) "Coluna_${index + 1}" else clean
        }

        val dataRows = mutableListOf<Map<String, String>>()
        for (i in 1 until allRows.size) {
            val rowValues = allRows[i]
            val rowMap = mutableMapOf<String, String>()
            for (colIdx in sanitizedHeaders.indices) {
                val header = sanitizedHeaders[colIdx]
                val value = if (colIdx < rowValues.size) rowValues[colIdx].trim() else ""
                rowMap[header] = value
            }
            dataRows.add(rowMap)
        }

        return RawTable(
            headers = sanitizedHeaders,
            rows = dataRows,
            detectedDelimiter = delimiter,
            detectedEncoding = charset.name()
        )
    }

    private fun parseDelimitedText(text: String, delimiter: Char): List<List<String>> {
        val result = mutableListOf<List<String>>()
        val currentRow = mutableListOf<String>()
        val currentField = StringBuilder()
        var inQuotes = false
        var i = 0

        while (i < text.length) {
            val ch = text[i]
            when {
                ch == '"' -> {
                    if (inQuotes && i + 1 < text.length && text[i + 1] == '"') {
                        currentField.append('"')
                        i++ // skip escaped quote
                    } else {
                        inQuotes = !inQuotes
                    }
                }
                ch == delimiter && !inQuotes -> {
                    currentRow.add(currentField.toString())
                    currentField.setLength(0)
                }
                (ch == '\r' || ch == '\n') && !inQuotes -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') {
                        i++ // handle CRLF
                    }
                    currentRow.add(currentField.toString())
                    currentField.setLength(0)
                    // Only add if row is not completely empty
                    if (currentRow.any { it.isNotBlank() }) {
                        result.add(currentRow.toList())
                    }
                    currentRow.clear()
                }
                else -> {
                    currentField.append(ch)
                }
            }
            i++
        }

        if (currentField.isNotEmpty() || currentRow.isNotEmpty()) {
            currentRow.add(currentField.toString())
            if (currentRow.any { it.isNotBlank() }) {
                result.add(currentRow.toList())
            }
        }

        return result
    }
}
