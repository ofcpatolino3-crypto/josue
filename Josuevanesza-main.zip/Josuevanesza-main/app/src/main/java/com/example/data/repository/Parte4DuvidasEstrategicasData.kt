package com.example.data.repository

import com.example.data.model.*

object Parte4DuvidasEstrategicasData {
    fun getChapter(): EBookChapter {
        return EBookChapter(
            id = "part4_duvidas_estrategicas",
            partId = "part_4",
            partNumber = 4,
            partTitle = "PARTE 4 — DÚVIDAS ESTRATÉGICAS: O MÉTODO CESGRANRIO",
            chapterNumber = 1,
            title = "Como a Fundação Cesgranrio Costuma Cobrar Matemática e Português",
            subtitle = "Técnicas de Interpretação, Eliminação de Alternativas, Gestão de Tempo e Neutralização de Pegadinhas",
            readTimeMinutes = 18,
            strategicSummary = "A Fundação Cesgranrio é uma banca de estilo direto, contextualizado e avesso a decorebas estéreis. Saber decodificar seus enunciados e administrar os 240 minutos de prova é o diferencial entre o candidato mediano e o futuro empregado da Transpetro.",
            highYieldAlerts = listOf(
                "A Cesgranrio costuma colocar o distrator mais tentador na Alternativa A ou B para pegar candidatos afobados.",
                "Em Português, o comando da questão dita tudo: 'Infere-se do texto' exige dedução lógica; 'De acordo com o texto' exige comprovação explícita na linha citada.",
                "Em Matemática, 80% das questões podem ter alternativas absurdas eliminadas por estimativa rápida de ordem de grandeza."
            ),
            examTraps = listOf(
                "Ler apenas a primeira frase do enunciado e pressupor a pergunta: a Cesgranrio frequentemente insere uma reviravolta na última linha ('Assinale a afirmativa INCORRETA quanto à...').",
                "Gastar mais de 6 minutos em uma única questão de cálculo travada: se a conta não saiu, marque com uma estrela e avance imediatamente!"
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Como Interpretar o Enunciado da Cesgranrio",
                    body = """Os enunciados da Cesgranrio no PSP Transpetro são formulados com precisão cirúrgica. Para interpretá-los com 100% de precisão:

1. Leitura em Duas Camadas:
• 1ª Camada (Visão Panorâmica): Leia o enunciado até o ponto final sem tentar resolver mentalmente. Entenda o tema e o contexto operacional (ex: transferência de produto, cálculo de vazão, reescrita de cláusula).
• 2ª Camada (Filtro do Comando): Isole o que a banca REALMENTE está pedindo. Destaque termos como: 'incorreto', 'exceto', 'respectivamente', 'relação de causa', 'preserva o sentido original'.

2. Decodificação de Textos de Apoio em Português:
• Textos jornalísticos, crônicas e ensaios corporativos: Identifique o posicionamento do autor no primeiro e no último parágrafo.
• Identifique os conectivos de transição: Conectivos adversativos ('no entanto', 'porém') e concessivos ('embora', 'conquanto') marcam as mudanças de direção do pensamento que sempre viram questão de prova!""",
                    bulletPoints = listOf(
                        "Grife com caneta os valores numéricos e as unidades em Matemática.",
                        "Em Português, volte ao texto e leia 2 linhas antes e 2 linhas depois do trecho citado.",
                        "Identifique o sujeito gramatical de cada oração para não cair em falsas concordâncias."
                    )
                ),
                ContentSection(
                    title = "2. As 5 Grandes Pegadinhas da Cesgranrio e Como Neutralizá-las",
                    body = """A Fundação Cesgranrio possui um 'DNA' reconhecível. Estas são suas armadilhas favoritas:

1. O Distrator do 'Senso Comum' (Português):
A banca insere uma alternativa que qualquer pessoa na rua concordaria no dia a dia, mas que viola a norma culta formal (ex: 'Chegou em São Paulo' em vez de 'Chegou a São Paulo', ou 'Entre eu e você' em vez de 'Entre mim e você').

2. A Armadilha da Inversão de Grandezas (Matemática):
Em problemas de regra de três com torneiras, bombas ou operários, a banca coloca como opção A o resultado da multiplicação direta (caso você esqueça de inverter a grandeza proporcional).

3. O Falso Paralelismo de Crase:
'O treinamento destinou-se a técnicos e à engenheiros' (Crase antes de masculino plural = erro clássico).

4. A Pergunta da 'Diferença' ou 'Resto':
O enunciado pede 'quanto SOBROU no tanque' ou 'qual foi a DIFERENÇA entre as vazões', mas a alternativa A traz o valor intermediário calculado (o volume transferido).

5. A Troca Sutil de Conectivo:
Substituir 'visto que' (causa) por 'à medida que' (proporção) sob a falsa alegação de que 'o sentido permanece o mesmo'.""",
                    tables = listOf(
                        TableItem(
                            title = "Guia de Sobrevivência contra Pegadinhas Cesgranrio",
                            headers = listOf("Tipo de Pegadinha", "Como a Banca Arma", "Contra-Ataque do Candidato"),
                            rows = listOf(
                                listOf("Crase antes de Plural", "'Refiro-me à normas'", "Verifique: 'A' no singular + plural = Crase Proibida!"),
                                listOf("Aumento/Desconto Sucessivo", "+10% e -10% = 0%", "Multiplique fatores: 1,10 × 0,90 = 0,99 (-1% real)"),
                                listOf("Verbo Haver Impessoal", "'Haviam muitos registros'", "Haver = existir não tem plural! Use 'Havia'"),
                                listOf("Pergunta do Resto", "A banca pede o saldo remanescente", "Releia o comando final antes de marcar no gabarito"),
                                listOf("Pronome 'Cujo'", "'O técnico cujo o carro...'", "NUNCA use artigo após o pronome cujo!")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "3. Gestão Milimétrica do Tempo (4 Horas = 240 Minutos)",
                    body = """A prova tem 60 questões (10 Português + 10 Matemática + 40 Específicas).
Veja a distribuição ideal cronometrada para maximizar seus pontos:

• Bloco 1 (00:00 às 00:35 - 35 min): Língua Portuguesa (10 questões).
  - Leia o texto de apoio com atenção e responda as questões gramaticais e de interpretação com a mente descansada.
• Bloco 2 (00:35 às 02:20 - 1h45 min): Conhecimentos Específicos (40 questões).
  - As questões específicas possuem peso decisivo e muitas são conceituais diretas. Resolva primeiro as que você tem certeza absoluta.
• Bloco 3 (02:20 às 03:20 - 1 hora): Matemática (10 questões).
  - Faça os cálculos com calma e organize os rascunhos em ordem para não misturar números de questões diferentes.
• Bloco 4 (03:20 às 03:40 - 20 min): Revisão das Questões Marcadas com Dúvida.
  - Retorne apenas às questões que você pulou ou marcou para reavaliação.
• Bloco 5 (03:40 às 04:00 - 20 min): Preenchimento do Cartão-Resposta (Gabarito Oficial).
  - Preencha com caneta preta ou azul transparente em silêncio absoluto e com foco total. Nunca deixe o cartão-resposta para os últimos 5 minutos!""",
                    bulletPoints = listOf(
                        "Tempo médio por questão: 3 minutos e 30 segundos.",
                        "Regra do Pulo Estratégico: Travou há mais de 4 minutos? Marque a bolinha da dúvida no caderno e siga em frente.",
                        "Check de hidratação: Beba pequenos goles de água a cada 45 minutos para oxigenar o cérebro."
                    )
                ),
                ContentSection(
                    title = "4. Técnica de Eliminação de Alternativas e 'Chute Consciente'",
                    body = """Como toda questão da Cesgranrio possui 5 alternativas (A, B, C, D, E), chutar aleatoriamente dá apenas 20% de chance de acerto. Ao aplicar a técnica de eliminação, sua probabilidade salta para 50% ou 100%!

Método do Filtro de 3 Etapas:
1. Elimine os Extremos e Absurdos (1ª Passada):
Em questões de cálculo, elimine valores que são ordens de grandeza maiores ou menores que o fisicamente possível. Em Português, elimine alternativas com generalizações radicais ('nunca', 'jamais', 'em todas as circunstâncias').

2. Isole as Alternativas 'Gêmeas' ou Contraditórias:
Muitas vezes a Cesgranrio coloca duas opções quase idênticas que divergem apenas em um sinal ou preposição. Quase sempre, a resposta correta é uma dessas duas!

3. O Critério da Consistência Sistêmica:
Se restar dúvida entre duas opções, escolha a alternativa que melhor se alinha com a segurança das operações, a ética corporativa e a precisão técnica da Transpetro.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "REGRA SAGRADA DO GABARITO",
                            content = "NUNCA troque a resposta marcada no calor da primeira resolução no cartão-resposta, a menos que você tenha encontrado um erro factual evidente e comprovado no rascunho. Estatisticamente, candidatos trocam respostas certas por erradas no final da prova por ansiedade.",
                            iconType = "ALERT"
                        )
                    )
                )
            )
        )
    }
}
