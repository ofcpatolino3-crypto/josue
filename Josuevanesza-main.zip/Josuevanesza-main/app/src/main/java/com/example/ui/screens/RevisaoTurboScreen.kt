package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.Parte12RevisaoTurboData
import com.example.data.repository.Parte13MapasMentaisData
import com.example.ui.components.AttentionBoxView
import com.example.ui.components.TableComponent
import com.example.ui.theme.TranspetroGold
import com.example.ui.theme.TranspetroGreenSuccess
import com.example.ui.theme.TranspetroNavyPrimary
import com.example.ui.viewmodel.EBookUiState
import com.example.ui.viewmodel.EBookViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RevisaoTurboScreen(
    viewModel: EBookViewModel,
    uiState: EBookUiState,
    modifier: Modifier = Modifier
) {
    val revisaoChapter = remember { Parte12RevisaoTurboData.getChapter() }
    val mapasChapter = remember { Parte13MapasMentaisData.getChapter() }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("100 Conceitos de Ouro", "Mapas Mentais Textuais", "Checklist de Véspera")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        // Top Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = TranspetroNavyPrimary)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = null,
                            tint = TranspetroGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "REVISÃO TURBO TRANSPETRO 2026",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TranspetroGold
                        )
                    }
                    Text(
                        text = "100 Conceitos de Ouro & Mapas Mentais",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Compilação ultraconcentrada dos tópicos que somam mais de 80% das questões das provas anteriores da Cesgranrio.",
                        fontSize = 12.5.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // Sub Tabs
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontSize = 12.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> {
                // 100 Conceitos de Ouro
                revisaoChapter.contentSections.forEach { sec ->
                    item {
                        Text(
                            text = sec.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = sec.body,
                                    fontSize = 13.5.sp,
                                    lineHeight = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    if (sec.tables.isNotEmpty()) {
                        items(sec.tables.size) { idx ->
                            TableComponent(table = sec.tables[idx])
                        }
                    }

                    if (sec.attentionBoxes.isNotEmpty()) {
                        items(sec.attentionBoxes.size) { idx ->
                            AttentionBoxView(box = sec.attentionBoxes[idx])
                        }
                    }
                }
            }
            1 -> {
                // Mapas Mentais Textuais
                mapasChapter.contentSections.forEach { sec ->
                    item {
                        Text(
                            text = sec.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = sec.body.removePrefix("```text\n").removeSuffix("\n```"),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                }
            }
            2 -> {
                // Checklist de Véspera
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = TranspetroGreenSuccess.copy(alpha = 0.1f)),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Checklist,
                                    contentDescription = null,
                                    tint = TranspetroGreenSuccess,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "CHECKLIST OBRIGATÓRIO PARA O DIA DA PROVA",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TranspetroGreenSuccess
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            val checklistItems = listOf(
                                "Documento oficial original de identificação com foto em perfeitas condições (RG, CNH ou Passaporte).",
                                "Pelo menos 2 canetas esferográficas de corpo transparente com tinta PRETA ou AZUL escura.",
                                "Cartão de Confirmação de Inscrição (CCI) impresso com endereço do local de prova e número de sala.",
                                "Garrafa de água transparente e sem rótulo.",
                                "Alimento leve para o meio da prova (barra de cereal, frutas ou chocolate).",
                                "Chegar com no mínimo 1 hora e 15 minutos de antecedência ao fechamento dos portões.",
                                "Dormir de 7 a 8 horas na noite anterior e manter a mente tranquila e focada!"
                            )
                            checklistItems.forEach { itemText ->
                                Row(modifier = Modifier.padding(vertical = 4.dp)) {
                                    Text(text = "☑ ", fontWeight = FontWeight.Bold, color = TranspetroGreenSuccess, fontSize = 14.sp)
                                    Text(text = itemText, fontSize = 13.sp, lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
