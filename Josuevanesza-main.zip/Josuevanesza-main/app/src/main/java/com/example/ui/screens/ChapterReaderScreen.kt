package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EBookUiState
import com.example.ui.viewmodel.EBookViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterReaderScreen(
    chapter: EBookChapter,
    viewModel: EBookViewModel,
    uiState: EBookUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCompleted = uiState.completedChapterIds.contains(chapter.id)
    val isFavorite = uiState.favoriteChapterIds.contains(chapter.id)

    // Reading Mode Background
    val readerBackground = when {
        uiState.isSepiaMode -> Color(0xFFFBF0D9)
        uiState.isNightReadingMode -> Color(0xFF121824)
        else -> MaterialTheme.colorScheme.background
    }

    val readerTextColor = when {
        uiState.isSepiaMode -> Color(0xFF382C1E)
        uiState.isNightReadingMode -> Color(0xFFE2E8F0)
        else -> MaterialTheme.colorScheme.onBackground
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = chapter.partTitle,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = chapter.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    // Zoom A- / A+
                    IconButton(onClick = { viewModel.decreaseFontSize() }) {
                        Icon(Icons.Default.TextDecrease, contentDescription = "Diminuir Fonte")
                    }
                    IconButton(onClick = { viewModel.increaseFontSize() }) {
                        Icon(Icons.Default.TextIncrease, contentDescription = "Aumentar Fonte")
                    }
                    // Sepia Mode
                    IconButton(onClick = { viewModel.toggleSepiaMode() }) {
                        Icon(
                            Icons.Default.ColorLens,
                            contentDescription = "Modo Sépia",
                            tint = if (uiState.isSepiaMode) TranspetroGoldDark else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    // Bookmark / Fav
                    IconButton(onClick = { viewModel.toggleFavorite(chapter.id) }) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Favoritar",
                            tint = if (isFavorite) TranspetroGoldDark else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(readerBackground)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp)
        ) {
            // Chapter Header Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Capítulo ${chapter.chapterNumber} • ~${chapter.readTimeMinutes} min de leitura",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isCompleted,
                                    onCheckedChange = { viewModel.toggleChapterCompletion(chapter.id) }
                                )
                                Text(
                                    text = if (isCompleted) "Concluído" else "Marcar lido",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                        Text(
                            text = chapter.title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = chapter.subtitle,
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Resumo Estratégico do Capítulo
            if (chapter.strategicSummary.isNotBlank()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = TranspetroNavyPrimary.copy(alpha = 0.06f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Lightbulb,
                                    contentDescription = null,
                                    tint = TranspetroNavyPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "RESUMO ESTRATÉGICO PARA A PROVA",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = TranspetroNavyPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = chapter.strategicSummary,
                                fontSize = uiState.readerFontSizeSp.sp,
                                color = readerTextColor,
                                lineHeight = (uiState.readerFontSizeSp * 1.45f).sp
                            )
                        }
                    }
                }
            }

            // High-Yield Alerts
            if (chapter.highYieldAlerts.isNotEmpty()) {
                item {
                    AttentionBoxView(
                        box = AttentionBoxData(
                            title = "PONTOS DE ALTO RENDIMENTO (MAIOR INCIDÊNCIA)",
                            content = chapter.highYieldAlerts.joinToString("\n\n• ", prefix = "• "),
                            iconType = "ALERT"
                        )
                    )
                }
            }

            // Exam Traps
            if (chapter.examTraps.isNotEmpty()) {
                item {
                    ExamTrapCard(
                        trap = ExamTrapData(
                            title = "Armadilhas Frequentes da Cesgranrio no Assunto",
                            trapDescription = chapter.examTraps.joinToString("\n\n• ", prefix = "• "),
                            howToAvoid = "Releia com atenção redobrada e aplique as regras da norma culta e fórmulas oficiais."
                        )
                    )
                }
            }

            // Content Sections
            chapter.contentSections.forEach { section ->
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = section.title,
                        fontSize = (uiState.readerFontSizeSp + 2f).sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                    Text(
                        text = section.body,
                        fontSize = uiState.readerFontSizeSp.sp,
                        color = readerTextColor,
                        lineHeight = (uiState.readerFontSizeSp * 1.5f).sp
                    )
                }

                // Bullets
                if (section.bulletPoints.isNotEmpty()) {
                    item {
                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            section.bulletPoints.forEach { pt ->
                                Row(modifier = Modifier.padding(vertical = 3.dp)) {
                                    Text(text = "• ", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text(
                                        text = pt,
                                        fontSize = uiState.readerFontSizeSp.sp,
                                        color = readerTextColor,
                                        lineHeight = (uiState.readerFontSizeSp * 1.4f).sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Formulas
                if (section.formulas.isNotEmpty()) {
                    items(section.formulas) { formula ->
                        FormulaCard(formula = formula)
                    }
                }

                // Tables
                if (section.tables.isNotEmpty()) {
                    items(section.tables) { table ->
                        TableComponent(table = table)
                    }
                }

                // Attention Boxes inside section
                if (section.attentionBoxes.isNotEmpty()) {
                    items(section.attentionBoxes) { box ->
                        AttentionBoxView(box = box)
                    }
                }

                // Exam Traps inside section
                if (section.examTraps.isNotEmpty()) {
                    items(section.examTraps) { trap ->
                        ExamTrapCard(trap = trap)
                    }
                }

                // Practical Examples
                if (section.practicalExamples.isNotEmpty()) {
                    items(section.practicalExamples) { eg ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "EXEMPLO PRÁTICO RESOLVIDO",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = eg.scenario,
                                    fontSize = uiState.readerFontSizeSp.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = readerTextColor
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = eg.stepByStepSolution,
                                    fontSize = (uiState.readerFontSizeSp - 1f).sp,
                                    lineHeight = (uiState.readerFontSizeSp * 1.4f).sp,
                                    color = readerTextColor
                                )
                                if (eg.keyTakeaway.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Conclusão Chave: ${eg.keyTakeaway}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TranspetroGoldDark
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Chapter Practice Questions Section
            if (chapter.questions.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Quiz,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "QUESTÕES DE FIXAÇÃO & GABARITO COMENTADO",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                items(chapter.questions) { q ->
                    val selected = uiState.userQuizAnswers[q.id]
                    QuestionInteractiveCard(
                        question = q,
                        selectedOption = selected,
                        onOptionSelected = { idx -> viewModel.answerQuizQuestion(q.id, idx) }
                    )
                }
            }

            // Bottom Complete Button
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        viewModel.toggleChapterCompletion(chapter.id)
                        onBack()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("finish_chapter_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCompleted) TranspetroGreenSuccess else MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.Done,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isCompleted) "Capítulo Concluído! (Voltar ao Sumário)" else "Marcar como Lido e Voltar",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
