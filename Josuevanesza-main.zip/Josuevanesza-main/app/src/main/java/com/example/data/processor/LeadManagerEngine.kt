package com.example.data.processor

import com.example.data.model.*
import com.example.data.parser.CsvParser
import com.example.data.parser.XlsxParser
import com.example.data.util.PhoneSafetyHandler
import java.text.Normalizer

object LeadManagerEngine {

    /**
     * Complete and safe processing of any lead file (CSV, TSV, XLSX, XLS, XML).
     * Follows strict zero data loss rules.
     * Automatically maps Curso/Concurso, WhatsApp, Email, Temperatura, Observação, etc.
     */
    fun processFile(
        fileName: String,
        bytes: ByteArray,
        customCourseCol: String? = null,
        customObsCol: String? = null
    ): FileParseResult {
        val lowerName = fileName.lowercase()
        val rawTable = when {
            lowerName.endsWith(".xlsx") -> {
                try {
                    val res = XlsxParser.parseXlsx(bytes)
                    CsvParser.RawTable(res.headers, res.rows, ';', "UTF-8 (XLSX)")
                } catch (e: Exception) {
                    // Fallback try as CSV if file was misnamed
                    CsvParser.parse(bytes)
                }
            }
            lowerName.endsWith(".xml") || (lowerName.endsWith(".xls") && isXmlSpreadsheet(bytes)) -> {
                try {
                    val text = String(bytes, Charsets.UTF_8)
                    val res = XlsxParser.parseXmlSpreadsheet(text)
                    CsvParser.RawTable(res.headers, res.rows, ';', "XML Spreadsheet")
                } catch (e: Exception) {
                    CsvParser.parse(bytes)
                }
            }
            else -> {
                CsvParser.parse(bytes)
            }
        }

        val headers = rawTable.headers
        val rows = rawTable.rows

        // Detect Columns safely using strict normalized matching or user custom selection
        val phoneCol = detectPhoneColumn(headers, rows)
        val nameCol = detectNameColumn(headers)
        val emailCol = detectEmailColumn(headers)
        var courseCol = if (customCourseCol != null) {
            if (customCourseCol == "__NONE__") null else customCourseCol
        } else {
            detectCourseColumn(headers)
        }
        val tempCol = detectTemperatureColumn(headers)
        var obsCol = if (customObsCol != null) {
            if (customObsCol == "__NONE__") null else customObsCol
        } else {
            detectObservationColumn(headers)
        }
        val respCol = detectResponsibleColumn(headers)
        val statusCol = detectStatusColumn(headers)
        val campCol = detectCampaignColumn(headers)

        // SMART COURSE RECOVERY:
        // If course column was not detected in headers, check if the observation column
        // actually holds the course that the student bought (e.g. Polícia Federal, Delegado, etc.)!
        if (customCourseCol == null && courseCol == null && obsCol != null) {
            val sampleValues = rows.take(40)
                .mapNotNull { (it[obsCol] ?: "").trim() }
                .filter { it.isNotBlank() }
            val courseLikeCount = sampleValues.count { isCourseLikeText(it) }
            if (sampleValues.isNotEmpty() && (courseLikeCount >= 1 || sampleValues.size <= 2)) {
                courseCol = obsCol
                obsCol = null
            }
        }

        // Internal Validation and Conflict Detection
        var hasConflict = false
        var conflictMsg: String? = null

        // 1. Check if Course and Observation ever collide
        if (courseCol != null && obsCol != null && courseCol.equals(obsCol, ignoreCase = true)) {
            hasConflict = true
            conflictMsg = "Conflito: A coluna '$courseCol' foi mapeada para Curso e Observação simultaneamente. Importação bloqueada."
        }

        // 2. Check if Phone and Name ever collide
        if (phoneCol != null && nameCol != null && phoneCol.equals(nameCol, ignoreCase = true)) {
            hasConflict = true
            conflictMsg = "Conflito: A coluna '$phoneCol' foi mapeada para Telefone e Nome simultaneamente."
        }

        // 3. Check for duplicated headers in original file
        val headerFreq = headers.groupingBy { normalizeHeader(it) }.eachCount()
        val dup = headerFreq.entries.find { it.value > 1 && it.key.isNotBlank() }
        if (dup != null) {
            hasConflict = true
            conflictMsg = "Aviso de Conflito: O arquivo possui colunas duplicadas com o mesmo cabeçalho ('${dup.key}')."
        }

        // Build Column Mapping Report (Cabeçalho original → Campo do sistema → Quantidade de valores)
        val columnMappings = mutableListOf<ColumnMappingItem>()

        if (nameCol != null) {
            val count = rows.count { (it[nameCol] ?: "").trim().isNotBlank() }
            columnMappings.add(ColumnMappingItem(
                originalHeader = nameCol,
                targetField = "Nome",
                filledCount = count
            ))
        }

        if (phoneCol != null) {
            val count = rows.count { (it[phoneCol] ?: "").trim().isNotBlank() }
            columnMappings.add(ColumnMappingItem(
                originalHeader = phoneCol,
                targetField = "Telefone / WhatsApp",
                filledCount = count
            ))
        }

        if (emailCol != null) {
            val count = rows.count { (it[emailCol] ?: "").trim().isNotBlank() }
            columnMappings.add(ColumnMappingItem(
                originalHeader = emailCol,
                targetField = "E-mail",
                filledCount = count
            ))
        }

        if (courseCol != null) {
            val count = rows.count {
                val raw = it[courseCol] ?: ""
                sanitizeCourseValue(raw).isNotBlank()
            }
            columnMappings.add(ColumnMappingItem(
                originalHeader = courseCol,
                targetField = "Curso / Concurso",
                filledCount = count
            ))
        }

        if (obsCol != null) {
            val count = rows.count { (it[obsCol] ?: "").trim().isNotBlank() }
            columnMappings.add(ColumnMappingItem(
                originalHeader = obsCol,
                targetField = "Observação",
                filledCount = count
            ))
        }

        if (tempCol != null) {
            val count = rows.count { (it[tempCol] ?: "").trim().isNotBlank() }
            columnMappings.add(ColumnMappingItem(
                originalHeader = tempCol,
                targetField = "Temperatura",
                filledCount = count
            ))
        }

        if (respCol != null) {
            val count = rows.count { (it[respCol] ?: "").trim().isNotBlank() }
            columnMappings.add(ColumnMappingItem(
                originalHeader = respCol,
                targetField = "Responsável",
                filledCount = count
            ))
        }

        val parsedLeads = mutableListOf<Lead>()
        val readErrors = mutableListOf<String>()

        for (index in rows.indices) {
            val row = rows[index]
            try {
                val rawPhone = if (phoneCol != null) row[phoneCol] ?: "" else findPhoneInRow(row)
                val sanitizedPhone = PhoneSafetyHandler.sanitizeRawPhone(rawPhone)
                val normalizedPhone = PhoneSafetyHandler.normalizePhone(sanitizedPhone)

                val name = if (nameCol != null) (row[nameCol] ?: "").trim() else ""
                val email = if (emailCol != null) (row[emailCol] ?: "").trim() else ""

                // STRICT RULE: Curso / Concurso comes EXCLUSIVELY from the detected course column
                val rawCourse = if (courseCol != null) (row[courseCol] ?: "") else ""
                var sanitizedCourse = sanitizeCourseValue(rawCourse)

                // STRICT RULE: Observação comes EXCLUSIVELY from the detected observation column
                val rawObs = if (obsCol != null) (row[obsCol] ?: "") else ""
                var sanitizedObs = rawObs.trim()

                // If course is still blank, but observation explicitly indicates what the student bought:
                // (e.g. "Curso: Polícia Federal", "Comprou: Delegado Civil", "Produto: PRF", "Adquiriu: ..."):
                if (sanitizedCourse.isBlank() && sanitizedObs.isNotBlank()) {
                    val prefixes = listOf("curso:", "comprou:", "produto:", "adquiriu:", "matricula:", "matrícula:", "turma:")
                    val matchedPrefix = prefixes.find { sanitizedObs.startsWith(it, ignoreCase = true) }
                    if (matchedPrefix != null) {
                        sanitizedCourse = sanitizedObs.substring(matchedPrefix.length).trim()
                        sanitizedObs = ""
                    } else if (courseCol == null && isCourseLikeText(sanitizedObs)) {
                        sanitizedCourse = sanitizedObs
                        sanitizedObs = ""
                    }
                }

                // Temperature
                val temp = if (tempCol != null) (row[tempCol] ?: "").trim() else ""

                val responsible = if (respCol != null) (row[respCol] ?: "").trim() else ""
                val status = if (statusCol != null) (row[statusCol] ?: "").trim() else ""
                val campaign = if (campCol != null) (row[campCol] ?: "").trim() else ""

                val lead = Lead(
                    id = "lead_${index + 1}",
                    originalRowIndex = index + 1,
                    name = name,
                    originalPhone = sanitizedPhone,
                    normalizedPhone = normalizedPhone,
                    email = email,
                    course = sanitizedCourse,
                    temperature = temp,
                    observation = sanitizedObs,
                    responsible = responsible,
                    status = status,
                    campaign = campaign,
                    rawData = row
                )
                parsedLeads.add(lead)
            } catch (e: Exception) {
                readErrors.add("Erro na linha ${index + 1}: ${e.message}")
            }
        }

        // Flag duplicates without removing them!
        val leadsWithDuplicity = flagDuplicates(parsedLeads)

        val fileType = when {
            lowerName.endsWith(".xlsx") -> "Excel XLSX"
            lowerName.endsWith(".xls") -> "Excel XLS"
            lowerName.endsWith(".xml") -> "XML Spreadsheet"
            lowerName.endsWith(".tsv") -> "TSV"
            else -> "CSV Delimitado"
        }

        // Generate pre-import validation comparison: Arquivo Original × Dados Importados
        val validation = ImportValidationComparison(
            totalRowsInFile = rows.size,
            totalLeadsParsed = leadsWithDuplicity.size,
            leadsWithDetectedName = leadsWithDuplicity.count { it.hasName },
            leadsWithDetectedPhone = leadsWithDuplicity.count { it.hasPhone },
            leadsWithDetectedEmail = leadsWithDuplicity.count { it.hasEmail },
            leadsWithDetectedCourse = leadsWithDuplicity.count { it.hasCourse },
            leadsWithDetectedTemperature = leadsWithDuplicity.count { it.hasTemperature },
            leadsWithDetectedObservation = leadsWithDuplicity.count { it.hasObservation },
            courseColumnFound = courseCol,
            phoneColumnFound = phoneCol,
            nameColumnFound = nameCol,
            emailColumnFound = emailCol,
            temperatureColumnFound = tempCol,
            observationColumnFound = obsCol,
            isCoursePreserved = true,
            columnMappings = columnMappings,
            hasMappingConflict = hasConflict,
            conflictDetails = conflictMsg
        )

        return FileParseResult(
            fileName = fileName,
            fileType = fileType,
            detectedEncoding = rawTable.detectedEncoding,
            detectedDelimiter = rawTable.detectedDelimiter,
            totalRowsRead = rows.size,
            headers = headers,
            leads = leadsWithDuplicity,
            phoneColumnName = phoneCol,
            nameColumnName = nameCol,
            emailColumnName = emailCol,
            courseColumnName = courseCol,
            temperatureColumnName = tempCol,
            observationColumnName = obsCol,
            responsibleColumnName = respCol,
            statusColumnName = statusCol,
            campaignColumnName = campCol,
            readErrors = readErrors,
            validationComparison = validation,
            columnMappings = columnMappings,
            hasMappingConflict = hasConflict,
            mappingConflictMessage = conflictMsg
        )
    }

    private fun isXmlSpreadsheet(bytes: ByteArray): Boolean {
        val sample = String(bytes.take(200).toByteArray(), Charsets.UTF_8)
        return sample.contains("<?xml") || sample.contains("<Workbook")
    }

    /**
     * Normalizes a header or text by removing accents, lowercasing,
     * replacing separators (/, -, _, :, ., ,, ;, |, (, ), [, ]) with spaces,
     * and collapsing multiple whitespaces into a single space.
     */
    fun normalizeHeader(raw: String): String {
        val noDiacritics = Normalizer.normalize(raw, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase()

        val cleanSeparators = noDiacritics
            .replace('/', ' ')
            .replace('-', ' ')
            .replace('_', ' ')
            .replace(':', ' ')
            .replace('.', ' ')
            .replace(',', ' ')
            .replace(';', ' ')
            .replace('|', ' ')
            .replace('(', ' ')
            .replace(')', ' ')
            .replace('[', ' ')
            .replace(']', ' ')

        return cleanSeparators.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Sanitizes course cell value.
     * CRITICAL RULE: "Ex: Polícia Federal" or similar dummy strings must ONLY be example placeholders
     * and must NEVER be treated or saved as the lead's course value.
     * When cell is empty or has a placeholder, returns empty string ("").
     * Never auto-fills "Polícia Federal" when not in original file.
     */
    fun sanitizeCourseValue(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return ""

        val norm = normalizeHeader(trimmed)
        if (norm.startsWith("ex ") || norm.startsWith("exemplo ") ||
            norm == "ex policia federal" || norm == "ex policia" ||
            norm == "exemplo de curso" || norm == "exemplo" ||
            norm == "ex concurso" || norm == "policia federal exemplo"
        ) {
            return ""
        }

        return trimmed
    }

    /**
     * Checks if a text value looks like a course, exam, or purchased educational training.
     */
    fun isCourseLikeText(text: String): Boolean {
        val norm = normalizeHeader(text)
        if (norm.isBlank()) return false
        val courseKeywords = listOf(
            "policia", "federal", "civil", "militar", "prf", "pf", "oab", "delegado",
            "auditor", "tribunal", "tcu", "tce", "inss", "carreiras", "curso", "concurso",
            "combo", "direito", "analista", "tecnico", "banco", "edital", "turma",
            "modulo", "preparatorio", "intensivo", "comprou", "adquiriu", "pacote", "plano",
            "regular", "assinatura", "bancaria", "fiscal", "juridica", "administrativo",
            "saude", "medicina", "residencia", "vestibular", "enem", "transpetro", "petrobras",
            "caixa", "correios", "receita", "senado", "camara", "banco do brasil"
        )
        return courseKeywords.any { norm.contains(it) }
    }

    /**
     * Detects column for Curso / Concurso matching all variations of what the student bought:
     * CURSO QUE O ALUNO COMPROU, CURSO COMPRADO, O QUE COMPROU, COMPRA, COMPRAS,
     * PRODUTO COMPRADO, ITEM COMPRADO, CURSO ADQUIRIDO, DETALHES DA COMPRA, OBS DO CURSO,
     * CURSO, CURSO/CONCURSO, CONCURSO, PRODUTO, ITEM, etc.
     * NEVER misidentifies as observation.
     */
    fun detectCourseColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }

        // Priority 1: Exact matches for course, purchase, and acquired product terms
        val directKeywords = listOf(
            "curso que o aluno comprou", "curso que comprou", "curso do aluno comprou",
            "curso comprado", "cursos comprados", "curso do aluno", "concurso do aluno",
            "o que o aluno comprou", "o que comprou", "o que foi comprado", "o que adquiriu",
            "produto que o aluno comprou", "produto que comprou", "produto comprado",
            "produtos comprados", "produto adquirido", "produtos adquiridos",
            "item que comprou", "item comprado", "itens comprados",
            "curso adquirido", "cursos adquiridos", "curso matriculado",
            "obs do curso", "observacao do curso", "observacoes do curso",
            "curso obs", "obs curso", "observacao curso", "curso observacao",
            "detalhes do curso", "detalhes da compra", "detalhes do produto",
            "descricao do curso", "descricao do produto", "descricao produto",
            "compra do aluno", "compra", "compras", "comprado", "comprou",
            "adquirido", "adquiridos", "matricula", "turma", "turmas",
            "treinamento", "pacote", "pacotes", "plano", "planos", "oferta", "ofertas",
            "curso concurso", "concurso curso",
            "nome do curso", "nome do concurso", "nomedocurso", "nomedoconcurso",
            "curso pretendido", "concurso pretendido", "curso de interesse", "concurso de interesse",
            "produto curso", "curso produto",
            "curso", "concurso"
        )
        for (kw in directKeywords) {
            val idx = normalizedList.indexOfFirst { it == kw }
            if (idx != -1) return headers[idx]
        }

        // Priority 2: Substring matches for course / purchase keywords
        // Ignores phone, email, and name columns to avoid false positives
        for (kw in directKeywords) {
            val idx = normalizedList.indexOfFirst {
                it.contains(kw) && !it.contains("email") && !it.contains("telefone") &&
                        !it.contains("whatsapp") && !it.contains("nome") && !it.contains("responsavel")
            }
            if (idx != -1) return headers[idx]
        }

        // Priority 3: Product / Item / Cargo variations
        val productKeywords = listOf(
            "produto", "produtos", "produto adquirido", "descricao do produto",
            "item", "itens", "nome do item", "nome do produto", "itens do curso",
            "itens adquiridos", "cargo", "vaga", "interesse"
        )
        for (kw in productKeywords) {
            val idx = normalizedList.indexOfFirst { it == kw }
            if (idx != -1) return headers[idx]
        }
        for (kw in productKeywords) {
            val idx = normalizedList.indexOfFirst {
                (it.startsWith("$kw ") || it.endsWith(" $kw") || it.contains(kw)) &&
                        !it.contains("email") && !it.contains("telefone") && !it.contains("nome")
            }
            if (idx != -1) return headers[idx]
        }

        return null
    }

    /**
     * Detects column for Observação strictly.
     * Accepted: Observação, Observações, Obs, Anotação, Anotações, Comentário, Comentários, Nota, Notas.
     * STRICT: NEVER matches any course, purchase, product, or item column!
     */
    fun detectObservationColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }

        val obsKeywords = listOf(
            "observacao", "observacoes", "obs",
            "anotacao", "anotacoes",
            "comentario", "comentarios",
            "nota", "notas",
            "mensagem", "historico"
        )

        // Strict: Any column describing courses, purchases or products MUST NOT be matched as observation!
        fun isExcluded(norm: String): Boolean {
            return norm.contains("curso") || norm.contains("concurso") ||
                    norm.contains("produto") || norm.contains("item") ||
                    norm.contains("compra") || norm.contains("compr") ||
                    norm.contains("adquir") || norm.contains("matric") ||
                    norm.contains("turma") || norm.contains("plano") ||
                    norm.contains("pacote") || norm.contains("trein") ||
                    norm.contains("pedido") || norm.contains("oferta")
        }

        for (kw in obsKeywords) {
            val idx = normalizedList.indexOfFirst {
                (it == kw || it.startsWith("$kw ") || it.endsWith(" $kw")) && !isExcluded(it)
            }
            if (idx != -1) return headers[idx]
        }

        for (kw in obsKeywords) {
            val idx = normalizedList.indexOfFirst {
                it.contains(kw) && !isExcluded(it)
            }
            if (idx != -1) return headers[idx]
        }

        return null
    }

    fun detectTemperatureColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }
        val keywords = listOf(
            "temperatura", "temp", "qualificacao", "calor", "score", "grau", "prioridade", "nivel"
        )
        for (kw in keywords) {
            val idx = normalizedList.indexOfFirst { it == kw || it.startsWith("$kw ") || it.contains(kw) }
            if (idx != -1) return headers[idx]
        }
        return null
    }

    fun detectPhoneColumn(headers: List<String>, rows: List<Map<String, String>>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }

        val phoneKeywords = listOf(
            "whatsapp", "zap", "wpp", "telefone whatsapp", "whatsapp telefone", "telefone cel",
            "celular", "telefone", "numero do telefone", "numero de telefone", "numero telefone",
            "numero", "tel", "cel", "phone", "mobile", "fone"
        )

        // 1. Try matching header name
        for (kw in phoneKeywords) {
            val idx = normalizedList.indexOfFirst {
                (it == kw || it.startsWith("$kw ") || it.contains(kw)) &&
                        !it.contains("curso") && !it.contains("concurso") &&
                        !it.contains("obs") && !it.contains("nota")
            }
            if (idx != -1) return headers[idx]
        }

        // 2. Sample column values (never pick a column that clearly has names or courses)
        for (h in headers) {
            val norm = normalizeHeader(h)
            if (norm.contains("curso") || norm.contains("concurso") || norm.contains("obs") ||
                norm.contains("nome") || norm.contains("produto") || norm.contains("email")
            ) {
                continue
            }
            val sampleValues = rows.take(20).mapNotNull { it[h] }
            if (PhoneSafetyHandler.isPhoneColumnBySampling(sampleValues)) {
                return h
            }
        }

        return null
    }

    fun detectNameColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }

        val nameKeywords = listOf(
            "nome completo", "nome do contato", "nome cliente", "nome do cliente",
            "nome", "cliente", "contato", "lead", "full name", "titular", "aluno"
        )

        // Must NOT match if it's "nome do curso", "nome do concurso", "nome do produto", "nome do item"
        for (kw in nameKeywords) {
            val idx = normalizedList.indexOfFirst {
                it == kw &&
                        !it.contains("curso") && !it.contains("concurso") &&
                        !it.contains("produto") && !it.contains("item")
            }
            if (idx != -1) return headers[idx]
        }

        for (kw in nameKeywords) {
            val idx = normalizedList.indexOfFirst {
                (it.startsWith("$kw ") || it.contains(kw)) &&
                        !it.contains("curso") && !it.contains("concurso") &&
                        !it.contains("produto") && !it.contains("item")
            }
            if (idx != -1) return headers[idx]
        }

        return null
    }

    fun detectEmailColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }

        val emailKeywords = listOf(
            "email do cliente", "e mail do cliente", "email contato", "e mail contato",
            "email", "e mail", "mail", "correio"
        )

        for (kw in emailKeywords) {
            val idx = normalizedList.indexOfFirst { it == kw || it.contains(kw) }
            if (idx != -1) return headers[idx]
        }

        return null
    }

    fun detectResponsibleColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }
        val keywords = listOf(
            "responsavel", "atendente", "vendedor", "consultor",
            "dono", "proprietario", "corretor", "owner", "user", "assigned", "agente"
        )
        for (kw in keywords) {
            val idx = normalizedList.indexOfFirst { it == kw || it.contains(kw) }
            if (idx != -1) return headers[idx]
        }
        return null
    }

    fun detectStatusColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }
        val keywords = listOf("status", "situacao", "fase", "etapa", "estado")
        for (kw in keywords) {
            val idx = normalizedList.indexOfFirst { it == kw || it.contains(kw) }
            if (idx != -1) return headers[idx]
        }
        return null
    }

    fun detectCampaignColumn(headers: List<String>): String? {
        val normalizedList = headers.map { normalizeHeader(it) }
        val keywords = listOf("campanha", "origem", "fonte", "campaign", "utm source", "midia")
        for (kw in keywords) {
            val idx = normalizedList.indexOfFirst { it == kw || it.contains(kw) }
            if (idx != -1) return headers[idx]
        }
        return null
    }

    private fun findPhoneInRow(row: Map<String, String>): String {
        for (value in row.values) {
            val digits = value.filter { it.isDigit() }
            if (digits.length in 8..15) {
                return value
            }
        }
        return ""
    }

    private fun flagDuplicates(leads: List<Lead>): List<Lead> {
        val phoneCounts = mutableMapOf<String, Int>()
        for (lead in leads) {
            if (lead.normalizedPhone.isNotBlank()) {
                phoneCounts[lead.normalizedPhone] = (phoneCounts[lead.normalizedPhone] ?: 0) + 1
            }
        }

        return leads.map { lead ->
            val count = if (lead.normalizedPhone.isNotBlank()) {
                phoneCounts[lead.normalizedPhone] ?: 1
            } else 1

            lead.copy(
                isDuplicate = count > 1,
                duplicateCount = count
            )
        }
    }

    fun generateIntegrityReport(leads: List<Lead>, readErrors: List<String>): IntegrityReport {
        val total = leads.size
        val withPhone = leads.count { it.hasPhone }
        val withoutPhone = total - withPhone
        val withEmail = leads.count { it.hasEmail }
        val withCourse = leads.count { it.hasCourse }
        val phonesPreserved = withPhone
        val phonesLost = 0
        val duplicates = leads.count { it.isDuplicate }

        val responsibleMap = leads.groupBy {
            it.responsible.ifBlank { "Sem Responsável" }
        }.mapValues { it.value.size }

        val alerts = mutableListOf<String>()
        if (withoutPhone > 0) {
            alerts.add("Atenção: $withoutPhone lead(s) não possuíam telefone no arquivo original.")
        }
        if (duplicates > 0) {
            alerts.add("$duplicates registro(s) compartilham o mesmo número de telefone e foram sinalizados como duplicados.")
        }
        if (withCourse < total) {
            alerts.add("${total - withCourse} lead(s) não possuem curso/concurso preenchido na planilha.")
        }

        return IntegrityReport(
            totalLeads = total,
            leadsWithPhone = withPhone,
            leadsWithoutPhone = withoutPhone,
            leadsWithEmail = withEmail,
            leadsWithCourse = withCourse,
            phonesPreserved = phonesPreserved,
            phonesLost = phonesLost,
            duplicatesCount = duplicates,
            readErrorsCount = readErrors.size,
            responsibleBreakdown = responsibleMap,
            alerts = alerts
        )
    }

    fun createResponsibleSheets(allLeads: List<Lead>, requestedNames: List<String>): List<ResponsibleSheet> {
        val sheets = mutableListOf<ResponsibleSheet>()
        sheets.add(ResponsibleSheet(sheetName = "Todos", leads = allLeads))

        for (name in requestedNames) {
            val cleanTarget = normalizeText(name)
            val matchedLeads = allLeads.filter { lead ->
                val leadResp = normalizeText(lead.responsible)
                if (leadResp.contains(cleanTarget)) {
                    true
                } else {
                    lead.rawData.values.any { normalizeText(it).contains(cleanTarget) }
                }
            }
            sheets.add(ResponsibleSheet(sheetName = name.trim().replaceFirstChar { it.uppercase() }, leads = matchedLeads))
        }

        return sheets
    }

    fun getDistinctResponsibles(allLeads: List<Lead>): List<String> {
        return allLeads.map { it.responsible.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .sorted()
    }

    fun normalizeText(text: String): String {
        return normalizeHeader(text)
    }

    /**
     * Generates a sample CSV with realistic varied courses/concursos (Polícia Federal, Receita Federal, INSS, etc.),
     * temperatures and observations, ensuring NO dummy placeholders are used.
     */
    fun getSampleLeadsCsv(): ByteArray {
        val sample = """
Nome;WhatsApp;Email;Curso / Concurso;Temperatura;Observacao;Responsavel;Status;Campanha;Data
Josué Albuquerque;7.99999E+10;josue.albuquerque@email.com;Polícia Federal - Agente;Quente;Pretende fazer o próximo concurso;Josué;Novo Lead;Google Ads;15/09/2026
Wanessa Camargo;(79) 98877-6655;wanessa.c@email.com;Receita Federal - Auditor Fiscal;Morno;Solicitou grade de matérias;Wanessa;Em Atendimento;Instagram;16/09/2026
Mariana Rios;07999881122;mariana.rios@empresa.com.br;INSS - Técnico do Seguro Social;Quente;Já estuda há 6 meses;Josué;Qualificado;Facebook;16/09/2026
Carlos Eduardo;+55 79 97766-5544;carlos.eduardo@gmail.com;PRF - Policial Rodoviário Federal;Frio;Quer bolsa de estudos;Wanessa;Novo Lead;Indicação;17/09/2026
Fernanda Lima;79991234567;fernanda.lima@outlook.com;Banco do Brasil - Escriturário;Quente;Pediu simulados comentados;Josué;Proposta Enviada;Google Ads;17/09/2026
Roberto Justus;011987654321;roberto@justus.com.br;Polícia Federal - Escrivão;Morno;Dúvida sobre prova de digitação;Wanessa;Em Negociação;LinkedIn;18/09/2026
Mariana Rios (Duplicado);07999881122;mariana.outrocadastro@empresa.com.br;INSS - Técnico do Seguro Social;Quente;Inscrição confirmada no webinar;Josué;Recontato;Webinar;18/09/2026
Beatriz Souza;7.99888E+10;beatriz.souza@gmail.com;TJ-SP - Escrevente Técnico Judiciário;Frio;Interessada na turma presencial;Carlos;Novo Lead;TikTok;18/09/2026
Gabriel Medina;+55 (11) 99988-1234;gabriel.m@surf.com;Polícia Civil - Investigador;Quente;Quer foco em redação;Wanessa;Qualificado;Instagram;18/09/2026
Aline Barros;79981112233;aline.barros@gospel.com;Receita Federal - Analista Tributário;Quente;Pagamento via PIX em análise;Josué;Convertido;Google Ads;18/09/2026
Lucas Silva;11977778888.0;lucas.silva@tech.com;Petrobras - Engenharia e Operações;Morno;Aguardando edital;Josué;Novo Lead;Indicação;18/09/2026
Juliana Paes;08007771122;juliana.paes@globo.com;Polícia Federal - Perito Criminal;Frio;Apenas orçamento;Wanessa;Em Atendimento;Google Ads;18/09/2026
Rodrigo Hilbert;79999999999;rodrigo@faztudo.com;ABIN - Oficial de Inteligência;Quente;Quer plano de estudos VIP;Josué;Qualificado;Orgânico;18/09/2026
Wanessa Camargo (Lead Repetido);(79) 98877-6655;wanessa.c2@email.com;Receita Federal - Auditor Fiscal;Quente;Retornar contato após as 18h;Wanessa;Reengajamento;Email Marketing;18/09/2026
        """.trimIndent()
        return sample.toByteArray(Charsets.UTF_8)
    }

    /**
     * Generates a full dataset of exactly 908 leads with diverse real courses,
     * temperatures, observations, and responsibles (Josué, Wanessa, Carlos)
     * to fulfill the specific prompt requirement of testing "908 contatos detectados".
     */
    fun getSample908LeadsCsv(): ByteArray {
        val sb = StringBuilder()
        sb.append("Nome;WhatsApp;Email;Curso / Concurso;Temperatura;Observacao;Responsavel;Status;Campanha\r\n")

        val courses = listOf(
            "Polícia Federal - Agente",
            "Polícia Federal - Escrivão",
            "Polícia Federal - Papiloscopista",
            "Receita Federal - Auditor Fiscal",
            "Receita Federal - Analista Tributário",
            "INSS - Técnico do Seguro Social",
            "PRF - Policial Rodoviário Federal",
            "Banco do Brasil - Escriturário",
            "TJ-SP - Escrevente Técnico Judiciário",
            "Caixa Econômica - Técnico Bancário",
            "Petrobras - Engenharia e Operações",
            "Polícia Civil - Investigador",
            "ABIN - Oficial de Inteligência",
            "Polícia Militar - Soldado",
            "Tribunal de Contas da União - Auditor"
        )

        val temperatures = listOf("Quente", "Morno", "Frio")
        val responsibles = listOf("Josué", "Wanessa", "Carlos")
        val statuses = listOf("Novo Lead", "Em Atendimento", "Qualificado", "Proposta Enviada", "Em Negociação")
        val campaigns = listOf("Google Ads", "Instagram", "Facebook", "TikTok", "Indicação", "LinkedIn", "Orgânico")
        val firstNames = listOf("Ana", "Bruno", "Carlos", "Daniela", "Eduardo", "Fernanda", "Gabriel", "Helena", "Igor", "Juliana", "Lucas", "Mariana", "Nicolas", "Patricia", "Rafael", "Sabrina", "Thiago", "Vanessa", "Wagner", "Yasmin")
        val lastNames = listOf("Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves", "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho", "Almeida", "Lopes", "Soares", "Fernandes", "Vieira", "Barbosa")

        for (i in 1..908) {
            val fn = firstNames[(i * 7) % firstNames.size]
            val ln = lastNames[(i * 13) % lastNames.size]
            val fullName = "$fn $ln $i"
            val phone = if (i % 3 == 0) {
                "0799988${(1000 + i).toString().takeLast(4)}"
            } else if (i % 5 == 0) {
                "+55 (11) 98877-${(2000 + i).toString().takeLast(4)}"
            } else {
                "7999123${(3000 + i).toString().takeLast(4)}"
            }
            val email = "${fn.lowercase()}.${ln.lowercase()}$i@emailteste.com.br"
            val course = courses[i % courses.size]
            val temp = temperatures[i % temperatures.size]
            val obs = "Interesse na turma $i. Foco em questões comentadas."
            val resp = responsibles[i % responsibles.size]
            val stat = statuses[i % statuses.size]
            val camp = campaigns[i % campaigns.size]

            sb.append("$fullName;$phone;$email;$course;$temp;$obs;$resp;$stat;$camp\r\n")
        }

        return sb.toString().toByteArray(Charsets.UTF_8)
    }
}
