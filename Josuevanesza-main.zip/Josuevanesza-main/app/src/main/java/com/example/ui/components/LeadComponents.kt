package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ExportValidationResult
import com.example.data.model.FileParseResult
import com.example.data.model.IntegrityReport
import com.example.data.model.Lead

val PrimaryNavy = Color(0xFF0B2545)
val AccentTeal = Color(0xFF134074)
val SuccessGreen = Color(0xFF0F9D58)
val WarningAmber = Color(0xFFD97706)
val DangerRed = Color(0xFFDC2626)
val SurfaceLight = Color(0xFFF8FAFC)
val CardBorder = Color(0xFFE2E8F0)
val CourseBlue = Color(0xFF0369A1)
val CourseBg = Color(0xFFE0F2FE)

@Composable
fun LeadCard(
    lead: Lead,
    modifier: Modifier = Modifier,
    onMoveObservationToCourse: ((leadId: String) -> Unit)? = null
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .testTag("lead_card_${lead.originalRowIndex}")
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(
            width = if (lead.isDuplicate) 1.5.dp else 1.dp,
            color = if (lead.isDuplicate) WarningAmber.copy(alpha = 0.7f) else CardBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Row index, Name, Status & Duplicate Flag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(PrimaryNavy.copy(alpha = 0.1f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "#${lead.originalRowIndex}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryNavy
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = lead.name.ifBlank { "Sem Nome" },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF1E293B)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (lead.isDuplicate) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(WarningAmber.copy(alpha = 0.15f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Duplicado (${lead.duplicateCount}x)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarningAmber
                            )
                        }
                    }

                    if (lead.status.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFEEF2F6))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = lead.status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF475569)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Phone Section — HIGHEST PRIORITY
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = if (lead.hasPhone) Color(0xFFF0FDF4) else Color(0xFFFEF2F2),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (lead.hasPhone) SuccessGreen.copy(alpha = 0.3f) else DangerRed.copy(alpha = 0.3f)
                )
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (lead.hasPhone) Icons.Default.Phone else Icons.Default.PhoneMissed,
                            contentDescription = "Telefone",
                            tint = if (lead.hasPhone) SuccessGreen else DangerRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "WHATSAPP / TELEFONE (ORIGINAL)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (lead.hasPhone) Color(0xFF166534) else DangerRed
                            )
                            Text(
                                text = if (lead.hasPhone) lead.originalPhone else "SEM TELEFONE NO ARQUIVO ORIGINAL",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (lead.hasPhone) Color(0xFF0F172A) else DangerRed,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    if (lead.hasPhone && lead.normalizedPhone != lead.originalPhone) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Normalizado: ",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                            Text(
                                text = lead.normalizedPhone,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1E293B),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Curso / Concurso Section
            if (lead.course.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    color = CourseBg,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CourseBlue.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = "Curso",
                            tint = CourseBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "CURSO / CONCURSO",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = CourseBlue
                            )
                            Text(
                                text = lead.course,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0C4A6E)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Temperature, Observations, Email & Responsible
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (lead.email.isNotBlank()) {
                    Row(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = "Email",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = lead.email,
                            fontSize = 12.sp,
                            color = Color(0xFF334155)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (lead.temperature.isNotBlank()) {
                        val tempColor = when (lead.temperature.lowercase()) {
                            "quente", "alta" -> DangerRed
                            "morno", "media", "média" -> WarningAmber
                            else -> CourseBlue
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(tempColor.copy(alpha = 0.12f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Temp: ${lead.temperature}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = tempColor
                            )
                        }
                    }

                    if (lead.responsible.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AccentTeal.copy(alpha = 0.12f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Resp: ${lead.responsible}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentTeal
                            )
                        }
                    }
                }
            }

            if (lead.observation.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notes,
                            contentDescription = "Observação",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Obs: ${lead.observation}",
                            fontSize = 11.5.sp,
                            color = Color(0xFF475569)
                        )
                    }

                    if (lead.course.isBlank() && onMoveObservationToCourse != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(
                            onClick = { onMoveObservationToCourse(lead.id) },
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CourseBlue),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CourseBlue),
                            modifier = Modifier.testTag("btn_move_obs_to_course_${lead.originalRowIndex}")
                        ) {
                            Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Mover p/ Curso", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Expanded view: Shows all original raw columns
            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(color = CardBorder)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "TODAS AS COLUNAS ORIGINAIS (INTEGRIDADE 100%):",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    lead.rawData.forEach { (col, value) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = "$col: ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF64748B),
                                modifier = Modifier.widthIn(min = 90.dp)
                            )
                            Text(
                                text = value.ifBlank { "(vazio)" },
                                fontSize = 11.sp,
                                color = if (value.isBlank()) Color(0xFF94A3B8) else Color(0xFF0F172A),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Pre-Import Validation Dialog showing:
 * 1. "X contatos detectados"
 * 2. Original vs Parsed comparison metrics: Nome, Telefone, E-mail, Curso/Concurso, etc.
 * 3. Inspection table: Nome | WhatsApp | E-mail | Curso/Concurso | Temperatura | Observação
 * 4. Action button: "Confirmar e Importar X Leads"
 */
@Composable
fun PreImportConfirmationDialog(
    parseResult: FileParseResult,
    onConfirmImport: () -> Unit,
    onCancel: () -> Unit,
    onUpdateMapping: ((courseCol: String?, obsCol: String?) -> Unit)? = null
) {
    val totalLeads = parseResult.leads.size
    val validation = parseResult.validationComparison
    val horizontalScrollState = rememberScrollState()

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(PrimaryNavy.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FactCheck,
                                contentDescription = null,
                                tint = PrimaryNavy,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Importador Inteligente de Planilhas",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp,
                                color = PrimaryNavy
                            )
                            Text(
                                text = "Validação de Mapeamento & Conferência • ${parseResult.fileName}",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    // Badge: "X contatos detectados"
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFFDCFCE7),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "$totalLeads contatos detectados",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF166534),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Column Mapping Validation Card (Validação de Mapeamento de Colunas)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (parseResult.hasMappingConflict) Color(0xFFFEF2F2) else Color(0xFFF8FAFC)
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (parseResult.hasMappingConflict) DangerRed else CardBorder
                    )
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "VALIDAÇÃO DO MAPEAMENTO DE COLUNAS:",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (parseResult.hasMappingConflict) DangerRed else PrimaryNavy
                            )
                            if (parseResult.hasMappingConflict) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = DangerRed
                                ) {
                                    Text(
                                        text = "BLOQUEADO POR CONFLITO",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        if (parseResult.hasMappingConflict && parseResult.mappingConflictMessage != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "⚠️ ${parseResult.mappingConflictMessage}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DangerRed
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Column mapping list: Cabeçalho original → Campo do sistema → Quantidade de valores
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (parseResult.columnMappings.isEmpty()) {
                                Text(
                                    text = "Nenhuma coluna mapeada automaticamente.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            } else {
                                for (mapping in parseResult.columnMappings) {
                                    val isCourse = mapping.targetField.contains("Curso")
                                    val isObs = mapping.targetField.contains("Observação")
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color.White,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            when {
                                                isCourse -> CourseBlue.copy(alpha = 0.5f)
                                                isObs -> Color(0xFF0D9488).copy(alpha = 0.5f)
                                                else -> CardBorder
                                            }
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = mapping.originalHeader,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = Color(0xFF334155)
                                            )
                                            Text(
                                                text = " → ",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.sp,
                                                color = PrimaryNavy
                                            )
                                            Text(
                                                text = mapping.targetField,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.sp,
                                                color = when {
                                                    isCourse -> CourseBlue
                                                    isObs -> Color(0xFF0D9488)
                                                    else -> PrimaryNavy
                                                }
                                            )
                                            Text(
                                                text = " → ${mapping.filledCount} valores",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 10.5.sp,
                                                color = Color(0xFF166534)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Interactive Column Selection & Quick Invert Option
                        if (onUpdateMapping != null && parseResult.headers.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = CardBorder.copy(alpha = 0.8f))
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "CORREÇÃO / AJUSTE DE COLUNAS:",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PrimaryNavy
                                )

                                val currentCourse = parseResult.courseColumnName
                                val currentObs = parseResult.observationColumnName

                                if (currentCourse != null || currentObs != null) {
                                    TextButton(
                                        onClick = {
                                            onUpdateMapping(currentObs ?: "__NONE__", currentCourse ?: "__NONE__")
                                        },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SwapHoriz,
                                            contentDescription = null,
                                            tint = CourseBlue,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Inverter Curso ⇄ Observação",
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CourseBlue
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                ColumnSelectorDropdown(
                                    label = "Coluna para Curso / Concurso:",
                                    selectedColumn = parseResult.courseColumnName,
                                    availableHeaders = parseResult.headers,
                                    modifier = Modifier.weight(1f),
                                    onSelect = { selected ->
                                        onUpdateMapping(selected, parseResult.observationColumnName)
                                    }
                                )
                                ColumnSelectorDropdown(
                                    label = "Coluna para Observação:",
                                    selectedColumn = parseResult.observationColumnName,
                                    availableHeaders = parseResult.headers,
                                    modifier = Modifier.weight(1f),
                                    onSelect = { selected ->
                                        onUpdateMapping(parseResult.courseColumnName, selected)
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Comparison Cards: Arquivo Original x Dados Importados
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "COMPARAÇÃO: ARQUIVO ORIGINAL × DADOS IMPORTADOS",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = PrimaryNavy
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricBox(
                                label = "Nome",
                                count = validation?.leadsWithDetectedName ?: parseResult.leads.count { it.hasName },
                                total = totalLeads,
                                modifier = Modifier.weight(1f)
                            )
                            MetricBox(
                                label = "WhatsApp",
                                count = validation?.leadsWithDetectedPhone ?: parseResult.leads.count { it.hasPhone },
                                total = totalLeads,
                                modifier = Modifier.weight(1f),
                                highlightSuccess = true
                            )
                            MetricBox(
                                label = "E-mail",
                                count = validation?.leadsWithDetectedEmail ?: parseResult.leads.count { it.hasEmail },
                                total = totalLeads,
                                modifier = Modifier.weight(1f)
                            )
                            MetricBox(
                                label = "Curso/Concurso",
                                count = validation?.leadsWithDetectedCourse ?: parseResult.leads.count { it.hasCourse },
                                total = totalLeads,
                                modifier = Modifier.weight(1f),
                                highlightSuccess = true
                            )
                        }

                        if (parseResult.courseColumnName != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "✓ Coluna de Curso: '${parseResult.courseColumnName}' mapeada com sucesso (valores reais da planilha).",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF166534)
                            )
                        }
                        if (parseResult.observationColumnName != null) {
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "✓ Coluna de Observação: '${parseResult.observationColumnName}' mapeada independentemente (sem mesclagem com curso).",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF0D9488)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Table Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Conferência Visual dos Campos (Role para conferir):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "Mostrando registros",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Inspection Table: Nome | WhatsApp | E-mail | Curso/Concurso | Temperatura | Observação
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .horizontalScroll(horizontalScrollState)
                        ) {
                            // Table Header Row
                            Row(
                                modifier = Modifier
                                    .background(PrimaryNavy)
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TableCellHeader(text = "#", width = 45.dp)
                                TableCellHeader(text = "Nome", width = 160.dp)
                                TableCellHeader(text = "WhatsApp", width = 145.dp)
                                TableCellHeader(text = "E-mail", width = 170.dp)
                                TableCellHeader(text = "Curso/Concurso", width = 210.dp)
                                TableCellHeader(text = "Temperatura", width = 110.dp)
                                TableCellHeader(text = "Observação", width = 220.dp)
                            }

                            // Table Rows
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                items(parseResult.leads) { lead ->
                                    val rowBg = if (lead.originalRowIndex % 2 == 0) SurfaceLight else Color.White
                                    Row(
                                        modifier = Modifier
                                            .background(rowBg)
                                            .padding(vertical = 6.dp, horizontal = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TableCell(text = "${lead.originalRowIndex}", width = 45.dp, isBold = true)
                                        TableCell(text = lead.name.ifBlank { "—" }, width = 160.dp)
                                        TableCell(
                                            text = if (lead.hasPhone) lead.originalPhone else "—",
                                            width = 145.dp,
                                            textColor = if (lead.hasPhone) Color(0xFF166534) else DangerRed,
                                            isMonospace = true
                                        )
                                        TableCell(text = lead.email.ifBlank { "—" }, width = 170.dp)
                                        TableCell(
                                            text = lead.course.ifBlank { "—" },
                                            width = 210.dp,
                                            textColor = if (lead.course.isNotBlank()) CourseBlue else Color(0xFF94A3B8),
                                            isBold = lead.course.isNotBlank()
                                        )
                                        TableCell(text = lead.temperature.ifBlank { "—" }, width = 110.dp)
                                        TableCell(text = lead.observation.ifBlank { "—" }, width = 220.dp)
                                    }
                                    HorizontalDivider(color = Color(0xFFF1F5F9))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.testTag("btn_cancel_import")
                    ) {
                        Text("Cancelar")
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = onConfirmImport,
                        enabled = !parseResult.hasMappingConflict,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuccessGreen,
                            disabledContainerColor = Color(0xFFCBD5E1)
                        ),
                        modifier = Modifier.testTag("btn_confirm_import")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Confirmar e Importar $totalLeads Leads",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(
    label: String,
    count: Int,
    total: Int,
    modifier: Modifier = Modifier,
    highlightSuccess: Boolean = false
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            Text(text = label, fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
            Text(
                text = "$count",
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (highlightSuccess && count > 0) Color(0xFF166534) else PrimaryNavy
            )
            val pct = if (total > 0) (count * 100) / total else 0
            Text(text = "$pct% preenchido", fontSize = 9.sp, color = Color(0xFF94A3B8))
        }
    }
}

@Composable
private fun TableCellHeader(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 6.dp)
    )
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    textColor: Color = Color(0xFF1E293B),
    isBold: Boolean = false,
    isMonospace: Boolean = false
) {
    Text(
        text = text,
        fontSize = 11.sp,
        fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
        fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
        color = textColor,
        maxLines = 1,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 6.dp)
    )
}

@Composable
fun IntegrityReportDialog(
    report: IntegrityReport,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RELATÓRIO DE INTEGRIDADE",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Conferência matemática e estrutural do arquivo de leads:",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                ReportMetricItem(label = "TOTAL DE LEADS:", value = "${report.totalLeads}")
                ReportMetricItem(label = "LEADS COM TELEFONE:", value = "${report.leadsWithPhone}", isSuccess = true)
                ReportMetricItem(label = "LEADS SEM TELEFONE:", value = "${report.leadsWithoutPhone}")
                ReportMetricItem(label = "LEADS COM E-MAIL:", value = "${report.leadsWithEmail}")
                ReportMetricItem(label = "LEADS COM CURSO/CONCURSO:", value = "${report.leadsWithCourse}", isSuccess = true)
                ReportMetricItem(label = "TELEFONES PRESERVADOS:", value = "${report.phonesPreserved}", isSuccess = true)
                ReportMetricItem(
                    label = "TELEFONES PERDIDOS:",
                    value = "${report.phonesLost}",
                    isSuccess = report.phonesLost == 0,
                    isDanger = report.phonesLost > 0
                )
                ReportMetricItem(label = "DUPLICADOS:", value = "${report.duplicatesCount} (Mantidos)")
                ReportMetricItem(
                    label = "ERROS DE LEITURA:",
                    value = "${report.readErrorsCount}",
                    isSuccess = report.readErrorsCount == 0,
                    isDanger = report.readErrorsCount > 0
                )

                if (report.responsibleBreakdown.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "LEADS POR RESPONSÁVEL:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryNavy
                    )
                    report.responsibleBreakdown.forEach { (resp, count) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 1.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "• $resp", fontSize = 12.sp, color = Color(0xFF334155))
                            Text(text = "$count leads", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryNavy)
            ) {
                Text("Fechar Relatório")
            }
        }
    )
}

@Composable
fun PreExportValidationDialog(
    validation: ExportValidationResult,
    onConfirmExport: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedFormat by remember { mutableStateOf("XLS") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Rule,
                    contentDescription = null,
                    tint = if (validation.canExport) SuccessGreen else DangerRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "VALIDAÇÃO PRÉ-EXPORTAÇÃO",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Comparação obrigatória antes de gerar o arquivo final:",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceLight)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        ComparisonRow(
                            label = "Quantidade de leads:",
                            inVal = "${validation.inputLeadsCount}",
                            outVal = "${validation.outputLeadsCount}",
                            isMatch = validation.inputLeadsCount == validation.outputLeadsCount
                        )
                        ComparisonRow(
                            label = "Telefones preenchidos:",
                            inVal = "${validation.inputPhonesCount}",
                            outVal = "${validation.outputPhonesCount}",
                            isMatch = validation.inputPhonesCount == validation.outputPhonesCount
                        )
                        ComparisonRow(
                            label = "Cursos preenchidos:",
                            inVal = "Total preservado",
                            outVal = "${validation.lostCourses} perdidos",
                            isMatch = validation.lostCourses == 0
                        )
                        ComparisonRow(
                            label = "Telefones perdidos:",
                            inVal = "0 esperado",
                            outVal = "${validation.lostPhones}",
                            isMatch = validation.lostPhones == 0
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Escolha o formato de saída seguro:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryNavy
                )

                Row(modifier = Modifier.padding(top = 6.dp)) {
                    FilterChip(
                        selected = selectedFormat == "XLS",
                        onClick = { selectedFormat = "XLS" },
                        label = { Text("Excel Multi-Abas (.xls)", fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = selectedFormat == "CSV",
                        onClick = { selectedFormat = "CSV" },
                        label = { Text("CSV Seguro (;)", fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                Text(
                    text = if (selectedFormat == "XLS") {
                        "✓ Gera abas automáticas para cada responsável + aba 'Todos'. Células com tipo texto estrito (zero perda de DDD e zeros à esquerda)."
                    } else {
                        "✓ CSV com BOM UTF-8 e proteção de texto para evitar conversão decimal ou notação científica no Excel."
                    },
                    fontSize = 11.sp,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmExport(selectedFormat) },
                enabled = validation.canExport,
                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
            ) {
                Text("Exportar sem Perdas")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
fun ValidationBlockerDialog(
    validation: ExportValidationResult,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = DangerRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "EXPORTAÇÃO BLOQUEADA",
                    fontWeight = FontWeight.ExtraBold,
                    color = DangerRed,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "A regra de integridade estrita impediu a exportação porque divergências foram detectadas:",
                    fontSize = 12.sp,
                    color = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(8.dp))
                for (reason in validation.blockerReasons) {
                    Text(
                        text = "• $reason",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DangerRed,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
            ) {
                Text("Corrigir Dados")
            }
        }
    )
}

@Composable
private fun ReportMetricItem(
    label: String,
    value: String,
    isSuccess: Boolean = false,
    isDanger: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF334155)
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = when {
                isDanger -> DangerRed
                isSuccess -> SuccessGreen
                else -> PrimaryNavy
            },
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun ComparisonRow(
    label: String,
    inVal: String,
    outVal: String,
    isMatch: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.5.sp, color = Color(0xFF475569))
        Row {
            Text(text = "Entrada: $inVal", fontSize = 11.5.sp, color = Color(0xFF64748B))
            Text(text = "  →  ", fontSize = 11.5.sp, color = Color(0xFF94A3B8))
            Text(
                text = "Saída: $outVal",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (isMatch) SuccessGreen else DangerRed
            )
        }
    }
}

@Composable
fun ColumnSelectorDropdown(
    label: String,
    selectedColumn: String?,
    availableHeaders: List<String>,
    modifier: Modifier = Modifier,
    onSelect: (String?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column(modifier = modifier) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF475569)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Box {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = true },
                shape = RoundedCornerShape(6.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = selectedColumn ?: "(Nenhuma)",
                        fontSize = 11.sp,
                        fontWeight = if (selectedColumn != null) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedColumn != null) PrimaryNavy else Color(0xFF94A3B8),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("(Nenhuma)", fontSize = 12.sp, color = Color(0xFF94A3B8)) },
                    onClick = {
                        expanded = false
                        onSelect("__NONE__")
                    }
                )
                availableHeaders.forEach { header ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = header,
                                fontSize = 12.sp,
                                fontWeight = if (header == selectedColumn) FontWeight.Bold else FontWeight.Normal,
                                color = if (header == selectedColumn) CourseBlue else Color(0xFF1E293B)
                            )
                        },
                        onClick = {
                            expanded = false
                            onSelect(header)
                        }
                    )
                }
            }
        }
    }
}

