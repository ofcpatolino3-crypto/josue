package com.example.data.repository

import com.example.data.model.*

object Parte14EstrategiaProvaData {
    fun getChapter(): EBookChapter {
        return EBookChapter(
            id = "part14_estrategia_prova",
            partId = "part_14",
            partNumber = 14,
            partTitle = "PARTE 14 — ESTRATÉGIA FINAL DE PROVA & MENTALIDADE VENCEDORA",
            chapterNumber = 1,
            title = "A Estratégia Definitiva para o Dia da Prova e os Próximos Passos",
            subtitle = "Controle Emocional, Roteiro Minuto a Minuto, Interposição de Recursos e Etapas de Admissão",
            readTimeMinutes = 20,
            strategicSummary = "Tudo o que você precisa saber para transformar meses de preparação em uma vaga efetiva na maior subsidiária de logística de combustíveis da América Latina.",
            highYieldAlerts = listOf(
                "O controle emocional no dia da prova representa até 30% da sua nota final.",
                "Não discuta gabaritos com outros candidatos na saída do prédio; espere a divulgação oficial da Cesgranrio.",
                "O Processo Seletivo Público da Transpetro inclui etapas posteriores eliminatórias: Exame Médico Admissional (ASO), comprovação de requisitos e Curso de Formação."
            ),
            examTraps = listOf(
                "Mudar respostas de última hora no cartão de respostas movido pelo desespero dos minutos finais.",
                "Deixar de conferir o prazo estrito de 2 dias úteis para interposição de recursos contra questões com duplicidade ou erro conceitual."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. O Protocolo das 4 Horas de Prova",
                    body = """No momento em que o fiscal autorizar o início da prova:

1. Minuto 00 ao 03 (Calibração Mental):
• Respire profundamente 3 vezes (inspire em 4 segundos, segure em 4, expire em 6).
• Folheie o caderno de prova rapidamente para verificar se não há páginas em branco ou defeitos de impressão.

2. A Sequência Vencedora de Resolução:
• Passo 1: Língua Portuguesa (Questões 1 a 10). Mantenha a atenção plena na interpretação dos textos de apoio.
• Passo 2: Conhecimentos Específicos (Questões 21 a 60). Resolva em primeira passada todas as questões conceituais diretas sobre as quais você tem certeza imediata.
• Passo 3: Matemática (Questões 11 a 20). Faça os cálculos em espaço limpo no rascunho com letras legíveis.
• Passo 4: Segunda Passada nas Questões Marcadas com Dúvida.
• Passo 5: Preenchimento do Cartão-Resposta com 20 minutos de folga. Cubra totalmente a bolha com a caneta sem amassar a folha.""",
                    bulletPoints = listOf(
                        "Durante a prova, faça pausas estratégicas de 30 segundos a cada 50 minutos: feche os olhos, alongue o pescoço e beba um gole de água.",
                        "Se uma questão for excessivamente longa e complexa, circule o número e avance; não queime seu tempo precioso.",
                        "Mantenha o foco absoluto na sua prova; ignore o ritmo ou a velocidade dos outros candidatos."
                    )
                ),
                ContentSection(
                    title = "2. Pós-Prova, Recursos e Etapas de Contratação na Transpetro",
                    body = """Após a realização da prova objetiva:

• Divulgação do Gabarito Preliminar: Geralmente ocorre no primeiro dia útil subsequente no portal da Fundação Cesgranrio.
• Interposição de Recursos:
  - Seja técnico, objetivo e respeitoso.
  - Cite a bibliografia oficial e normas técnicas (ex: ABNT NBR 17505, API 650, Portarias da ANP, Gramática Tradicional).
  - Nunca copie recursos prontos de terceiros; a banca anula recursos com texto idêntico.

Etapas Após a Homologação do Concurso:
1. Convocação dos Aprovados: Acompanhe o Diário Oficial da União (DOU) e o site oficial da Transpetro.
2. Qualificação Biopsicossocial e Exames Médicos Admissionais: Avaliação médica rigorosa para aptidão em trabalho em área industrial (NR-20, trabalho em altura NR-35 e espaço confinado NR-33).
3. Apresentação de Documentos Comprobatórios de Escolaridade (Diploma de Nível Médio / Registro no respectivo Conselho de Classe CFT/CRQ quando aplicável).
4. Integração Corporativa e Curso de Formação: Início da jornada profissional com remuneração e pacote completo de benefícios da Transpetro.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "MENSAGEM FINAL: O SUCESSO É O RESULTADO DA SUA CONSTÂNCIA",
                            content = "Você tem em mãos o material mais completo, didático e estratégico já produzido para o PSP Transpetro 2026. Revise com dedicação, confie na sua jornada e conquiste a sua vaga!",
                            iconType = "LAW"
                        )
                    )
                )
            )
        )
    }
}
