package com.example.data.repository

import com.example.data.model.*

object Parte12RevisaoTurboData {
    fun getChapter(): EBookChapter {
        return EBookChapter(
            id = "part12_revisao_turbo",
            partId = "part_12",
            partNumber = 12,
            partTitle = "PARTE 12 — REVISÃO TURBO TRANSPETRO & CONCEITOS DE OURO",
            chapterNumber = 1,
            title = "Revisão Turbo de Véspera e os 100 Conceitos Mais Cobrados",
            subtitle = "Resumo Ultraconcentrado, Fórmulas em Tabelas, Mnemônicos Infalíveis e Checklist Final",
            readTimeMinutes = 25,
            strategicSummary = "Compilado cirúrgico para as últimas 48 horas antes da prova, contendo apenas o que possui probabilidade estatística superior a 80% de aparecer no caderno de questões da Fundação Cesgranrio.",
            highYieldAlerts = listOf(
                "Revise os mnemônicos e as fórmulas fundamentais na véspera sem se sobrecarregar.",
                "Garanta uma boa noite de sono de pelo menos 7 a 8 horas antes do dia da prova.",
                "Verifique com antecedência o trajeto, transporte, local de prova e itens obrigatórios (caneta preta transparente e documento oficial com foto)."
            ),
            examTraps = listOf(
                "Tentar estudar matérias inéditas ou complexas na véspera (isso só gera ansiedade e insegurança).",
                "Chegar ao local de prova com menos de 1 hora de antecedência (os portões fecham rigorosamente no horário marcado!)."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Os 30 Conceitos de Ouro de Língua Portuguesa",
                    body = """1. CRASE PROIBIDA: Antes de masculino, verbo, pronome pessoal/indefinido, palavras repetidas e com 'A' no singular diante de plural ('a normas').
2. CRASE FACULTATIVA: Antes de nome de mulher, pronome possessivo feminino singular ('à minha equipe') e após a preposição 'até'.
3. HAVER IMPESSOAL: No sentido de existir ou tempo decorrido, 'haver' não tem sujeito e fica sempre na 3ª pessoa do singular ('Havia muitos relatórios').
4. FAZER TEMPORAL: 'Faz três anos' (nunca 'Fazem três anos').
5. VERBO + SE: VTD + SE = Voz Passiva Sintética (verbo concorda com o sujeito: 'Alugam-se tanques'). VTI + SE = Sujeito Indeterminado (verbo fica no singular: 'Precisa-se de operadores').
6. REGÊNCIA 'VISAR': No sentido de almejar/desejar, exige a preposição 'A' ('Visamos ao cargo').
7. REGÊNCIA 'ASSISTIR': No sentido de ver/presenciar, exige a preposição 'A' ('Assistimos ao treinamento').
8. CONECTIVOS ADVERSATIVOS: mas, porém, contudo, todavia, no entanto, entretanto (introduzem oposição).
9. CONECTIVOS CONCESSIVOS: embora, conquanto, ainda que, mesmo que, posto que, a despeito de (introduzem oposição mas não anulam a oração principal; exigem verbo no subjuntivo).
10. PRONOME RELATIVO 'CUJO': Indica posse; concorda com a coisa possuída; NUNCA aceita artigo após ele ('cujo o' NÃO EXISTE!).""",
                    bulletPoints = listOf(
                        "Diferença 'Ao encontro de' (a favor/concordância) vs. 'De encontro a' (choque/oposição).",
                        "Diferença 'A cerca de' (aproximadamente) vs. 'Acerca de' (sobre/a respeito) vs. 'Há cerca de' (tempo passado).",
                        "Uso dos Porquês: 'Por que' (pergunta/motivo pelo qual), 'Por quê' (fim de frase), 'Porque' (explicação/causa), 'O porquê' (substantivo/o motivo)."
                    )
                ),
                ContentSection(
                    title = "2. Os 30 Conceitos de Ouro de Matemática",
                    body = """1. GRAU °API: °API = (141,5 / d) - 131,5. Quanto MAIOR o °API, MAIS LEVE é o petróleo.
2. VOLUME DO CILINDRO (Tanque): V = π · r² · h. (1 m³ = 1.000 Litros).
3. AUMENTO PERCENTUAL: Multiplicar por (1 + i/100). (ex: +25% ⇒ × 1,25).
4. DESCONTO PERCENTUAL: Multiplicar por (1 - i/100). (ex: -15% ⇒ × 0,85).
5. AUMENTOS SUCESSIVOS: Fator Total = F1 × F2 × ... × Fn. (Nunca some porcentagens!).
6. JUROS SIMPLES: J = C · i · t e M = C · (1 + i · t).
7. JUROS COMPOSTOS: M = C · (1 + i)^t.
8. REGRA DE TRÊS INVERSA: Grandezas opostas multiplicam-se em LINHA RETA (ex: mais bombas = menos tempo).
9. ESCALA CARTOGRÁFICA: E = d / D (distância no mapa / distância real na mesma unidade).
10. MÉDIA PONDERADA: Multiplica valores pelos pesos e DIVIDE PELA SOMA DOS PESOS.""",
                    tables = listOf(
                        TableItem(
                            title = "Tabela Rápida de Conversões Fundamentais para a Prova",
                            headers = listOf("Grandeza", "Unidade de Partida", "Unidade de Destino", "Operação de Conversão"),
                            rows = listOf(
                                listOf("Volume", "1 m³", "Litros (L)", "Multiplicar por 1.000"),
                                listOf("Volume", "1 dm³", "Litros (L)", "1 dm³ = 1 Litro"),
                                listOf("Comprimento", "1 polegada (\")", "Milímetros (mm)", "1\" = 25,4 mm"),
                                listOf("Pressão", "1 bar", "Pascal (Pa) / kgf/cm²", "1 bar = 100.000 Pa ≈ 1,02 kgf/cm²"),
                                listOf("Pressão", "1 atm", "mmHg / psi", "1 atm = 760 mmHg ≈ 14,7 psi"),
                                listOf("Massa", "1 tonelada (t)", "Quilogramas (kg)", "Multiplicar por 1.000")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "3. Os 40 Conceitos de Ouro de Conhecimentos Específicos (Dutos, Mecânica, Admin)",
                    body = """1. VÁLVULA DE ESFERA FULL BORE: Passagem plena para passagem livre de PIGs.
2. VÁLVULA DE RETENÇÃO (Check): Impede o fluxo reverso automaticamente.
3. NPSH: Para não cavitar, NPSH disponível DEVE ser MAIOR que NPSH requerido (NPSH_d > NPSH_r).
4. BOMBAS EM SÉRIE: Somam as alturas manométricas (H_total = H1 + H2).
5. BOMBAS EM PARALELO: Somam as vazões (Q_total = Q1 + Q2).
6. TANQUES DE TETO FLUTUANTE: Obrigatórios para petróleo leve e gasolina (eliminam o espaço vapor).
7. PIG MFL: Magnetização para mapear corrosão e perda de espessura por fluxo magnético disperso.
8. GÁS INERTE EM NAVIOS (IGS): Teor de O₂ inferior a 8% em volume nos tanques de carga.
9. INCÊNDIO CLASSE B: Líquidos inflamáveis combatem-se com Espuma Mecânica (LGE) ou PQS. PROIBIDO jato pleno de água!
10. PROTEÇÃO CATÓDICA: Conecta a tubulação ao polo NEGATIVO para atuar como CÁTODO protegido (-850 mV vs. Cu/CuSO₄).
11. PARAFUSO CLASSE 8.8: Resistência à Tração = 800 MPa; Limite de Escoamento = 640 MPa.
12. PROCESSO TIG (GTAW): Eletrodo de tungstênio NÃO CONSUMÍVEL sob gás inerte; padrão para passe de raiz.
13. ELETRODO E7018: Eletrodo básico de baixo hidrogênio para soldagem em todas as posições com 70.000 psi de tração.
14. SURGE EM COMPRESSORES: Instabilidade em baixas vazões; combatido por válvula anti-surge.
15. CURVA ABC: Classe A representa ~20% dos itens e ~80% do valor monetário do estoque.
16. CLASSIFICAÇÃO XYZ: Itens Z são de alta criticidade operacional (sua falta paralisa a planta).
17. PEPS (FIFO): Saídas a custos antigos; estoque final avaliado a preços novos de mercado.
18. LEI DAS ESTATAIS (13.303/16): Inexigibilidade quando a competição for inviável (exclusividade).
19. LEI ANTICORRUPÇÃO (12.846/13): Responsabilidade civil e administrativa OBJETIVA da pessoa jurídica.
20. SEGURANÇA EM ESPAÇO CONFINADO (NR-33): Exige PET, vigia permanente e monitoramento contínuo da atmosfera.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "CHECKLIST FINAL DE VÉSPERA",
                            content = "• 2 ou mais canetas esferográficas transparentes de tinta preta ou azul.\n• Documento oficial original de identidade com foto em bom estado.\n• Cartão de Confirmação de Inscrição impresso com o endereço do local de prova.\n• Água em garrafa transparente sem rótulo e lanche leve (barra de cereal/frutas).\n• Mantenha a calma e confie em todo o conteúdo estudado!",
                            iconType = "ALERT"
                        )
                    )
                )
            )
        )
    }
}
