package com.example.data.repository

import com.example.data.model.*

object Parte7AdministracaoControleData {
    fun getChapters(): List<EBookChapter> {
        return listOf(
            createTeoriaGeralProcessosChapter(),
            createGestaoMateriaisEstoquesChapter(),
            createComprasContratosEstataisChapter(),
            createCustosOrcamentoControleChapter(),
            createGovernancaComplianceEticaChapter()
        )
    }

    private fun createTeoriaGeralProcessosChapter(): EBookChapter {
        return EBookChapter(
            id = "admin_cap_1",
            partId = "part_7",
            partNumber = 7,
            partTitle = "PARTE 7 — CONHECIMENTOS ESPECÍFICOS: ADMINISTRAÇÃO E CONTROLE",
            chapterNumber = 1,
            title = "Capítulo 1 — Teoria Geral da Administração, Funções Administrativas e Gestão de Processos",
            subtitle = "PODC (Planejar, Organizar, Dirigir, Controlar), Ciclo PDCA, Matriz GUT, Diagrama de Ishikawa e Metodologia 5S",
            readTimeMinutes = 22,
            strategicSummary = "As 4 funções administrativas essenciais, os 3 níveis de planejamento (Estratégico, Tático e Operacional), mapeamento de processos de negócios e ferramentas da qualidade.",
            highYieldAlerts = listOf(
                "Níveis de Planejamento: Estratégico (Longo Prazo, Alta Direção, Visão Global); Tático (Médio Prazo, Gerências, Unidades de Negócio); Operacional (Curto Prazo, Supervisores/Técnicos, Foco em Tarefas Diárias).",
                "Ciclo PDCA (Deming): Plan (Planejar), Do (Executar), Check (Verificar/Medir), Act/Adjust (Padronizar e Agir corretivamente).",
                "Matriz GUT: Priorização de problemas pelo produto Gravidade (G) × Urgência (U) × Tendência (T), variando de 1 a 5 cada nota."
            ),
            examTraps = listOf(
                "Confundir Eficácia com Eficiência: Eficiência é fazer as coisas certas gastando o mínimo de recursos (meios); Eficácia é atingir os objetivos e metas traçados (fins); Efetividade é gerar impacto transformador duradouro.",
                "Aplicar a ferramenta 5S como mero mutirão de limpeza. O 5S é uma filosofia de padronização, organização e disciplina comportamental contínua."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. As Quatro Funções Administrativas Clássicas (PODC)",
                    body = """A administração é o processo de tomar decisões e guiar recursos para alcançar objetivos organizacionais:

1. Planejar: Definir a missão, a visão, os objetivos futuros e os planos de ação necessários para atingi-los.
2. Organizar: Dividir o trabalho, agrupar atividades em órgãos/departamentos (departamentalização), alocar recursos e definir linhas de autoridade e responsabilidade.
3. Dirigir (Liderança): Conduzir, motivar, coordenar e comunicar com as pessoas para que executem as tarefas planejadas com alto engajamento.
4. Controlar: Monitorar o desempenho em tempo real, comparar os resultados com os padrões estabelecidos e adotar ações corretivas tempestivas.""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo dos Níveis de Planejamento Organizacional",
                            headers = listOf("Critério", "Planejamento Estratégico", "Planejamento Tático", "Planejamento Operacional"),
                            rows = listOf(
                                listOf("Nível Hierárquico", "Alta Administração (Diretoria/Conselho)", "Média Gerência (Chefias de Terminais)", "Nível Operacional (Supervisores e Técnicos)"),
                                listOf("Horizonte Temporal", "Longo Prazo (3 a 5 anos)", "Médio Prazo (1 a 2 anos)", "Curto Prazo (diário, semanal, mensal)"),
                                listOf("Abrangência", "Toda a corporação Transpetro", "Uma área ou departamento específico", "Uma tarefa, procedimento ou manobra específica"),
                                listOf("Grau de Incerteza", "Elevado (ambiente externo dinâmico)", "Moderado", "Baixo (rotinas e procedimentos padronizados)")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Ferramentas da Qualidade e Melhoria Contínua",
                    body = """Ferramentas aplicadas na rotina administrativa e operacional:
• Diagrama de Causa e Efeito (Espinha de Peixe / Ishikawa / 6M): Estrutura as causas-raiz de desvios em 6 categorias: Método, Máquina, Material, Mão de Obra, Meio Ambiente e Medição.
• Princípio de Pareto (Regra 80/20): 80% das consequências decorrem de 20% das causas vitais.
• Metodologia 5S (Sensos Japoneses):
  1. Seiri (Utilização/Descarte): Separar o que é útil do que é inútil.
  2. Seiton (Organização): Um lugar para cada coisa e cada coisa em seu lugar.
  3. Seiso (Limpeza): Não apenas limpar, mas eliminar as fontes de sujeira.
  4. Seiketsu (Padronização/Saúde): Manter as condições físicas e de higiene padronizadas.
  5. Shitsuke (Autodisciplina): Cumprir os padrões de forma natural e voluntária.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: MATRIZ GUT DE PRIORIZAÇÃO",
                            content = "Pontuação de 1 a 5 para Gravidade (impacto se não resolver), Urgência (tempo disponível para agir) e Tendência (potencial de agravamento com o tempo). Multiplica-se G × U × T (o problema com maior resultado numérico é o primeiro a ser tratado).",
                            iconType = "FORMULA"
                        )
                    )
                )
            ),
            questions = createAdminTopicQuestions(1, "Teoria Geral e Processos")
        )
    }

    private fun createGestaoMateriaisEstoquesChapter(): EBookChapter {
        return EBookChapter(
            id = "admin_cap_2",
            partId = "part_7",
            partNumber = 7,
            partTitle = "PARTE 7 — CONHECIMENTOS ESPECÍFICOS: ADMINISTRAÇÃO E CONTROLE",
            chapterNumber = 2,
            title = "Capítulo 2 — Gestão de Materiais, Controle de Estoques e Armazenagem",
            subtitle = "Curva ABC (Valor Monetário) e XYZ (Criticidade), Estoque de Segurança, Ponto de Pedido, PEPS, UEPS e Custo Médio",
            readTimeMinutes = 24,
            strategicSummary = "Classificação de sobressalentes e insumos, cálculo do Ponto de Pedido e Lote Econômico de Compra (LEC), métodos contábeis de valoração de estoque e inventários rotativos.",
            highYieldAlerts = listOf(
                "Curva ABC (Princípio de Pareto): Itens Classe A (~ 20% dos itens representam ~ 80% do valor monetário do estoque; exigem controle rigoroso diário); Classe B (~ 30% dos itens, ~ 15% do valor); Classe C (~ 50% dos itens, ~ 5% do valor).",
                "Classificação XYZ (Criticidade Operacional): Itens Z são vitais/críticos (a falta paralisa a operação do duto/terminal e não há substituto imediato).",
                "Método PEPS (Primeiro que Entra, Primeiro que Sai / FIFO): Os primeiros materiais adquiridos são os primeiros a serem requisitados; o estoque final fica avaliado pelos preços mais recentes (adotado pelo Fisco brasileiro e normas contábeis). O UEPS é proibido pela legislação fiscal brasileira."
            ),
            examTraps = listOf(
                "Achar que itens Classe C da curva ABC não precisam de controle: Se um item Classe C for também 'Classe Z' de criticidade (ex: um o-ring especial de R$ 5,00 da bomba principal), sua falta para uma refinaria inteira!",
                "Calcular o Ponto de Pedido sem somar o Estoque de Segurança."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Classificação de Materiais e Gestão de Inventários",
                    body = """A gestão de materiais visa garantir que os insumos e sobressalentes estejam disponíveis no local certo, no momento exato e com o menor custo financeiro possível:

1. Classificação por Valor e Criticidade:
• Curva ABC: Foco financeiro. Permite aplicar políticas diferenciadas de compras (itens A exigem negociações estratégicas de alto escalão).
• Classificação XYZ: Foco na continuidade operacional.
  - X (Baixa criticidade): Materiais comuns com facilidade de obtenção no mercado local.
  - Y (Média criticidade): Sobressalentes importantes, mas com fornecimento regular ou substitutos aceitáveis.
  - Z (Alta criticidade): Itens de segurança nacional ou peças sobressalentes de importação exclusiva cuja falta causa parada de produção e riscos ao meio ambiente.

2. Acurácia de Estoque e Inventários:
• Inventário Geral (Periódico): Realizado uma vez ao ano com paralisação das atividades do almoxarifado.
• Inventário Rotativo (Cíclico): Contagem física contínua e programada de determinados grupos de itens ao longo do ano, priorizando os itens Classe A e Z sem interromper as operações.""",
                    formulas = listOf(
                        FormulaItem(
                            name = "Fórmula do Ponto de Pedido (PP)",
                            expression = "PP = (C_m · TR) + ES",
                            variables = "PP: Ponto de Pedido; C_m: Consumo médio diário; TR: Tempo de Reposição (Lead Time em dias); ES: Estoque de Segurança.",
                            applicationTip = "Quando o saldo físico do estoque atingir o valor do PP, deve-se emitir imediatamente a Solicitação de Compras."
                        )
                    )
                ),
                ContentSection(
                    title = "2. Métodos de Avaliação e Valoração de Estoques",
                    body = """Métodos de Custeio de Saída de Materiais:
• PEPS (FIFO - First In, First Out): O custo das baixas é apurado pelo preço dos lotes mais antigos. Em períodos inflacionários, gera menor Custo das Mercadorias Vendidas (CMV), maior lucro contábil e estoque final supervalorizado a preços de mercado.
• UEPS (LIFO - Last In, First Out): As saídas são valoradas pelo preço dos lotes mais recentes. Gera maior CMV e menor lucro contábil (proibido pela legislação tributária brasileira).
• Custo Médio Ponderado Móvel (CMPM): A cada nova entrada de material com preço diferente, recalcula-se o custo médio unitário:
  Custo Médio = (Valor Total do Saldo Anterior + Valor da Nova Entrada) / Quantidade Total em Estoque.""",
                    tables = listOf(
                        TableItem(
                            title = "Comparativo dos Métodos de Valoração de Estoque",
                            headers = listOf("Método", "Avaliação do Estoque Final", "Custo do Material Consumido", "Aceitação Fiscal no Brasil"),
                            rows = listOf(
                                listOf("PEPS / FIFO", "Avaliado a preços recentes (maior)", "Avaliado a preços mais antigos (menor)", "Aceito plenamente (NBC TG / RIR)"),
                                listOf("UEPS / LIFO", "Avaliado a preços antigos (subavaliado)", "Avaliado a preços recentes (maior)", "NÃO aceito pelo Imposto de Renda"),
                                listOf("Média Ponderada", "Avaliado pela média móvel ponderada", "Avaliado pelo custo médio móvel", "Aceito plenamente (o mais utilizado)")
                            )
                        )
                    )
                )
            ),
            questions = createAdminTopicQuestions(2, "Gestão de Materiais")
        )
    }

    private fun createComprasContratosEstataisChapter(): EBookChapter {
        return EBookChapter(
            id = "admin_cap_3",
            partId = "part_7",
            partNumber = 7,
            partTitle = "PARTE 7 — CONHECIMENTOS ESPECÍFICOS: ADMINISTRAÇÃO E CONTROLE",
            chapterNumber = 3,
            title = "Capítulo 3 — Compras, Suprimentos, Contratos e Lei das Estatais (Lei 13.303/2016)",
            subtitle = "Regulamento de Licitações e Contratos da Petrobras/Transpetro (RLCP), Fiscalização Contratual, Aditivos e SLA",
            readTimeMinutes = 24,
            strategicSummary = "Processo de compras em sociedades de economia mista, procedimentos de licitação conforme a Lei 13.303/2016, dispensa e inexigibilidade, fiscalização técnica de contratos e aplicação de sanções.",
            highYieldAlerts = listOf(
                "A Transpetro, por ser sociedade de economia mista subsidiária, rege suas licitações e contratos pela Lei nº 13.303/2016 (Estatuto Jurídico das Estatais) e seu Regulamento Interno (RLCP), e não pela Lei 14.133/2021 geral.",
                "Inexigibilidade de Licitação: Ocorre quando há inviabilidade jurídica de competição (ex: fornecedor exclusivo comprovado, profissional de notória especialização técnica).",
                "Dispensa de Licitação: Há viabilidade de competição, mas a lei autoriza a contratação direta por conveniência administrativa (ex: baixo valor, emergência comprovada)."
            ),
            examTraps = listOf(
                "Confundir Inexigibilidade com Dispensa de Licitação. Inexigibilidade = Inviabilidade de competição; Dispensa = Competição possível, mas dispensada por lei.",
                "Fiscal do contrato assinar atestado de medição de serviço sem conferir in loco a entrega física efetiva e o cumprimento do SLA."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Diretrizes de Licitações e Contratos nas Estatais (Lei 13.303/2016)",
                    body = """Princípios Norteadores das Contratações da Transpetro:
• Impessoalidade, Moralidade, Igualdade, Publicidade, Eficiência, Probidade Administrativa, Desenvolvimento Nacional Sustentável e Vinculação ao Instrumento Convocatório.

Fases do Procedimento Licitatório na Lei das Estatais (Inversão de Fases como Regra):
1. Preparatória: Elaboração do Termo de Referência (TR) / Projeto Básico, estimativa de custos sigilosa ou pública e aprovação orçamentária.
2. Divulgação do Edital.
3. Apresentação de Lances ou Propostas.
4. Julgamento das Propostas (Critérios: Menor Preço, Maior Desconto, Melhor Combinação Técnica e Preço, Melhor Técnica, Melhor Retorno Econômico).
5. Habilitação: Aberta APENAS a documentação do licitante vencedor (garante agilidade ao processo!).
6. Fase Recursal Única.
7. Homologação e Adjudicação do Objeto.""",
                    tables = listOf(
                        TableItem(
                            title = "Diferenciação Prática: Inexigibilidade vs. Dispensa de Licitação",
                            headers = listOf("Critério", "Inexigibilidade (Art. 30 da Lei 13.303)", "Dispensa (Art. 29 da Lei 13.303)"),
                            rows = listOf(
                                listOf("Possibilidade de Competição", "Impossível / Inviável (ausência de concorrentes)", "Perfeitamente possível (existem múltiplos concorrentes)"),
                                listOf("Hipóteses Típicas", "Fornecedor ou fabricante exclusivo certificado; serviço técnico de notória especialização", "Pequeno valor (limites legais da estatal); emergência ou calamidade pública; licitação deserta"),
                                listOf("Rol Legal", "Rol Exemplificativo (meramente ilustrativo)", "Rol Taxativo (apenas o que está estritamente na lei)")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Fiscalização e Gestão de Contratos de Serviços",
                    body = """Papel do Fiscal Técnico e Administrativo do Contrato na Transpetro:
• Acompanhamento da Execução: Verificar se os prazos, especificações técnicas e materiais utilizados pela empresa contratada estão em conformidade com o edital.
• Acordo de Nível de Serviço (SLA / ANS): Indicadores objetivos de desempenho (ex: tempo de atendimento de chamados, taxa de disponibilidade de equipamentos) que geram glosas ou retenções financeiras no pagamento em caso de descumprimento.
• Fiscalização Trabalhista e Previdenciária: Conferir mensalmente o pagamento de salários, FGTS e INSS dos terceirizados para blindar a Transpetro contra responsabilidade subsidiária trabalhista (Súmula 331 do TST).
• Alterações Contratuais (Termos Aditivos): Devem respeitar os limites legais de acréscimos e supressões de até 25% (ou 50% para reformas) do valor inicial atualizado do contrato.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: RECEBIMENTO PROVISÓRIO E DEFINITIVO",
                            content = "O Recebimento Provisório é feito pelo fiscal do contrato logo após a entrega do serviço para efeito de posterior verificação de conformidade. O Recebimento Definitivo é feito por comissão ou autoridade competente após a comprovação cabal de que o objeto atende 100% aos requisitos contratuais.",
                            iconType = "LAW"
                        )
                    )
                )
            ),
            questions = createAdminTopicQuestions(3, "Compras e Contratos")
        )
    }

    private fun createCustosOrcamentoControleChapter(): EBookChapter {
        return EBookChapter(
            id = "admin_cap_4",
            partId = "part_7",
            partNumber = 7,
            partTitle = "PARTE 7 — CONHECIMENTOS ESPECÍFICOS: ADMINISTRAÇÃO E CONTROLE",
            chapterNumber = 4,
            title = "Capítulo 4 — Gestão de Custos, Noções de Orçamento e Controle Interno",
            subtitle = "Custos Diretos/Indiretos, Fixos/Variáveis, Ponto de Equilíbrio (PE), Orçamento Operacional e Matriz COSO",
            readTimeMinutes = 24,
            strategicSummary = "Classificação e apropriação de custos industriais, cálculo da Margem de Contribuição, Ponto de Equilíbrio Contábil, Financeiro e Econômico, elaboração e controle do orçamento empresarial e controles internos.",
            highYieldAlerts = listOf(
                "Margem de Contribuição Unitária (MC): MC = Preço de Venda Unitário (PV) - Custo Variável Unitário (CVU). Representa quanto cada unidade contribui para cobrir os custos fixos e gerar lucro.",
                "Ponto de Equilíbrio Contábil (PEC): PEC (em unidades) = Custos Fixos Totais / Margem de Contribuição Unitária.",
                "Custos Fixos vs. Variáveis: Custo Fixo independe do volume produzido no curto prazo (ex: aluguel, salários fixos); Custo Variável cresce proporcionalmente à produção/movimentação (ex: energia elétrica de bombas, insumos)."
            ),
            examTraps = listOf(
                "Achar que no Ponto de Equilíbrio Financeiro (PEF) somam-se as despesas de depreciação. O PEF DESCONSIDERA despesas que não geram desembolso financeiro real no caixa (como depreciação e amortização).",
                "Confundir Custo Direto (facilmente apropriável ao produto sem rateio) com Custo Variável."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Classificação e Análise de Custos para Tomada de Decisão",
                    body = """Conceitos Fundamentais da Contabilidade de Custos:

1. Quanto à Identificação com o Objeto de Custo:
• Custos Diretos: Podem ser medidos e apropriados diretamente ao produto ou serviço sem critérios subjetivos de rateio (ex: diesel consumido no motor da bomba, mangote marítimo trocado no navio).
• Custos Indiretos: Dependem de critérios de rateio ou estimativas para serem distribuídos (ex: iluminação geral do terminal, supervisão geral de segurança, depreciação do prédio administrativo).

2. Quanto ao Comportamento em Relação ao Volume:
• Custos Fixos: Mantêm-se constantes dentro de uma determinada faixa de capacidade instalada, independentemente de se movimentar 1.000 ou 100.000 m³ de combustível.
• Custos Variáveis: Variam em proporção direta com o volume movimentado de petróleo/derivados.

3. Custos vs. Despesas:
• Custos: Gastos relativos à atividade produtiva e operacional central (operação de dutos, manutenção de bombas).
• Despesas: Gastos com a gestão administrativa, comercialização e captação de recursos financeiros.""",
                    formulas = listOf(
                        FormulaItem(
                            name = "Pontos de Equilíbrio (Break-Even Point)",
                            expression = "PEC = Custos Fixos / MC_unitária  |  PEF = (Custos Fixos - Não Desembolsáveis) / MC_unitária  |  PEE = (Custos Fixos + Lucro Desejado) / MC_unitária",
                            variables = "PEC: Contábil (lucro zero); PEF: Financeiro (caixa zero); PEE: Econômico (cobre o custo de oportunidade do capital).",
                            applicationTip = "Lembre-se da hierarquia: PEF < PEC < PEE (o Ponto de Equilíbrio Financeiro é sempre o menor dos três)."
                        )
                    )
                ),
                ContentSection(
                    title = "2. Orçamento Empresarial e Sistema de Controles Internos (COSO)",
                    body = """Gestão Orçamentária na Transpetro:
• Orçamento Estático vs. Flexível: O orçamento flexível ajusta as previsões de custos e receitas às variações reais do volume operacional executado.
• Análise das Variações (Orçado vs. Realizado): Identificação de desvios favoráveis e desfavoráveis para intervenção gerencial corretiva.

Estrutura de Controles Internos (Metodologia COSO - Committee of Sponsoring Organizations):
Os controles internos visam garantir a eficácia das operações, a confiabilidade dos relatórios financeiros e a conformidade legal (compliance).
Cinco Componentes Inter-relacionados do COSO:
1. Ambiente de Controle (postura da alta liderança, ética e integridade).
2. Avaliação de Riscos (identificação e análise dos riscos corporativos).
3. Atividades de Controle (políticas, procedimentos, aprovações, segregação de funções).
4. Informação e Comunicação (fluxo transparente e tempestivo de dados).
5. Atividades de Monitoramento (auditoria interna contínua e revisões gerenciais).""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: SEGREGAÇÃO DE FUNÇÕES",
                            content = "O princípio da Segregação de Funções estabelece que nenhuma pessoa deve ter controle completo sobre todas as fases de uma transação crítica (ex: quem solicita a compra não pode ser quem aprova, nem quem recebe o material e nem quem autoriza o pagamento).",
                            iconType = "LAW"
                        )
                    )
                )
            ),
            questions = createAdminTopicQuestions(4, "Custos e Orçamento")
        )
    }

    private fun createGovernancaComplianceEticaChapter(): EBookChapter {
        return EBookChapter(
            id = "admin_cap_5",
            partId = "part_7",
            partNumber = 7,
            partTitle = "PARTE 7 — CONHECIMENTOS ESPECÍFICOS: ADMINISTRAÇÃO E CONTROLE",
            chapterNumber = 5,
            title = "Capítulo 5 — Governança Corporativa, Ética, Compliance e Lei Anticorrupção",
            subtitle = "Código de Conduta Ética Transpetro/Petrobras, Programa de Integridade, Lei 12.846/2013 e Conflito de Interesses",
            readTimeMinutes = 24,
            strategicSummary = "Pilares da Governança Corporativa (IBGC), Programa de Integridade e Compliance do Sistema Petrobras, canais de denúncia (Ouvidoria), prevenção à lavagem de dinheiro e Lei Anticorrupção.",
            highYieldAlerts = listOf(
                "Os Quatro Princípios Fundamentais da Governança Corporativa (IBGC): Transparência (Disclosure), Equidade (Fairness), Prestação de Contas (Accountability) e Responsabilidade Corporativa.",
                "Lei Anticorrupção (Lei nº 12.846/2013): Estabelece a responsabilidade objetiva (civil e administrativa) das pessoas jurídicas pela prática de atos contra a administração pública nacional ou estrangeira, independente de comprovação de culpa ou dolo dos dirigentes.",
                "Canal de Denúncias da Ouvidoria-Geral: Canal independente e anônimo com garantia absoluta de não retaliação ao denunciante de boa-fé."
            ),
            examTraps = listOf(
                "Achar que a responsabilidade da empresa na Lei Anticorrupção exige prova de dolo ou intenção culposa dos executivos (a responsabilidade da pessoa jurídica é OBJETIVA!).",
                "Aceitar brindes ou presentes de fornecedores de valor superior ao teto estipulado no Código de Conduta Ética (violação grave de compliance e conflito de interesses)."
            ),
            contentSections = listOf(
                ContentSection(
                    title = "1. Princípios de Governança Corporativa e Programa de Compliance",
                    body = """O Programa de Integridade da Transpetro garante que todas as decisões e operações sejam pautadas pela transparência e legalidade:

Os 4 Pilares da Governança Corporativa:
1. Transparência: Desejo genuíno de disponibilizar informações claras, completas e tempestivas para acionistas, órgãos de controle e sociedade, além do exigido por lei.
2. Equidade: Tratamento justo e isonômico de todos os públicos de interesse (stakeholders), sem discriminação ou privilégios indevidos.
3. Prestação de Contas (Accountability): Os agentes de governança devem prestar contas de sua atuação de modo claro e assumir integralmente as consequências de seus atos e omissões.
4. Responsabilidade Corporativa: Visão de sustentabilidade a longo prazo, zelando pela viabilidade econômico-financeira, social e ambiental da organização.""",
                    tables = listOf(
                        TableItem(
                            title = "Diretrizes do Código de Conduta Ética do Sistema Petrobras/Transpetro",
                            headers = listOf("Tema", "Conduta Obrigatória", "Conduta Expressamente Proibida"),
                            rows = listOf(
                                listOf("Conflito de Interesses", "Declarar imediatamente relações familiares ou financeiras com fornecedores", "Participar de decisão de contratação de empresa de parentes"),
                                listOf("Brindes e Presentes", "Aceitar apenas itens de valor promocional irrelevante e distribuição geral", "Aceitar viagens, hospedagens, cortesias ou presentes de fornecedores"),
                                listOf("Uso de Bens e Recursos", "Utilizar ativos da empresa exclusivamente para os fins do trabalho", "Utilizar veículos ou ferramentas corporativas para atividades particulares"),
                                listOf("Informações Privilegiadas", "Manter sigilo absoluto sobre dados operacionais e estratégicos (Insider Trading)", "Repassar informações confidenciais a terceiros ou operar ações no mercado")
                            )
                        )
                    )
                ),
                ContentSection(
                    title = "2. Lei Anticorrupção (Lei 12.846/2013) e Acordo de Leniência",
                    body = """Aspectos Chave da Lei 12.846/2013:
• Responsabilidade Objetiva: A empresa responde civil e administrativamente pelos atos lesivos praticados em seu interesse ou benefício por qualquer funcionário ou preposto, sem necessidade de provar que a diretoria tinha ciência.
• Sanções Administrativas:
  - Multa de 0,1% a 20% do faturamento bruto do último exercício anterior à instauração do processo administrativo (ou de R$ 6 mil a R$ 50 milhões se não for possível utilizar o faturamento).
  - Publicação extraordinária da decisão condenatória nos grandes veículos de comunicação.
• Acordo de Leniência: Permite à pessoa jurídica colaborar com as investigações, identificar demais envolvidos e obter provas documentais em troca da isenção ou atenuação das sanções legais.""",
                    attentionBoxes = listOf(
                        AttentionBoxData(
                            title = "ATENÇÃO: PROTEÇÃO AO DENUNCIANTE",
                            content = "Na Transpetro, a retaliação a qualquer empregado ou colaborador que fizer denúncia fundamentada de má conduta constitui falta grave e passível de demissão por justa causa.",
                            iconType = "LAW"
                        )
                    )
                )
            ),
            questions = createAdminTopicQuestions(5, "Governança e Compliance")
        )
    }

    private fun createAdminTopicQuestions(chapNum: Int, topicName: String): List<PracticeQuestion> {
        return listOf(
            PracticeQuestion(
                id = "adm_q_${chapNum}_1",
                code = "ADM-$chapNum-01",
                subject = "Administração e Controle",
                topic = topicName,
                difficulty = "Médio",
                statement = "Na gestão de materiais e estoques de sobressalentes para a infraestrutura dutoviária da Transpetro, um analista deve considerar que:",
                options = listOf(
                    "A) Os itens classificados como Classe A na Curva ABC são os mais numerosos em quantidade física no almoxarifado, totalizando mais de 70% dos itens.",
                    "B) O Ponto de Pedido (PP) é determinado unicamente pela multiplicação do consumo médio diário pelo tempo de reposição, desconsiderando o estoque de segurança.",
                    "C) Pelo método de avaliação PEPS (FIFO), as saídas de materiais do estoque são valoradas pelo preço dos lotes mais antigos, mantendo o estoque final avaliado a custos mais recentes.",
                    "D) A classificação XYZ de criticidade operacional tem por objetivo precificar financeiramente os itens de maior custo unitário.",
                    "E) O método UEPS (LIFO) é o único critério de valoração de estoques expressamente admitido pela legislação do Imposto de Renda no Brasil."
                ),
                correctIndex = 2,
                detailedExplanation = "A alternativa C está correta: No método PEPS (Primeiro que Entra, Primeiro que Sai), os primeiros custos de aquisição são os primeiros a serem baixados, fazendo com que o saldo remanescente em estoque fique avaliado aos preços mais recentes.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: Na Curva ABC, os itens Classe A representam aproximadamente 20% da QUANTIDADE física e cerca de 80% do VALOR monetário.",
                    1 to "Incorreto: A fórmula completa do Ponto de Pedido é PP = (C_m × TR) + ES (soma-se o Estoque de Segurança).",
                    3 to "Incorreto: A classificação XYZ avalia a CRITICIDADE operacional (impacto da falta do item na operação), e não o valor financeiro.",
                    4 to "Incorreto: O UEPS é expressamente PROIBIDO pela legislação fiscal brasileira."
                ),
                highYieldTip = "PEPS = Estoque final avaliado a preços novos (maior); UEPS = Estoque final avaliado a preços velhos (proibido no Brasil)."
            ),
            PracticeQuestion(
                id = "adm_q_${chapNum}_2",
                code = "ADM-$chapNum-02",
                subject = "Administração e Controle",
                topic = topicName,
                difficulty = "Difícil",
                statement = "No que se refere às diretrizes de Governança Corporativa, Licitações nas Estatais (Lei 13.303/2016) e Lei Anticorrupção (Lei 12.846/2013), assinale a afirmativa correta:",
                options = listOf(
                    "A) A responsabilização civil e administrativa de pessoas jurídicas na Lei Anticorrupção depende da comprovação cabal de dolo ou culpa dos seus diretores.",
                    "B) A Inexigibilidade de licitação caracteriza-se pela inviabilidade jurídica de competição, como na contratação de fornecedor exclusivo devidamente comprovado.",
                    "C) O Ponto de Equilíbrio Financeiro (PEF) exige a cobertura integral de todas as despesas contábeis não desembolsáveis, como a depreciação de ativos.",
                    "D) O princípio da segregação de funções recomenda que a mesma equipe técnica elabore o edital, selecione o fornecedor, receba as mercadorias e ordene os pagamentos.",
                    "E) O planejamento estratégico é voltado exclusivamente para o curto prazo e focado na otimização de tarefas operacionais diárias."
                ),
                correctIndex = 1,
                detailedExplanation = "A alternativa B está correta: A inexigibilidade de licitação (art. 30 da Lei 13.303/2016) ocorre quando a competição é inviável, especialmente no caso de fornecedor exclusivo ou serviços técnicos de notória especialização.",
                incorrectOptionsExplanation = mapOf(
                    0 to "Incorreto: A responsabilidade na Lei 12.846/2013 é OBJETIVA, independe de dolo ou culpa.",
                    2 to "Incorreto: O PEF DESCONSIDERA custos não desembolsáveis como depreciação.",
                    3 to "Incorreto: A segregação de funções EXIGE a separação rigorosa entre essas etapas para evitar fraudes.",
                    4 to "Incorreto: Planejamento de curto prazo com foco em tarefas diárias é o planejamento OPERACIONAL."
                ),
                highYieldTip = "Inexigibilidade = Inviabilidade de competição. Dispensa = Competição viável, mas dispensada expressamente pela lei."
            )
        )
    }
}
