package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.exporter.LeadExporter
import com.example.data.model.Lead
import com.example.data.processor.LeadManagerEngine
import com.example.data.util.PhoneSafetyHandler
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Gestor de Leads", appName)
  }

  @Test
  fun `phone safety recovers scientific notation without losing digits`() {
    val raw = "7.99999E+10"
    val recovered = PhoneSafetyHandler.sanitizeRawPhone(raw)
    assertEquals("79999900000", recovered)
  }

  @Test
  fun `phone safety recovers trailing decimals without losing digits`() {
    val raw = "11977778888.0"
    val recovered = PhoneSafetyHandler.sanitizeRawPhone(raw)
    assertEquals("11977778888", recovered)
  }

  @Test
  fun `phone safety preserves leading zeros`() {
    val raw = "07999881122"
    val recovered = PhoneSafetyHandler.sanitizeRawPhone(raw)
    assertEquals("07999881122", recovered)
  }

  @Test
  fun `phone safety preserves international code and DDD`() {
    val raw = "+55 (79) 99999-9999"
    val recovered = PhoneSafetyHandler.sanitizeRawPhone(raw)
    assertEquals("+55 (79) 99999-9999", recovered)

    val normalized = PhoneSafetyHandler.normalizePhone(recovered)
    assertEquals("5579999999999", normalized)
  }

  @Test
  fun `course column variations detection supports CURSO, CURSO CONCURSO, PRODUTO, ITENS`() {
    val headers1 = listOf("Nome", "Telefone", "CURSO / CONCURSO", "Email")
    assertEquals("CURSO / CONCURSO", LeadManagerEngine.detectCourseColumn(headers1))

    val headers2 = listOf("Nome", "WhatsApp", "PRODUTO", "Email")
    assertEquals("PRODUTO", LeadManagerEngine.detectCourseColumn(headers2))

    val headers3 = listOf("Nome", "WhatsApp", "ITENS", "Email")
    assertEquals("ITENS", LeadManagerEngine.detectCourseColumn(headers3))

    val headers4 = listOf("Nome", "WhatsApp", "NOME DO CONCURSO", "Email")
    assertEquals("NOME DO CONCURSO", LeadManagerEngine.detectCourseColumn(headers4))
  }

  @Test
  fun `placeholder Ex Policia Federal is NEVER saved as data`() {
    val csvWithPlaceholder = """
      Nome;Telefone;CURSO / CONCURSO;Email
      João Silva;79991234567;Ex: Polícia Federal;joao@teste.com
      Maria Santos;79997654321;Receita Federal - Auditor;maria@teste.com
      Carlos Lima;79998881122; ;carlos@teste.com
    """.trimIndent().toByteArray(Charsets.UTF_8)

    val result = LeadManagerEngine.processFile("teste_placeholder.csv", csvWithPlaceholder)
    val leads = result.leads

    // João had "Ex: Polícia Federal" -> MUST be cleaned to empty, NEVER saved!
    assertEquals("", leads[0].course)
    assertFalse(leads[0].hasCourse)

    // Maria had real course -> Must be preserved exactly
    assertEquals("Receita Federal - Auditor", leads[1].course)
    assertTrue(leads[1].hasCourse)

    // Carlos had empty cell -> Must remain empty, NOT defaulted to any fake text
    assertEquals("", leads[2].course)
  }

  @Test
  fun `fallback extracts course from ITENS or PRODUTO when main course column is absent`() {
    val csvWithItens = """
      Nome;WhatsApp;Email;ITENS;Temperatura;Observacao
      Lucas Dias;11987654321;lucas@teste.com;Polícia Federal - Escrivão;Quente;Dúvida edital
    """.trimIndent().toByteArray(Charsets.UTF_8)

    val result = LeadManagerEngine.processFile("teste_itens.csv", csvWithItens)
    val lead = result.leads[0]

    assertEquals("Polícia Federal - Escrivão", lead.course)
    assertEquals("Quente", lead.temperature)
    assertEquals("Dúvida edital", lead.observation)
  }

  @Test
  fun `908 leads batch correctly assigns distinct courses and validates zero loss`() {
    val bytes908 = LeadManagerEngine.getSample908LeadsCsv()
    val result = LeadManagerEngine.processFile("base_908.csv", bytes908)

    assertEquals(908, result.totalRowsRead)
    assertEquals(908, result.leads.size)

    val validation = result.validationComparison
    assertNotNull(validation)
    assertEquals(908, validation!!.totalRowsInFile)
    assertEquals(908, validation.totalLeadsParsed)
    assertEquals(908, validation.leadsWithDetectedCourse)
    assertEquals(908, validation.leadsWithDetectedPhone)

    // Verify multiple real distinct courses exist across leads
    val distinctCourses = result.leads.map { it.course }.distinct()
    assertTrue(distinctCourses.size > 5)
    assertTrue(distinctCourses.contains("Polícia Federal - Agente"))
    assertTrue(distinctCourses.contains("Receita Federal - Auditor Fiscal"))
    assertTrue(distinctCourses.contains("INSS - Técnico do Seguro Social"))

    // Ensure NO lead has placeholder "Ex: Polícia Federal"
    for (lead in result.leads) {
      assertFalse(lead.course.startsWith("Ex:"))
      assertFalse(lead.course.startsWith("Ex.:"))
    }
  }

  @Test
  fun `lead processing retains all records and detects duplicates without deleting`() {
    val sampleBytes = LeadManagerEngine.getSampleLeadsCsv()
    val result = LeadManagerEngine.processFile("test_sample.csv", sampleBytes)

    // Verify all rows are read
    assertEquals(14, result.totalRowsRead)
    assertEquals(14, result.leads.size)

    // Verify duplicates are flagged, NOT deleted
    val duplicates = result.leads.filter { it.isDuplicate }
    assertTrue(duplicates.isNotEmpty())
    assertEquals(14, result.leads.size) // Total count remains exactly 14

    // Verify integrity report
    val report = LeadManagerEngine.generateIntegrityReport(result.leads, result.readErrors)
    assertEquals(14, report.totalLeads)
    assertEquals(0, report.phonesLost)
    assertTrue(report.isIntegrityVerified)
    assertEquals(14, report.leadsWithCourse)
  }

  @Test
  fun `filter by responsible separates Josue and Wanessa correctly`() {
    val sampleBytes = LeadManagerEngine.getSampleLeadsCsv()
    val result = LeadManagerEngine.processFile("test_sample.csv", sampleBytes)

    val sheets = LeadManagerEngine.createResponsibleSheets(result.leads, listOf("Josué", "Wanessa"))
    assertEquals(3, sheets.size) // "Todos", "Josué", "Wanessa"

    val todosSheet = sheets.find { it.sheetName == "Todos" }
    val josueSheet = sheets.find { it.sheetName == "Josué" }
    val wanessaSheet = sheets.find { it.sheetName == "Wanessa" }

    assertNotNull(todosSheet)
    assertNotNull(josueSheet)
    assertNotNull(wanessaSheet)

    assertEquals(14, todosSheet!!.leadCount)
    assertEquals(7, josueSheet!!.leadCount)
    assertEquals(6, wanessaSheet!!.leadCount)
    assertEquals(todosSheet.leadCount, josueSheet.leadCount + wanessaSheet.leadCount + 1)
  }

  @Test
  fun `export validation blocks when phones or courses are lost and approves when preserved`() {
    val lead1 = Lead(
      id = "1", originalRowIndex = 1, name = "Test 1", originalPhone = "07999999999",
      normalizedPhone = "07999999999", email = "test1@email.com", course = "Polícia Federal",
      responsible = "Josué", status = "Novo", campaign = "Ads"
    )
    val lead2WithPhone = Lead(
      id = "2", originalRowIndex = 2, name = "Test 2", originalPhone = "011988887777",
      normalizedPhone = "011988887777", email = "test2@email.com", course = "Receita Federal",
      responsible = "Wanessa", status = "Novo", campaign = "Ads"
    )
    val lead2WithoutPhone = lead2WithPhone.copy(originalPhone = "", normalizedPhone = "", hasPhone = false)
    val lead2WithoutCourse = lead2WithPhone.copy(course = "", hasCourse = false)

    // Valid: 2 in, 2 out, all preserved
    val valid = LeadExporter.validateBeforeExport(listOf(lead1, lead2WithPhone), listOf(lead1, lead2WithPhone))
    assertTrue(valid.canExport)
    assertEquals(0, valid.lostPhones)
    assertEquals(0, valid.lostCourses)

    // Invalid: 1 phone lost
    val invalidPhone = LeadExporter.validateBeforeExport(listOf(lead1, lead2WithPhone), listOf(lead1, lead2WithoutPhone))
    assertFalse(invalidPhone.canExport)
    assertEquals(1, invalidPhone.lostPhones)

    // Invalid: 1 course lost
    val invalidCourse = LeadExporter.validateBeforeExport(listOf(lead1, lead2WithPhone), listOf(lead1, lead2WithoutCourse))
    assertFalse(invalidCourse.canExport)
    assertEquals(1, invalidCourse.lostCourses)
  }
}
