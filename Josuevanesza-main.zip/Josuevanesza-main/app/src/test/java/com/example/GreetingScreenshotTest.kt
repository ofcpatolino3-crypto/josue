package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.model.Lead
import com.example.ui.components.LeadCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun lead_card_screenshot() {
    val sampleLead = Lead(
      id = "lead_1",
      originalRowIndex = 1,
      name = "Josué Albuquerque",
      originalPhone = "(79) 99999-9999",
      normalizedPhone = "79999999999",
      email = "josue.albuquerque@email.com",
      responsible = "Josué",
      status = "Novo Lead",
      campaign = "Google Ads",
      isDuplicate = false,
      rawData = mapOf(
        "Nome" to "Josué Albuquerque",
        "Telefone" to "(79) 99999-9999",
        "Email" to "josue.albuquerque@email.com",
        "Responsavel" to "Josué"
      )
    )

    composeTestRule.setContent {
      MyApplicationTheme {
        LeadCard(lead = sampleLead)
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/lead_card.png")
  }
}
