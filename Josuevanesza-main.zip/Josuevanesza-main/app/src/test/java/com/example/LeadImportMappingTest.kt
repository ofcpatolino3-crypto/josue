package com.example

import com.example.data.processor.LeadManagerEngine
import org.junit.Assert.*
import org.junit.Test

class LeadImportMappingTest {

    private val engine = LeadManagerEngine

    @Test
    fun testScenario1_CourseBeforeObservation() {
        val csv = """
            Nome;Telefone;Curso / Concurso;Observação
            João Silva;11999887766;Polícia Rodoviária Federal;Interesse na turma da noite
            Maria Souza;21988776655;Receita Federal - Auditor;Solicitou desconto à vista
        """.trimIndent()

        val result = engine.processFile("leads.csv", csv.toByteArray(Charsets.UTF_8))
        assertFalse(result.hasMappingConflict)
        assertEquals(2, result.leads.size)

        val lead1 = result.leads[0]
        assertEquals("João Silva", lead1.name)
        assertEquals("Polícia Rodoviária Federal", lead1.course)
        assertEquals("Interesse na turma da noite", lead1.observation)

        val lead2 = result.leads[1]
        assertEquals("Maria Souza", lead2.name)
        assertEquals("Receita Federal - Auditor", lead2.course)
        assertEquals("Solicitou desconto à vista", lead2.observation)
    }

    @Test
    fun testScenario2_ObservationBeforeCourse() {
        val csv = """
            Nome;WhatsApp;Observação;Curso / Concurso
            Carlos Lima;31977665544;Aguardando retorno do responsável;Tribunal de Contas da União
            Ana Paula;41966554433;Já é aluna de outro curso;Polícia Civil - Delegado
        """.trimIndent()

        val result = engine.processFile("leads.csv", csv.toByteArray(Charsets.UTF_8))
        assertFalse(result.hasMappingConflict)
        assertEquals(2, result.leads.size)

        val lead1 = result.leads[0]
        assertEquals("Carlos Lima", lead1.name)
        assertEquals("Tribunal de Contas da União", lead1.course)
        assertEquals("Aguardando retorno do responsável", lead1.observation)

        val lead2 = result.leads[1]
        assertEquals("Ana Paula", lead2.name)
        assertEquals("Polícia Civil - Delegado", lead2.course)
        assertEquals("Já é aluna de outro curso", lead2.observation)
    }

    @Test
    fun testScenario3_HeaderNamedCurso() {
        val csv = """
            Nome;Celular;CURSO;Status
            Pedro Santos;11955443322;Carreiras Policiais 2026;Novo
        """.trimIndent()

        val result = engine.processFile("leads.csv", csv.toByteArray(Charsets.UTF_8))
        assertEquals("CURSO", result.courseColumnName)
        assertEquals("Carreiras Policiais 2026", result.leads[0].course)
        assertEquals("", result.leads[0].observation)
    }

    @Test
    fun testScenario4_HeaderNamedCursoSlashConcurso() {
        val variations = listOf("CURSO/CONCURSO", "CURSO / CONCURSO", "Curso/Concurso", "Curso / Concurso")
        for (header in variations) {
            val csv = """
                Nome;WhatsApp;$header
                Lucas Mendes;11944332211;Banco do Brasil
            """.trimIndent()

            val result = engine.processFile("test.csv", csv.toByteArray(Charsets.UTF_8))
            assertEquals(header, result.courseColumnName)
            assertEquals("Banco do Brasil", result.leads[0].course)
        }
    }

    @Test
    fun testScenario5_HeaderNamedConcurso() {
        val csv = """
            Nome;Telefone;CONCURSO;Obs
            Fernanda Rocha;21933221100;Polícia Federal - Perito;Entrar em contato após às 18h
        """.trimIndent()

        val result = engine.processFile("leads.csv", csv.toByteArray(Charsets.UTF_8))
        assertEquals("CONCURSO", result.courseColumnName)
        assertEquals("Obs", result.observationColumnName)
        assertEquals("Polícia Federal - Perito", result.leads[0].course)
        assertEquals("Entrar em contato após às 18h", result.leads[0].observation)
    }

    @Test
    fun testScenario6_HeaderNamedProduto() {
        val csv = """
            Cliente;Telefone;PRODUTO;Comentário
            Gabriel Neves;7999887766;Combo Carreiras Jurídicas;Sem observações adicionais
        """.trimIndent()

        val result = engine.processFile("leads.csv", csv.toByteArray(Charsets.UTF_8))
        assertEquals("PRODUTO", result.courseColumnName)
        assertEquals("Comentário", result.observationColumnName)
        assertEquals("Combo Carreiras Jurídicas", result.leads[0].course)
        assertEquals("Sem observações adicionais", result.leads[0].observation)
    }

    @Test
    fun testScenario7_HeaderNamedItemOrItens() {
        val csv1 = """
            Nome completo;Contato;ITEM
            Beatriz Ramos;81988776655;Curso OAB 1ª Fase
        """.trimIndent()
        val res1 = engine.processFile("items.csv", csv1.toByteArray(Charsets.UTF_8))
        assertEquals("ITEM", res1.courseColumnName)
        assertEquals("Curso OAB 1ª Fase", res1.leads[0].course)

        val csv2 = """
            Nome;Celular;ITENS
            Marcos Vinicius;85977665544;Módulo Avançado de Direito Penal
        """.trimIndent()
        val res2 = engine.processFile("itens.csv", csv2.toByteArray(Charsets.UTF_8))
        assertEquals("ITENS", res2.courseColumnName)
        assertEquals("Módulo Avançado de Direito Penal", res2.leads[0].course)
    }

    @Test
    fun testScenario8_ObservationVariations() {
        val obsHeaders = listOf("Obs", "Anotação", "Anotações", "Comentário", "Comentários", "Nota", "Notas")
        for (obsH in obsHeaders) {
            val csv = """
                Nome;WhatsApp;Curso;$obsH
                Teste Aluno;11999998888;ENAM 2026;Nota importante aqui
            """.trimIndent()

            val result = engine.processFile("test.csv", csv.toByteArray(Charsets.UTF_8))
            assertEquals("Curso", result.courseColumnName)
            assertEquals(obsH, result.observationColumnName)
            assertEquals("ENAM 2026", result.leads[0].course)
            assertEquals("Nota importante aqui", result.leads[0].observation)
        }
    }

    @Test
    fun testScenario9_EmptyCourseRemainsEmpty() {
        val csv = """
            Nome;WhatsApp;Curso / Concurso;Observação
            Aluno Sem Curso;11911112222;;Apenas observação do aluno
        """.trimIndent()

        val result = engine.processFile("empty.csv", csv.toByteArray(Charsets.UTF_8))
        val lead = result.leads[0]
        assertEquals("", lead.course)
        assertNotEquals("Polícia Federal", lead.course)
        assertNotEquals("Ex: Polícia Federal", lead.course)
        assertEquals("Apenas observação do aluno", lead.observation)
    }

    @Test
    fun testScenario10_PlaceholderStrippedAndNeverSaved() {
        val csv = """
            Nome;WhatsApp;Curso / Concurso;Observação
            Aluno Exemplo 1;11911113333;Ex: Polícia Federal;Interesse geral
            Aluno Exemplo 2;11911114444;Ex.: Polícia Federal;Aguardar contato
            Aluno Exemplo 3;11911115555;Exemplo: Polícia Federal;Solicitou ligar amanhã
            Aluno Real;11911116666;Polícia Federal - Agente;Inscrito no simulado
        """.trimIndent()

        val result = engine.processFile("placeholders.csv", csv.toByteArray(Charsets.UTF_8))
        assertEquals("", result.leads[0].course)
        assertEquals("", result.leads[1].course)
        assertEquals("", result.leads[2].course)
        assertEquals("Polícia Federal - Agente", result.leads[3].course)

        // Verify observations were preserved intact
        assertEquals("Interesse geral", result.leads[0].observation)
        assertEquals("Aguardar contato", result.leads[1].observation)
        assertEquals("Solicitou ligar amanhã", result.leads[2].observation)
        assertEquals("Inscrito no simulado", result.leads[3].observation)
    }

    @Test
    fun testScenario11_CommaAndSemicolonDelimiters() {
        val csvSemicolon = """
            Nome;WhatsApp;Curso;Observação
            Juliana Silva;11988887777;Delegado Federal;Formada em Direito
        """.trimIndent()
        val res1 = engine.processFile("semicolon.csv", csvSemicolon.toByteArray(Charsets.UTF_8))
        assertEquals("Delegado Federal", res1.leads[0].course)
        assertEquals("Formada em Direito", res1.leads[0].observation)

        val csvComma = """
            Nome,WhatsApp,Curso,Observação
            Renato Dias,11977776666,Polícia Rodoviária Federal,Estudando há 1 ano
        """.trimIndent()
        val res2 = engine.processFile("comma.csv", csvComma.toByteArray(Charsets.UTF_8))
        assertEquals("Polícia Rodoviária Federal", res2.leads[0].course)
        assertEquals("Estudando há 1 ano", res2.leads[0].observation)

        val tsv = "Nome\tWhatsApp\tCurso\tObservação\nCamila Ramos\t11966665555\tReceita Federal\tSolicitou edital"
        val res3 = engine.processFile("tab.tsv", tsv.toByteArray(Charsets.UTF_8))
        assertEquals("Receita Federal", res3.leads[0].course)
        assertEquals("Solicitou edital", res3.leads[0].observation)
    }

    @Test
    fun testMappingConflictDetection() {
        // When duplicated identical column exists
        val csvDupe = """
            Nome;Telefone;Curso;Curso
            Teste;11999990000;A;B
        """.trimIndent()
        val res = engine.processFile("dupe.csv", csvDupe.toByteArray(Charsets.UTF_8))
        assertTrue(res.hasMappingConflict)
        assertNotNull(res.mappingConflictMessage)
    }

    @Test
    fun testCursoQueOAlunoComprouHeader() {
        val csv = """
            Nome;Telefone;Curso que o aluno comprou;Observação
            Lucas Silva;11988889999;Polícia Federal - Agente;Aluno pagou à vista
        """.trimIndent()
        val res = engine.processFile("compras.csv", csv.toByteArray(Charsets.UTF_8))
        assertEquals("Curso que o aluno comprou", res.courseColumnName)
        assertEquals("Observação", res.observationColumnName)
        assertEquals("Polícia Federal - Agente", res.leads[0].course)
        assertEquals("Aluno pagou à vista", res.leads[0].observation)
    }

    @Test
    fun testCoursePrefixInObservationAutoExtracted() {
        val csv = """
            Nome;Telefone;Observação
            Mariana Costa;21977778888;Comprou: Delegado Polícia Civil
        """.trimIndent()
        val res = engine.processFile("sem_coluna_curso.csv", csv.toByteArray(Charsets.UTF_8))
        // Should detect course from the observation value
        assertEquals("Delegado Polícia Civil", res.leads[0].course)
        assertEquals("", res.leads[0].observation)
    }

    @Test
    fun testCustomColumnMappingOverride() {
        val csv = """
            Nome;Telefone;ColunaA;ColunaB
            Roberto Carlos;31966665555;Polícia Rodoviária Federal;Pretende fazer prova ano que vem
        """.trimIndent()
        val res = engine.processFile(
            fileName = "custom.csv",
            bytes = csv.toByteArray(Charsets.UTF_8),
            customCourseCol = "ColunaA",
            customObsCol = "ColunaB"
        )
        assertEquals("ColunaA", res.courseColumnName)
        assertEquals("ColunaB", res.observationColumnName)
        assertEquals("Polícia Rodoviária Federal", res.leads[0].course)
        assertEquals("Pretende fazer prova ano que vem", res.leads[0].observation)
    }
}
